KWT RTL 分层验证与波形查看包
日期：2026-11-09

本包保持当前 kwt_tcm_batch10 的 26 个设计源码文件逐字节不变。
测试台使用自动检查、错误退出和超时；波形用于观察过程，不代替数值检查。
本机可运行 ModelSim 预检查；服务器 VCS/真实工艺模型结果以新运行日志为准。
历史十样本 VCS PASS 属于原平台回归，不等于新增测试台已经在 VCS 通过。

1. 上传与解压（服务器 Bash）
把 kwt_vcs_module_verify_vcs.tar.gz 上传到 ~/Desktop，然后执行：

  source "$HOME/Desktop/kwt_e203_offline/env.sh"
  kwt_stage=$(mktemp -d "$HOME/Desktop/kwt_module_verify_XXXXXXXX")
  tar -xzf "$HOME/Desktop/kwt_vcs_module_verify_vcs.tar.gz" -C "$kwt_stage"
  cd "$kwt_stage/kwt_vcs_module_verify"
  sha256sum -c SHA256SUMS
  bash run_vcs.sh --list

每次调用均创建独立 runs/<测试名>_<随机字符>，不覆盖之前的结果。
run_vcs.sh 已写好编译、运行、检查日志和波形的步骤，不需要手写VCS命令。
PYTHON_BIN 默认 python，兼容 Python 2.7/3；VCS_BIN 默认 vcs。

2. 按顺序执行各模块

  bash run_vcs.sh operators
  bash run_vcs.sh pe
  bash run_vcs.sh matrix
  bash run_vcs.sh vector
  bash run_vcs.sh dequant
  bash run_vcs.sh icb_cfg
  bash run_vcs.sh icb_master
  bash run_vcs.sh dma
  bash run_vcs.sh arbiter
  bash run_vcs.sh sram
  bash run_vcs.sh controller

或者一次执行以上快速测试：
  bash run_all.sh

测试与源码：
operators   tb/tb_operators.sv   FP16/FP32转换、FP32加/乘、比较、SFU标量操作
pe          tb/tb_pe.sv          PE乘累加、清零、有效数据时序
matrix      tb/tb_matrix.sv      8x8阵列与小矩阵乘法
vector      tb/tb_vector.sv      Softmax、LayerNorm、GELU、残差等向量操作
dequant     tb/tb_dequant.sv     INT8反量化、比例/掩码及独立黄金向量
icb_cfg     tb/tb_icb_cfg.sv     MMIO寄存器、START、状态、IRQ、byte mask
icb_master  tb/tb_icb_master.sv  命令/响应握手及背压
dma         tb/tb_dma.sv         DMA读写搬运及错误路径
arbiter     tb/tb_arbiter.sv      CPU/DMA仲裁、响应归属及背压
sram        tb/tb_sram.sv        SRAM封装读写、掩码、地址
controller  tb/tb_controller.sv  本地单层控制器的17阶段调度

精确用例、计数和局限见 docs/coverage_*.txt，以检查项为覆盖范围。
这些定向功能测试不是穷尽验证，也不宣称完整IEEE浮点一致性。

3. 独立加速器集成

  WAVE_DURATION_NS=200000 bash run_vcs.sh accel
  bash run_vcs.sh accel_fault

tb_accel.sv验证 kwt_accel_icb 的一层端到端执行，含计算核、参数加载、内部SRAM、
DMA、配置寄存器及输出比较。它不包含E203，不能代替下节CPU平台测试。
tb_accel_fault.sv检查故障路径。其错误属于激励预期，最终仍需 PASS tb_accel_fault。
独立加速器TB使用其独立测试向量，CPU平台使用原十样本包的认证刺激，两者勿混淆。

4. 工艺SRAM与TCM

默认模块测试使用 +define+KWT_SRAM_BEHAV，代表功能存储器模型。
工艺库模式：
  SRAM_MODE=vendor bash run_vcs.sh sram
  bash run_vcs.sh tcm

SRAM_MODE=vendor仅用于sram/tcm；完整加速器工艺宏集成请运行下节global_*。
独立accel/accel_fault采用10ns行为仿真时钟；sram/tcm工艺功能测试采用100ns时钟。

tcm 对 ITCM(64位)和DTCM(32位)各256KiB进行完整地址扫描、字节写使能等检查，
始终使用工艺模型；不把本地测试替身作为服务器工艺模型交付。
默认库位置 /storage1/admin_public_dir/SRAM_Lib_2025；可设 SRAM_LIBRARY / SRAM_FILELIST。
100ns功能时钟不构成150MHz门级时序或SDF验证。

5. E203完整平台：单层 -> 单样本十二层 -> 十样本十二层

  bash run_vcs.sh global_layer1
  bash run_vcs.sh global_chain12
  DUMP=0 bash run_vcs.sh global_batch10

三个模式使用 global/tb/tb_tcm_chain12.sv、原CPU固件和原比较器。
global_layer1将固件和TB的CHAIN_LAYERS同时设为1；global_chain12为12；
global_batch10一次编译依次跑10个样本，汇总器重新检查全部实际输出。
前两项默认01_yes，可用 CASE_ID=08_off 等选择原10样本之一。
它们检查CPU指令执行、PLIC中断、共享总线、DMA、每层实际输出及FP32数值误差。
NRMSE门限0.03，最终分类头由Python软件计算。共享512KiB SRAM仍为行为模型。

服务器依赖沿用当前通过版本：
  ~/Desktop/kwt_e203_offline/env.sh
  RISCV_TOOLCHAIN 指向的工具链
  /storage1/admin_public_dir/SOC_RTL_2025/e203_hbirdv2-master_1013_update_sim.zip
  SRAM_Lib_2025及真实标准单元门控模型
门控模型默认通过旧kwt_platform_verify的清单或kwt_project的库索引查找；
也可显式 export CLOCKGATE_LIB_V=/真实路径/scc40nll_vhsc40_rvt.v。
E203主源码和工艺模型由服务器原依赖生成/引用，不包含未经核对的替代版本。
global/保留原包说明和历史验证记录；本包入口为根目录run_vcs.sh/run_global.sh。

6. 查看波形

每次运行会打印Results目录。模块波形在该目录wave.vcd；
CPU平台波形在 runs/global_*/cases/<样本>/wave.vcd。
将下面路径换成脚本实际输出的目录：

  bash view_wave.sh /实际运行目录 dve

脚本执行vcd2vpd转换，然后用DVE打开。也支持：
  bash view_wave.sh /实际运行目录 gtkwave
  bash view_wave.sh /实际运行目录 verdi

需要服务器图形桌面或可用DISPLAY。选中层级和信号后Add to Waves，Zoom Full，
数据右键设Hexadecimal/Unsigned，使用两个游标量周期。VCD不含源码调试数据库。

docs/pe_wave_example.png 是本机ModelSim实际VCD生成的示例图，不是服务器VCS结果。
其中want在下降沿准备下一上升沿的期望值，所以比psum_out提前半周期变化；
testbench在上升沿后检查输出。原始示例波形也保存为docs/pe_wave_example.vcd。

波形设置（单位ns）：
  WAVE_START_NS=0 WAVE_DURATION_NS=20000 WAVE_DEPTH=2 bash run_vcs.sh pe
  WAVE_SCOPE=tb_icb_master.master WAVE_DEPTH=1 bash run_vcs.sh icb_master
  DUMP=0 bash run_vcs.sh accel

模块默认从0ns开始录200000ns、层级深度2。
CPU平台默认等第一个加速器计算START后录100000ns，范围soc.u_accel、深度2。
WAVE_START_NS是触发后的延时，WAVE_DURATION_NS控制录制持续时间，不会结束测试。
WAVE_DEPTH=0递归所有层级，可能产生很大的波形。
观察CPU启动可改成时间触发、仅顶层端口：
  WAVE_TRIGGER=time WAVE_SCOPE=tb_tcm_chain12 WAVE_DEPTH=1 \
  WAVE_START_NS=0 WAVE_DURATION_NS=1000000 bash run_vcs.sh global_layer1

若触发点从未到达，或开始时间晚于测试结束，脚本会报告缺少wave.vcd。
tb里$finish表示测试本身结束；波形时间窗结束后仿真仍继续直到结果检查完成。

7. 结果文件和定位失败

compile_command.json：完整编译参数
compile.log/compile_console.log：VCS编译日志
simulation.log/simulation_console.log：仿真日志和自检信息
status.txt：模块完整成功标记（CPU平台看runner_status.txt）
wave.vcd：实际仿真波形
CPU cases/<样本>/execution.json、numerical.json、layer_*：计数及实际输出

出现编译失败先查看compile_console.log尾部；出现$ fatal/FAIL查看simulation.log。
不会用一条PASS字样替代CPU平台的实际输出比较，也不会把历史PASS写入本次结果。
所有设计RTL哈希见validation/frozen_rtl_sha256.json。
本地预检查结果见validation/中的报告；本地ModelSim结果与服务器VCS结果分别记录。

本次交付的验证记录：13个新增模块/集成TB在本机ModelSim自检通过；
CPU单层01_yes也完成预检查，NRMSE=0.00458658169，并验证了START触发波形。
这次CPU预检查使用公开E203及合成SRAM测试替身，并非服务器工艺模型结果；
测试替身不加入Linux仿真入口。完整记录见validation/global_local_summary.json。
脚本成功/失败传播15项检查通过（mock编排检查，不计为RTL仿真通过）。
