#!/usr/bin/env bash
# CPU + accelerator: original authenticated stimulus, firmware and scoreboard.
set -eo pipefail
export LC_ALL=C
root=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
base="$root/global"
mode=${1:-global_layer1}
case "$mode" in
  global_layer1) layers=1; cases=("${CASE_ID:-01_yes}") ;;
  global_chain12) layers=12; cases=("${CASE_ID:-01_yes}") ;;
  global_batch10) layers=12; cases=(01_yes 02_no 03_up 04_down 05_left 06_right 07_on 08_off 09_stop 10_go) ;;
  *) echo 'Use global_layer1, global_chain12 or global_batch10' >&2; exit 2 ;;
esac
python_bin=${PYTHON_BIN:-python}
vcs_bin=${VCS_BIN:-vcs}
command -v "$python_bin" >/dev/null
command -v "$vcs_bin" >/dev/null
[[ -n "${RISCV_TOOLCHAIN:-}" ]] || source "$HOME/Desktop/kwt_e203_offline/env.sh"
platform_zip=$(readlink -f -- "${PLATFORM_ZIP:-/storage1/admin_public_dir/SOC_RTL_2025/e203_hbirdv2-master_1013_update_sim.zip}")
library=$(readlink -f -- "${SRAM_LIBRARY:-/storage1/admin_public_dir/SRAM_Lib_2025}")
clockgate_lib=${CLOCKGATE_LIB_V:-}
[[ -z "$clockgate_lib" ]] || clockgate_lib=$(readlink -f -- "$clockgate_lib")
sram_filelist=${SRAM_FILELIST:-}
[[ -z "$sram_filelist" ]] || sram_filelist=$(readlink -f -- "$sram_filelist")
mkdir -p "$root/runs"
run=$(mktemp -d "$root/runs/${mode}_XXXXXXXX")
printf 'Run directory: %s\n' "$run"
printf 'INCOMPLETE\n' > "$run/runner_status.txt"
stage=package_check
failure() { local code=$?; trap - ERR; printf 'FAIL stage=%s logs=%s\n' "$stage" "$run" >&2; exit "$code"; }
trap failure ERR
(cd "$root" && sha256sum -c SHA256SUMS) > "$run/package_check.log"
(cd "$base" && sha256sum -c SHA256SUMS) > "$run/original_package_check.log"
stage=platform_prepare
"$python_bin" "$base/prepare_platform.py" --platform-zip "$platform_zip" --output "$run/platform" > "$run/$stage.log" 2>&1
stage=tcm_prepare
"$python_bin" "$base/tools/prepare_tcm.py" --platform "$run/platform" > "$run/$stage.log" 2>&1
stdcell_list=
if [[ -f "$run/platform/e203/rtl/e203/generic/GENERIC_RVT_SMIC.v" ]] && \
   grep -q 'CLKLANAQV4_8TR40' "$run/platform/e203/rtl/e203/generic/GENERIC_RVT_SMIC.v"; then
  stage=clockgate_find
  if [[ -z "$clockgate_lib" ]]; then
    "$python_bin" "$base/tools/find_clockgate.py" > "$run/clockgate_path.txt" 2> "$run/$stage.log"
    clockgate_lib=$(cat "$run/clockgate_path.txt")
  fi
  stage=clockgate_prepare
  "$python_bin" "$base/tools/prepare_clockgate.py" --platform "$run/platform" --model "$clockgate_lib" --output "$run/stdcell" > "$run/$stage.log" 2>&1
  stdcell_list="$run/stdcell/standardcell.f"
  mkdir "$run/clockgate_check"
  cd "$run/clockgate_check"
  stage=clockgate_compile
  "$vcs_bin" -full64 -sverilog -timescale=1ns/1ps +define+functional -top tb_clockgate_lib \
    -f "$stdcell_list" "$run/stdcell/patched_clockgate.v" "$base/tb/tb_clockgate_lib.sv" -o simv > compile.log 2>&1
  stage=clockgate_simulation
  ./simv > simulation.log 2>&1
  [[ -f clockgate_status.txt && "$(tr -d '\r\n' < clockgate_status.txt)" == PASS ]]
fi
stage=sram_prepare
sram_args=(--library "$library" --output "$run/sram")
[[ -z "$sram_filelist" ]] || sram_args+=(--filelist "$sram_filelist")
"$python_bin" "$base/tools/prepare_sram_models.py" "${sram_args[@]}" > "$run/$stage.log" 2>&1
stage=firmware_build
CHAIN_LAYERS="$layers" bash "$base/build_firmware.sh" "$run/build" > "$run/$stage.log" 2>&1
opts=(-full64 -sverilog -timescale=1ns/1ps -debug_access+all +define+ARM_UD_MODEL
  -top tb_tcm_chain12 -top kwt_wave_dump -f "$run/sram/sram.f")
[[ -z "$stdcell_list" ]] || opts+=(+define+functional -f "$stdcell_list")
while IFS= read -r f || [[ -n "$f" ]]; do
  f=${f%$'\r'}; [[ -z "$f" ]] || opts+=("+incdir+$run/platform/e203/$f")
done < "$run/platform/include_dirs.txt"
while IFS= read -r f || [[ -n "$f" ]]; do
  f=${f%$'\r'}; [[ -z "$f" ]] || opts+=("$run/platform/e203/$f")
done < "$run/platform/e203_sources.f"
opts+=("+incdir+$root/accel_rtl" "+incdir+$root/rtl")
while IFS= read -r f || [[ -n "$f" ]]; do
  f=${f%$'\r'}; [[ -z "$f" ]] || opts+=("$root/$f")
done < "$root/accel_sources.f"
opts+=("$root/rtl/kwt_icb_arb2.v" "$root/rtl/kwt_icb_window.v" "$root/rtl/kwt_platform_soc.v"
  "$root/rtl/kwt_tcm_4096x16.v" "$base/tb/icb_boot_ram.sv" "$base/tb/tb_tcm_chain12.sv")
"$python_bin" "$root/tools/make_wave.py" --output "$run/wave_dump.sv" \
  --scope "${WAVE_SCOPE:-tb_tcm_chain12.soc.u_accel}" \
  --trigger "${WAVE_TRIGGER:-tb_tcm_chain12.soc.u_accel.u_core.start_valid}" \
  --start "${WAVE_START_NS:-0}" --duration "${WAVE_DURATION_NS:-100000}" --depth "${WAVE_DEPTH:-2}"
opts+=("$run/wave_dump.sv" -o "$run/build/simv" -l "$run/compile.log")
cd "$run/build"
"$python_bin" -c 'import json,sys; print(json.dumps(sys.argv[1:],indent=2))' "$vcs_bin" "${opts[@]}" > "$run/compile_command.json"
stage=compile
"$vcs_bin" "${opts[@]}" > "$run/compile_console.log" 2>&1
mkdir "$run/cases"
for case_id in "${cases[@]}"; do
  result="$run/cases/$case_id"
  stage="payload_$case_id"
  "$python_bin" "$base/tools/case_payload.py" --case "$case_id" --result "$result" > "$run/$stage.log" 2>&1
  cp -- "$run/build/firmware_itcm.hex" "$result/firmware_itcm.hex"
  [[ ! -d "$run/build/simv.daidir" ]] || ln -s "$run/build/simv.daidir" "$result/simv.daidir"
  cd "$result"
  sim_opts=("+CHAIN_LAYERS=$layers" -l simulation.log)
  [[ "${DUMP:-1}" != 0 ]] || sim_opts+=(+NO_WAVE)
  stage="simulation_$case_id"
  LD_LIBRARY_PATH="$run/build:$run/build/simv.daidir${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}" \
    "$run/build/simv" "${sim_opts[@]}" > simulation_console.log 2>&1
  [[ -f status.txt && "$(tr -d '\r\n' < status.txt)" == PASS ]]
  [[ -f export_status.txt && "$(tr -d '\r\n' < export_status.txt)" == PASS ]]
  stage="comparison_$case_id"
  "$python_bin" "$base/tools/compare_chain.py" --case "$case_id" --result "$result" --layers "$layers" > numerical_console.log 2>&1
  [[ "$(tr -d '\r\n' < numerical_status.txt)" == PASS ]]
  if [[ "${DUMP:-1}" != 0 ]]; then [[ -s wave.vcd ]]; fi
  grep -E 'PASS CPU_CHAIN_EXECUTION|PASS END_TO_END_FUNCTIONAL' simulation.log
  cat numerical_console.log
  printf 'PASS %s: %s\n' "$case_id" "$result"
done
if [[ "$mode" == global_batch10 ]]; then
  stage=aggregation
  "$python_bin" "$base/tools/aggregate_batch.py" --run "$run" > "$run/aggregate.log" 2>&1
  [[ "$(tr -d '\r\n' < "$run/batch_status.txt")" == PASS ]]
  cat "$run/aggregate.log"
fi
printf 'PASS\n' > "$run/runner_status.txt"
printf 'PASS %s\nResults: %s\n' "$mode" "$run"
