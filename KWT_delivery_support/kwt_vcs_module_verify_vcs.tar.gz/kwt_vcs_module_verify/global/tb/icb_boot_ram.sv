`timescale 1ns/1ps
// Verification-only 512 KiB shared memory behind the real platform ICB fabric.
// No SRAM macro/area claim for this shared-memory target.
module icb_boot_ram(
    input wire clk, rst_n,
    input wire cmd_valid, output wire cmd_ready,
    input wire [31:0] cmd_addr, cmd_wdata,
    input wire cmd_read, input wire [3:0] cmd_wmask,
    output reg rsp_valid=0, input wire rsp_ready,
    output reg [31:0] rsp_rdata=0, output reg rsp_err=0
);
    reg [31:0] mem[0:131071];
    reg pending=0;
    reg [31:0] saved_data=0, rng=32'h71234567;
    reg saved_error=0;
    integer delay_left=0, lane, index;
    assign cmd_ready=rst_n && !pending && !rsp_valid && (|rng[1:0]);
    initial for(index=0; index<131072; index=index+1) mem[index]=0;
    always @(posedge clk) begin
        if(!rst_n) begin pending<=0; rsp_valid<=0; delay_left<=0; end
        else begin
            rng<={rng[30:0],rng[31]^rng[21]^rng[1]^rng[0]};
            if(cmd_valid && cmd_ready) begin
                pending<=1; delay_left<=rng[4:2];
                saved_error<=cmd_addr<32'ha0000000 || cmd_addr>=32'ha0080000;
                if(cmd_addr>=32'ha0000000 && cmd_addr<32'ha0080000) begin
                    index=(cmd_addr-32'ha0000000)>>2;
                    saved_data<=mem[index];
                    if(!cmd_read) for(lane=0;lane<4;lane=lane+1)
                        if(cmd_wmask[lane]) mem[index][8*lane+:8]<=cmd_wdata[8*lane+:8];
                end else saved_data<=0;
            end
            if(pending) begin
                if(delay_left==0) begin
                    pending<=0; rsp_valid<=1; rsp_rdata<=saved_data; rsp_err<=saved_error;
                end else delay_left<=delay_left-1;
            end
            if(rsp_valid && rsp_ready) rsp_valid<=0;
        end
    end
endmodule
