`timescale 1ns/1ps
// Functional preflight for GENERIC_CLOCKGATE_RVT and the actual standard cell.
// Compile with +define+functional and WITHOUT FPGA or FPGA_SOURCE.
// The 12TR40 cell latches E while CK is low, then ORs SE outside the latch.
// This is not a claim that a latch of (E | SE) is equivalent for arbitrary SE.
module tb_clockgate_lib;
    reg ck = 1'b0;
    reg enable = 1'b0;
    reg test_enable = 1'b0;
    wire gated_clk;
    GENERIC_CLOCKGATE_RVT dut (
        .ECK(gated_clk), .E(enable), .SE(test_enable), .CK(ck)
    );

    reg reference_enable;
    wire reference_clk;
    always @(*) begin
        if (!ck) reference_enable = enable;
    end
    assign reference_clk = ck & (reference_enable | test_enable);

    reg armed = 1'b0;
    reg clock_transition = 1'b0;
    reg nonoperating_test_transition = 1'b0;
    integer actual_rises = 0, actual_falls = 0;
    integer reference_rises = 0, reference_falls = 0;
    integer checks = 0, status_fd;

    // Counts catch extra narrow pulses even if the final level settles correctly.
    always @(gated_clk) begin
        if (armed) begin
            if ($isunknown(gated_clk)) $fatal(1, "CLOCKGATE UNKNOWN OUTPUT");
            if (gated_clk) begin
                actual_rises = actual_rises + 1;
                if (ck !== 1'b1) $fatal(1, "CLOCKGATE RISE WHILE CK LOW");
            end else actual_falls = actual_falls + 1;
            if (!clock_transition && !nonoperating_test_transition)
                $fatal(1, "CLOCKGATE EXTRA EDGE WITH STABLE CK/SE at %0t", $time);
        end
    end

    always @(reference_clk) begin
        if (armed) begin
            if (reference_clk) reference_rises = reference_rises + 1;
            else reference_falls = reference_falls + 1;
        end
    end

    task check_settled;
        input [8*80-1:0] label;
        begin
            #2;
            checks = checks + 1;
            if (gated_clk !== reference_clk)
                $fatal(1, "CLOCKGATE LEVEL %0s CK=%b E=%b SE=%b actual=%b expected=%b",
                       label, ck, enable, test_enable, gated_clk, reference_clk);
            if (actual_rises != reference_rises || actual_falls != reference_falls)
                $fatal(1, "CLOCKGATE EDGE COUNT %0s actual=%0d/%0d expected=%0d/%0d",
                       label, actual_rises, actual_falls, reference_rises, reference_falls);
        end
    endtask

    task drive_clock;
        input value;
        begin
            clock_transition = 1'b1;
            ck = value;
            check_settled("clock transition");
            clock_transition = 1'b0;
        end
    endtask

    task drive_enable;
        input value;
        begin
            enable = value;
            check_settled("enable transition");
        end
    endtask

    task drive_test_low;
        input value;
        begin
            if (ck !== 1'b0) $fatal(1, "TB NORMAL SE UPDATE MUST OCCUR WHILE CK LOW");
            test_enable = value;
            check_settled("normal SE transition while CK low");
        end
    endtask

    initial begin
        status_fd = $fopen("clockgate_status.txt", "w");
        if (!status_fd) $fatal(1, "CANNOT OPEN clockgate_status.txt");
        $fdisplay(status_fd, "INCOMPLETE");
        $fclose(status_fd);
        // Exercise the low-transparent latch before arming any edge monitors.
        // Do not rely on simulator-specific time-zero always @(*) evaluation.
        #1; enable = 1'b1;
        #1; enable = 1'b0;
        #2;
        if (gated_clk !== 1'b0 || reference_clk !== 1'b0)
            $fatal(1, "CLOCKGATE DID NOT INITIALIZE LOW");
        armed = 1'b1;

        // SE=0: disabled clock, then low-phase enable captures the next pulse.
        drive_clock(1); drive_clock(0);
        drive_enable(1);
        drive_clock(1);
        // E may fall or pulse during CK high without shortening this high pulse.
        drive_enable(0); drive_enable(1); drive_enable(0);
        drive_clock(0);
        drive_clock(1); // E=0 was captured; no clock pulse is allowed.
        // Pulsing E during CK high must not open a previously closed gate.
        drive_enable(1); drive_enable(0);
        // A held high-phase E update becomes effective only after CK goes low.
        drive_enable(1);
        drive_clock(0); drive_clock(1);
        drive_enable(0);
        drive_clock(0); drive_clock(1); drive_clock(0);
        $display("CLOCKGATE checked SE=0 low-latch and high-phase E immunity");

        // SE=1 is the stable bypass used by tb_kwt_platform (.test_mode(1'b1)).
        // Normal SE updates are restricted to the low clock phase.
        drive_test_low(1);
        drive_clock(1); drive_enable(1); drive_enable(0); drive_clock(0);
        drive_clock(1); drive_clock(0);
        drive_enable(1); drive_clock(1); drive_enable(0); drive_clock(0);
        drive_test_low(0);
        drive_clock(1); drive_clock(0);
        drive_enable(1); drive_clock(1); drive_clock(0);
        drive_enable(0);
        $display("CLOCKGATE checked stable SE=1 bypass and low-phase SE changes");

        // Deliberately NONOPERATING characterization: SE is outside the E latch.
        // Changing SE during CK high directly creates/ends a high output interval.
        // Do not use these transitions as a glitch-free operational sequence.
        drive_clock(1);
        nonoperating_test_transition = 1'b1;
        test_enable = 1'b1; check_settled("nonoperating SE rise while CK high");
        test_enable = 1'b0; check_settled("nonoperating SE fall while CK high");
        test_enable = 1'b1; check_settled("nonoperating SE rise repeated");
        drive_clock(0);
        drive_test_low(0);
        nonoperating_test_transition = 1'b0;
        drive_clock(1); drive_clock(0);
        $display("CLOCKGATE characterized direct SE path; high-phase SE changes are nonoperating");

        if (checks < 40 || reference_rises < 8 || actual_rises != actual_falls)
            $fatal(1, "CLOCKGATE TEST COVERAGE/FINAL PULSE COUNT");
        status_fd = $fopen("clockgate_status.txt", "w");
        if (!status_fd) $fatal(1, "CANNOT WRITE clockgate_status.txt");
        $fdisplay(status_fd, "PASS");
        $fclose(status_fd);
        $display("PASS CLOCKGATE_LIB checks=%0d rises=%0d falls=%0d", checks, actual_rises, actual_falls);
        $finish;
    end

    initial begin
        #2000;
        $fatal(1, "CLOCKGATE WATCHDOG");
    end
endmodule
