`timescale 1ns/1ps
// Verification-only execution/export test. No numerical golden data is loaded.
// PASS confirms execution, bus/output integrity and export, not model accuracy.
`include "e203_defines.v"
`define ITCM soc.u_main.u_e203_cpu_top.u_e203_srams.u_e203_itcm_ram.u_kwt_tcm
module tb_tcm_chain12;
    reg clk=0;always #50 clk=~clk;
    reg rst_n=0;wire irq,unexpected;wire [31:0] pc;
    wire bus_clk,bus_rst_n,cpu_irq;
    wire s_cmd_valid;
    wire s_cmd_ready;
    wire [31:0] s_cmd_addr;
    wire s_cmd_read;
    wire [31:0] s_cmd_wdata;
    wire [3:0] s_cmd_wmask;
    wire s_rsp_valid;
    wire s_rsp_ready;
    wire [31:0] s_rsp_rdata;
    wire s_rsp_err;
    reg l_cmd_valid=0,l_cmd_read=0;
    wire l_cmd_ready,l_rsp_valid,l_rsp_err;
    reg [31:0] l_cmd_addr=0,l_cmd_wdata=0;
    wire [31:0] l_rsp_rdata;
    reg [31:0] input_image[0:3167],param_image[0:13311];
    reg [63:0] firmware[0:32767];
    reg load_clk=0,load_cs=0,load_we=0;
    reg [14:0] load_addr=0;
    reg [7:0] load_wem=0;
    reg [63:0] load_data=0;
    reg loading_done=0,high_pc_seen=0,d_last_write=0,lheld=0;
    reg [64:0] lheld_payload;
    integer loader_requests=0,loader_responses=0,loader_collisions=0,cpu_ready_reads_before_load=0;
    integer loader_payload_writes=0,loader_ready_writes=0,loader_request_reads=0;
    integer ready_epoch=0,completed_layers=0,request_epoch=0;
    integer target_requests=0,target_responses=0,last_write_cycle=-1,load_first_cycle=-1;
    realtime load_first_ns=-1,last_write_ns=-1;
    kwt_platform_soc soc(.clk(clk),.rst_n(rst_n),.test_mode(1'b1),
        .irq(irq),.cpu_irq(cpu_irq),.inspect_pc(pc),.unexpected_bus(unexpected),
        .bus_clk(bus_clk),.bus_rst_n(bus_rst_n),
        .l_cmd_valid(l_cmd_valid),.l_cmd_ready(l_cmd_ready),
        .l_cmd_addr(l_cmd_addr),.l_cmd_read(l_cmd_read),.l_cmd_wdata(l_cmd_wdata),.l_cmd_wmask(4'hf),
        .l_rsp_valid(l_rsp_valid),.l_rsp_ready(1'b1),.l_rsp_rdata(l_rsp_rdata),.l_rsp_err(l_rsp_err),
        .s_cmd_valid(s_cmd_valid),.s_cmd_ready(s_cmd_ready),
        .s_cmd_addr(s_cmd_addr),.s_cmd_read(s_cmd_read),
        .s_cmd_wdata(s_cmd_wdata),.s_cmd_wmask(s_cmd_wmask),
        .s_rsp_valid(s_rsp_valid),.s_rsp_ready(s_rsp_ready),
        .s_rsp_rdata(s_rsp_rdata),.s_rsp_err(s_rsp_err));
    icb_boot_ram shared_ram(.clk(bus_clk),.rst_n(bus_rst_n),
        .cmd_valid(s_cmd_valid),
        .cmd_ready(s_cmd_ready),
        .cmd_addr(s_cmd_addr),
        .cmd_read(s_cmd_read),
        .cmd_wdata(s_cmd_wdata),
        .cmd_wmask(s_cmd_wmask),
        .rsp_valid(s_rsp_valid),
        .rsp_ready(s_rsp_ready),
        .rsp_rdata(s_rsp_rdata),
        .rsp_err(s_rsp_err));
    reg [15:0] actual_ln[0:76031];
    reg actual_seen[0:76031],ff_seen[0:76031];
    reg [31:0] ram_hash;
    integer start_cycle=-1,irq_cycle=-1;
    integer plic_claims=0,plic_completes=0,cpu_irq_rises=0;
    reg cpu_irq_prev=0;
    integer dump_layer,dump_index,dump_fd;
    integer cycles=0,cpu_requests=0,cpu_responses=0,dma_reads=0,dma_writes=0,dma_responses=0;
    integer collisions=0,starts=0,irq_rises=0,irq_clears=0,shared_stalls=0;
    wire [31:0] active_output_base=starts[0]?32'ha0004000:32'ha0000000;
    wire [31:0] active_input_base=starts[0]?32'ha0000000:32'ha0004000;
    integer layers=12,i,j,idx,fd,ln_checks=0,ff_checks=0,layer_starts=0;
    integer weight_beats=0,param_beats=0,stage_count=0,overlap_cycles=0;
    reg report_done=0,irq_prev=0,held=0,dheld=0;
    reg [31:0] cpu_last_addr=0,cpu_last_data=0;
    reg cpu_last_write=0;
    reg [68:0] held_payload,dheld_payload;
    string filename;
    always @(posedge bus_clk)begin
        if(!bus_rst_n)begin report_done<=0;irq_prev<=0;cpu_irq_prev<=0;held<=0;dheld<=0;end
        else begin
            cycles=cycles+1;irq_prev<=irq;cpu_irq_prev<=cpu_irq;
            if(cycles>60000000)$fatal(1,"INFERENCE_TIMEOUT pc=%h",pc);
            if(pc>=32'h80020000&&pc<32'h80021000)high_pc_seen=1;
            if(soc.u_main.mem_icb_cmd_valid&&l_cmd_valid)loader_collisions=loader_collisions+1;
            if(lheld&&(!l_cmd_valid||{l_cmd_addr,l_cmd_wdata,l_cmd_read}!==lheld_payload))
                $fatal(1,"LOADER_CHANGED_STALLED_COMMAND");
            lheld<=l_cmd_valid&&!l_cmd_ready;
            lheld_payload<={l_cmd_addr,l_cmd_wdata,l_cmd_read};
            if(l_cmd_valid&&l_cmd_ready)begin
                loader_requests=loader_requests+1;
                if(l_cmd_read)begin
                    if(l_cmd_addr!=32'ha007d004)$fatal(1,"LOADER_READ_ADDRESS");
                    loader_request_reads=loader_request_reads+1;
                end else if(l_cmd_addr==32'ha007d000)begin
                    if(l_cmd_wdata!=completed_layers+1)$fatal(1,"LOADER_READY_EPOCH");
                    loader_ready_writes=loader_ready_writes+1;
                end else begin
                    if(starts!=completed_layers)$fatal(1,"LOADER_OVERWRITES_LIVE_PARAMETERS");
                    if(l_cmd_addr<32'ha0003180)begin
                        if(starts!=0||l_cmd_addr<32'ha0000000)$fatal(1,"LOADER_REPLACES_CHAIN_INPUT");
                    end else if(l_cmd_addr<32'ha0010000||l_cmd_addr>=32'ha001d000)
                        $fatal(1,"LOADER_PAYLOAD_ADDRESS");
                    loader_payload_writes=loader_payload_writes+1;
                end
            end
            if(l_rsp_valid)begin
                if(l_rsp_err)$fatal(1,"LOADER_RESPONSE_ERROR");
                loader_responses=loader_responses+1;
            end
            if(cpu_irq&&!cpu_irq_prev)cpu_irq_rises=cpu_irq_rises+1;
            if(unexpected)$fatal(1,"UNEXPECTED CPU PORT pc=%h",pc);
            if(irq&&!irq_prev)begin irq_cycle=cycles;irq_rises=irq_rises+1;$display("IRQ ASSERT cycles=%0d",cycles);end
            if(soc.u_main.mem_icb_cmd_valid&&soc.d_cmd_valid)collisions=collisions+1;
            if(s_cmd_valid&&!s_cmd_ready)shared_stalls=shared_stalls+1;
            if(held&&(!s_cmd_valid||{s_cmd_addr,s_cmd_wdata,s_cmd_read,s_cmd_wmask}!==held_payload))
                $fatal(1,"ARBITER CHANGED STALLED COMMAND");
            held<=s_cmd_valid&&!s_cmd_ready;
            held_payload<={s_cmd_addr,s_cmd_wdata,s_cmd_read,s_cmd_wmask};
            if(dheld&&(!soc.d_cmd_valid||{soc.d_cmd_addr,soc.d_cmd_wdata,soc.d_cmd_read,soc.d_cmd_wmask}!==dheld_payload))
                $fatal(1,"DMA CHANGED STALLED COMMAND");
            dheld<=soc.d_cmd_valid&&!soc.d_cmd_ready;
            dheld_payload<={soc.d_cmd_addr,soc.d_cmd_wdata,soc.d_cmd_read,soc.d_cmd_wmask};
            if(s_cmd_valid&&s_cmd_ready)begin
                target_requests=target_requests+1;
                if($isunknown({s_cmd_addr,s_cmd_read,s_cmd_wmask}))$fatal(1,"UNKNOWN SHARED COMMAND");
                if(s_cmd_addr<32'ha0000000||s_cmd_addr>=32'ha0080000||s_cmd_addr[1:0]!=0)$fatal(1,"SHARED ADDRESS");
            end
            if(s_rsp_valid&&s_rsp_ready)begin
                target_responses=target_responses+1;
                if(s_rsp_err)$fatal(1,"SHARED BUS ERROR");
            end
            if(soc.d_cmd_valid&&soc.d_cmd_ready)begin
                if(ready_epoch!=starts||starts<1)$fatal(1,"DMA_BEFORE_EPOCH_READY");
                d_last_write<=!soc.d_cmd_read;
                if(soc.d_cmd_read)begin
                    if(!((soc.d_cmd_addr>=active_input_base&&soc.d_cmd_addr<active_input_base+32'h3180)||
                         (soc.d_cmd_addr>=32'ha0010000&&soc.d_cmd_addr<32'ha001d000)))
                        $fatal(1,"DMA_INPUT_OR_PARAM_ADDRESS");
                    dma_reads=dma_reads+1;
                end
                else begin
                    dma_writes=dma_writes+1;
                    if(soc.d_cmd_addr<active_output_base||soc.d_cmd_addr>=active_output_base+32'h3180||soc.d_cmd_wmask!=15)
                        $fatal(1,"DMA OUTPUT ADDRESS");
                end
            end
            if(soc.d_rsp_valid&&soc.d_rsp_ready)begin
                if(soc.d_rsp_err)$fatal(1,"DMA RESPONSE ERROR");
                dma_responses=dma_responses+1;
                if(d_last_write&&dma_writes==3168*starts)begin
                    last_write_cycle=cycles;last_write_ns=$realtime;
                end
            end
            if(soc.u_main.mem_icb_cmd_valid&&soc.u_main.mem_icb_cmd_ready)begin
                cpu_requests=cpu_requests+1;
                if(ready_epoch<starts+1&&soc.u_main.mem_icb_cmd_read&&soc.u_main.mem_icb_cmd_addr==32'ha007d000)
                    cpu_ready_reads_before_load=cpu_ready_reads_before_load+1;
                cpu_last_addr<=soc.u_main.mem_icb_cmd_addr;
                cpu_last_data<=soc.u_main.mem_icb_cmd_wdata;
                cpu_last_write<=!soc.u_main.mem_icb_cmd_read;
                if(!soc.u_main.mem_icb_cmd_read)begin
                    if(soc.u_main.mem_icb_cmd_wmask!=15 ||
                       !((soc.u_main.mem_icb_cmd_addr==32'ha007e000)||
                         (soc.u_main.mem_icb_cmd_addr==32'ha007d004)||
                         (soc.u_main.mem_icb_cmd_addr>=32'ha007f000&&soc.u_main.mem_icb_cmd_addr<=32'ha007f028)||
                         (soc.u_main.mem_icb_cmd_addr>=32'ha007f100&&soc.u_main.mem_icb_cmd_addr<32'ha007f130)))
                        $fatal(1,"CPU SHARED WRITE ADDRESS %h",soc.u_main.mem_icb_cmd_addr);
                end
            end
            if(soc.u_main.mem_icb_rsp_valid&&soc.u_main.mem_icb_rsp_ready)begin
                if(soc.u_main.mem_icb_rsp_err)$fatal(1,"CPU MEM RESPONSE ERROR");
                cpu_responses=cpu_responses+1;
                if(cpu_last_write&&cpu_last_addr==32'ha007d004&&cpu_last_data!=0)begin
                    if(cpu_last_data!=completed_layers+1||cpu_last_data>layers)$fatal(1,"CPU_REQUEST_EPOCH");
                    request_epoch=cpu_last_data;
                end
                if(cpu_last_write&&cpu_last_addr==32'ha007f028&&cpu_last_data!=0)begin
                    if(cpu_last_data!=completed_layers+1||cpu_last_data!=starts)$fatal(1,"CPU_COMPLETION_EPOCH");
                    export_layer(cpu_last_data);
                    completed_layers=cpu_last_data;
                end
                if(cpu_last_write&&cpu_last_addr==32'ha007f024&&
                   (cpu_last_data==32'h50415353||cpu_last_data==32'h4641494c))report_done<=1;
            end
            if(soc.u_main.plic_icb_cmd_valid&&soc.u_main.plic_icb_cmd_ready&&
               soc.u_main.plic_icb_cmd_addr==32'h0c200004)begin
                if(soc.u_main.plic_icb_cmd_read)plic_claims=plic_claims+1;
                else begin
                    if(soc.u_main.plic_icb_cmd_wdata!=17)$fatal(1,"PLIC COMPLETE ID");
                    plic_completes=plic_completes+1;
                end
            end
            if(soc.a_cmd_valid&&soc.a_cmd_ready&&!soc.a_cmd_read)begin
                if(soc.a_cmd_addr[11:0]==4&&soc.a_cmd_wdata[0])begin
                    if(ready_epoch!=starts+1||request_epoch!=starts+1||starts!=completed_layers)$fatal(1,"CPU_START_BEFORE_EPOCH_READY");
                    starts=starts+1;start_cycle=cycles;
                end
                if(soc.a_cmd_addr[11:0]==8&&soc.a_cmd_wdata[1])irq_clears=irq_clears+1;
            end
      if(soc.u_accel.error)$fatal(1,"RUN ERROR %h",soc.u_accel.error_code);
      if(soc.u_accel.ls&&soc.u_accel.lr)layer_starts=layer_starts+1;
      if(soc.u_accel.wl)weight_beats=weight_beats+1;
      if(soc.u_accel.pl)param_beats=param_beats+1;
      if(soc.u_accel.u_run.dbusy&&soc.u_accel.cbusy)overlap_cycles=overlap_cycles+1;
      if(soc.u_accel.ae+{1'b0,soc.u_accel.be}+{1'b0,soc.u_accel.ve}>1)$fatal(1,"ACT READ COLLISION");
      if((soc.u_accel.ae||soc.u_accel.be||soc.u_accel.ve)&&(soc.u_accel.ce||soc.u_accel.xe||soc.u_accel.de))$fatal(1,"ACT RW COLLISION");
      if(soc.u_accel.we&&soc.u_accel.wa<20'h18000&&soc.u_accel.wl&&soc.u_accel.active_bank==soc.u_accel.wb)$fatal(1,"LIVE WEIGHT OVERWRITE");
      if(soc.u_accel.pl&&(soc.u_accel.pe||(soc.u_accel.we&&soc.u_accel.wa>=20'h18000)))$fatal(1,"PARAM COLLISION");
      if(soc.u_accel.ae&&(soc.u_accel.aa>=18'h20000||soc.u_accel.aa[2:0]!=0))$fatal(1,"A ADDR");
      if(soc.u_accel.be&&(soc.u_accel.ba>=18'h20000||soc.u_accel.ba[2:0]!=0))$fatal(1,"B ADDR");
      if(soc.u_accel.ve&&(soc.u_accel.va>=18'h20000||soc.u_accel.va[5:0]!=0))$fatal(1,"V ADDR");
      if(soc.u_accel.ce&&soc.u_accel.cr)begin
        if(soc.u_accel.ca>=18'h20000||soc.u_accel.ca[4:0]!=0)$fatal(1,"C ADDR");
        if(soc.u_accel.stage==15)for(j=0;j<8;j=j+1)if(soc.u_accel.cs[j*4+:4]==15)begin
          idx=(starts-1)*6336+((soc.u_accel.ca-18'h12000)>>2)+j;
          if(idx<0||idx>=6336*layers)$fatal(1,"FFN2 INDEX OUT OF RANGE %0d",idx);
          if(ff_seen[idx])$fatal(1,"DUPLICATE FFN2 WRITE index=%0d",idx);
          if($isunknown(soc.u_accel.cd[j*32+:32]))$fatal(1,"UNKNOWN FFN2 WRITE index=%0d",idx);
          if(&soc.u_accel.cd[j*32+23+:8])$fatal(1,"NONFINITE FFN2 index=%0d",idx);
          ff_seen[idx]=1'b1;
          ff_checks=ff_checks+1;
        end
      end
      if(soc.u_accel.xe&&soc.u_accel.xr)begin
        if(soc.u_accel.xa>=18'h20000||soc.u_accel.xa[5:0]!=0)$fatal(1,"V WRITE ADDR");
        if(soc.u_accel.stage==16)for(j=0;j<32;j=j+1)if(soc.u_accel.xs[j*2+:2]==3)begin
          idx=(starts-1)*6336+(soc.u_accel.xa>>1)+j;
          if(idx<0||idx>=6336*layers)$fatal(1,"EXPORT INDEX OUT OF RANGE %0d",idx);
          if(actual_seen[idx])$fatal(1,"DUPLICATE LN2 WRITE index=%0d",idx);
          if($isunknown(soc.u_accel.xd[j*16+:16]))$fatal(1,"UNKNOWN LN2 WRITE index=%0d",idx);
          if(&soc.u_accel.xd[j*16+10+:5])$fatal(1,"NONFINITE LN2 index=%0d",idx);
          actual_ln[idx]=soc.u_accel.xd[j*16+:16];
          actual_seen[idx]=1'b1;
          ln_checks=ln_checks+1;
        end
      end
      if(soc.u_accel.stage_done)begin
        stage_count=stage_count+1;
        if(soc.u_accel.stage==16)$display("LAYER %0d EXECUTED cycles=%0d",starts,cycles);
      end
        end
    end
    // Check and save each layer before ping-pong can overwrite its output.
    task export_layer(input integer epoch);
        integer n,index,base_word,out_fd;
        reg [31:0] hash;
        string out_name;
        begin
            if(dma_reads!=16362*epoch||dma_writes!=3168*epoch||dma_responses!=19530*epoch)
                $fatal(1,"PER_LAYER_DMA_COUNTS epoch=%0d",epoch);
            if(irq_rises!=epoch||irq_clears!=epoch||plic_claims!=epoch||plic_completes!=epoch||irq||soc.u_accel.busy)
                $fatal(1,"PER_LAYER_IRQ_COMPLETION epoch=%0d",epoch);
            base_word=(epoch%2)?'h1000:0;
            hash=32'd2166136261;
            if(epoch<10)out_name=$sformatf("layer_0%0d_output_u32.hex",epoch);
            else out_name=$sformatf("layer_%0d_output_u32.hex",epoch);
            out_fd=$fopen(out_name,"w");if(!out_fd)$fatal(1,"CANNOT_OPEN_LAYER_OUTPUT");
            for(n=0;n<3168;n=n+1)begin
                index=(epoch-1)*6336+2*n;
                if(!actual_seen[index]||!actual_seen[index+1]||!ff_seen[index]||!ff_seen[index+1])
                    $fatal(1,"LAYER_ELEMENT_MISSING epoch=%0d word=%0d",epoch,n);
                if(shared_ram.mem[base_word+n]!=={actual_ln[index+1],actual_ln[index]})
                    $fatal(1,"LAYER_DMA_OUTPUT_DIFFERS epoch=%0d word=%0d",epoch,n);
                hash=(hash^shared_ram.mem[base_word+n])*32'd16777619;
                $fdisplay(out_fd,"%08h",shared_ram.mem[base_word+n]);
            end
            $fclose(out_fd);
            if(shared_ram.mem['h1fc40+epoch-1]!==hash)$fatal(1,"CPU_LAYER_HASH epoch=%0d",epoch);
            $display("PASS CPU_LAYER_COMPLETED epoch=%0d output_base=%h hash=%h",epoch,32'ha0000000+4*base_word,hash);
        end
    endtask
    // Requests traverse the extra master arbiter, CPU/DMA arbiter and MEM fabric.
    task loader_transfer(input bit is_read,input [31:0] address,input [31:0] value,output reg [31:0] result);
        begin
            @(negedge clk);
            l_cmd_addr=address;l_cmd_wdata=value;l_cmd_read=is_read;l_cmd_valid=1;
            if(!is_read&&load_first_ns<0&&address!=32'ha007d000)begin
                load_first_ns=$realtime;load_first_cycle=cycles+1;
            end
            @(posedge clk);while(!l_cmd_ready)@(posedge clk);
            @(negedge clk);l_cmd_valid=0;
            @(posedge clk);while(!l_rsp_valid)@(posedge clk);
            if(l_rsp_err)$fatal(1,"LOAD_FAILED address=%h",address);
            result=l_rsp_rdata;
            @(negedge clk);
        end
    endtask
    task load_chain;
        integer n,epoch;
        reg [31:0] response;
        string param_file;
        begin
            $readmemh("input.hex",input_image);
            for(n=0;n<3168;n=n+1)if($isunknown(input_image[n]))$fatal(1,"INPUT_IMAGE_INCOMPLETE %0d",n);
            wait(bus_rst_n);repeat(30)@(negedge clk);
            for(epoch=1;epoch<=layers;epoch=epoch+1)begin
                response=0;
                while(response!=epoch)begin
                    loader_transfer(1'b1,32'ha007d004,0,response);
                    if($isunknown(response)||response>epoch)$fatal(1,"INVALID_REQUEST_SEQUENCE %h",response);
                    if(response!=epoch)repeat(256)@(negedge clk);
                end
                if(completed_layers!=epoch-1)$fatal(1,"HOST_REQUEST_BEFORE_COMPLETION");
                if(epoch==1)begin
                    for(n=0;n<3168;n=n+1)loader_transfer(1'b0,32'ha0000000+4*n,input_image[n],response);
                    for(n=0;n<3168;n=n+1)if(shared_ram.mem[n]!==input_image[n])$fatal(1,"INPUT_LOAD_MISMATCH %0d",n);
                end
                if(epoch<10)param_file=$sformatf("params_0%0d.hex",epoch);
                else param_file=$sformatf("params_%0d.hex",epoch);
                for(n=0;n<13312;n=n+1)param_image[n]=32'hxxxxxxxx;
                $readmemh(param_file,param_image);
                for(n=0;n<13312;n=n+1)if($isunknown(param_image[n]))$fatal(1,"PARAM_IMAGE_INCOMPLETE epoch=%0d word=%0d",epoch,n);
                for(n=0;n<13312;n=n+1)loader_transfer(1'b0,32'ha0010000+4*n,param_image[n],response);
                for(n=0;n<13312;n=n+1)if(shared_ram.mem['h4000+n]!==param_image[n])$fatal(1,"PARAM_LOAD_MISMATCH epoch=%0d word=%0d",epoch,n);
                loader_transfer(1'b0,32'ha007d000,epoch,response);
                ready_epoch=epoch;
                $display("PASS ICB_LAYER_LOAD epoch=%0d requests=%0d responses=%0d",epoch,loader_requests,loader_responses);
            end
            loading_done=1;
        end
    endtask
    initial load_chain();
    initial begin
        for(dump_index=0;dump_index<76032;dump_index=dump_index+1)begin
            actual_seen[dump_index]=1'b0;ff_seen[dump_index]=1'b0;
        end
        dump_fd=$fopen("export_status.txt","w");
        if(dump_fd==0)$fatal(1,"CANNOT OPEN export_status.txt");
        $fdisplay(dump_fd,"INCOMPLETE");$fclose(dump_fd);
        fd=$fopen("status.txt","w");$fdisplay(fd,"INCOMPLETE");$fclose(fd);
        if(!$value$plusargs("CHAIN_LAYERS=%d",layers))layers=12;
        if(layers<1||layers>12)$fatal(1,"INVALID_CHAIN_LAYERS");
`ifdef FPGA
        $fatal(1,"FPGA_DEFINE_NOT_ALLOWED");
`endif
`ifdef E203_HAS_ECC
        $fatal(1,"ECC_INTERFACE_REQUIRES_SEPARATE_ADAPTATION");
`endif
        $display("TCM_EFFECTIVE_CONFIG ITCM_AW=%0d DW=%0d MW=%0d DTCM_AW=%0d DW=%0d MW=%0d ECC=0",
            `E203_ITCM_RAM_AW,`E203_ITCM_RAM_DW,`E203_ITCM_RAM_MW,
            `E203_DTCM_RAM_AW,`E203_DTCM_RAM_DW,`E203_DTCM_RAM_MW);
        if(`E203_ITCM_RAM_AW!=15 || `E203_ITCM_RAM_DW!=64 || `E203_ITCM_RAM_MW!=8 ||
           `E203_DTCM_RAM_AW!=16 || `E203_DTCM_RAM_DW!=32 || `E203_DTCM_RAM_MW!=4)
            $fatal(1,"UNEXPECTED_EFFECTIVE_TCM_WIDTH");
        $readmemh("firmware_itcm.hex",firmware);
        for(i=0;i<32768;i=i+1) if($isunknown(firmware[i])) $fatal(1,"INCOMPLETE_FIRMWARE_IMAGE word=%0d",i);

        // Verification-only boot setup with CPU held in reset. Never force a
        // macro's internal array. All forces are removed before CPU execution.
        #1;
        force `ITCM.CLK=load_clk;
        force `ITCM.RSTN=1'b1;
        force `ITCM.CS=load_cs;
        force `ITCM.WE=load_we;
        force `ITCM.ADDRESS=load_addr;
        force `ITCM.WEM=load_wem;
        force `ITCM.WDATA=load_data;
        load_cs=1; load_we=1; load_wem=8'hff;
        for(i=0;i<32768;i=i+1) begin
            load_addr=i; load_data=firmware[i];
            #50; load_clk=1; #50; load_clk=0;
        end
        load_we=0; load_wem=0;
        for(i=0;i<32768;i=i+1) begin
            load_addr=i;
            #50; load_clk=1; #25;
            if(`ITCM.RDATA !== firmware[i])
                $fatal(1,"PRELOAD_READBACK_FAIL word=%0d expected=%h got=%h",i,firmware[i],`ITCM.RDATA);
            #25; load_clk=0;
        end
        load_cs=0;
        #50;
        release `ITCM.CLK;
        release `ITCM.RSTN;
        release `ITCM.CS;
        release `ITCM.WE;
        release `ITCM.ADDRESS;
        release `ITCM.WEM;
        release `ITCM.WDATA;
        $display("PASS ITCM_PORT_PRELOAD words=32768 readback=32768");
        repeat(20) @(negedge clk);
        rst_n=1;
        wait(report_done);@(negedge clk);
        if(shared_ram.mem['h1fc09]!==32'h50415353||shared_ram.mem['h1fc06]!==0)
            $fatal(1,"FIRMWARE FAIL code=%h mcause=%h mepc=%h hash=%h",shared_ram.mem['h1fc06],shared_ram.mem['h1fc07],shared_ram.mem['h1fc08],shared_ram.mem['h1fc04]);
        if(starts!=layers||irq_rises!=layers||irq_clears!=layers||irq||soc.u_accel.busy)$fatal(1,"START/IRQ/IDLE COUNTS");
        if(shared_ram.mem['h1fc01]!==layers||shared_ram.mem['h1fc03]!==layers||shared_ram.mem['h1fc00]!==2||shared_ram.mem['h1fc05]!==17)$fatal(1,"CPU IRQ REPORT");
        if(plic_claims!=layers||plic_completes!=layers||cpu_irq_rises!=layers||cpu_irq)$fatal(1,"PLIC IRQ PATH COUNTS");
        if(layer_starts!=layers||stage_count!=17*layers||weight_beats!=12288*layers||param_beats!=898*layers||
           ln_checks!=6336*layers||ff_checks!=6336*layers||dma_writes!=3168*layers||dma_reads!=16362*layers)$fatal(1,"INFERENCE COUNTS");
        if(dma_responses!=dma_reads+dma_writes||cpu_requests!=cpu_responses||cpu_requests<=3168||collisions==0||shared_stalls==0)$fatal(1,"ARBITRATION COUNTS");
        if(!high_pc_seen||!loading_done||completed_layers!=layers||loader_ready_writes!=layers||
           loader_payload_writes!=3168+13312*layers||loader_request_reads<layers||
           loader_requests!=loader_payload_writes+loader_ready_writes+loader_request_reads||
           loader_responses!=loader_requests||cpu_ready_reads_before_load==0)
            $fatal(1,"LOADER_OR_CPU_COVERAGE requests=%0d responses=%0d ready_polls=%0d high_pc=%b",loader_requests,loader_responses,cpu_ready_reads_before_load,high_pc_seen);
        if(target_requests!=cpu_requests+dma_reads+dma_writes+loader_requests||target_responses!=target_requests)
            $fatal(1,"FABRIC_COMMAND_RESPONSE_ACCOUNTING");
        if(last_write_cycle<start_cycle||load_first_ns<0||last_write_ns<=load_first_ns)
            $fatal(1,"INVALID_END_TO_END_MEASUREMENT");
        // Check CPU-read result hash against independently read actual shared RAM.
        ram_hash=32'd2166136261;
        for(dump_index=0;dump_index<3168;dump_index=dump_index+1)
            ram_hash=(ram_hash^shared_ram.mem[(layers%2?'h1000:0)+dump_index])*32'd16777619;
        if(shared_ram.mem['h1fc04]!==ram_hash)$fatal(1,"CPU / SHARED RAM HASH MISMATCH cpu=%h ram=%h",shared_ram.mem['h1fc04],ram_hash);
        // Export after execution and bus-integrity checks; no accuracy assertion.
        for(dump_index=0;dump_index<6336*layers;dump_index=dump_index+1)begin
            if(actual_seen[dump_index]!==1'b1)$fatal(1,"MISSING LN2 WRITE index=%0d",dump_index);
            if(ff_seen[dump_index]!==1'b1)$fatal(1,"MISSING FFN2 WRITE index=%0d",dump_index);
        end
        for(dump_index=0;dump_index<3168;dump_index=dump_index+1)
            if(shared_ram.mem[(layers%2?'h1000:0)+dump_index]!==
               {actual_ln[(layers-1)*6336+2*dump_index+1],actual_ln[(layers-1)*6336+2*dump_index]})
                $fatal(1,"EXPORTED LN2 / SHARED OUTPUT DIFFER index=%0d",dump_index);
        for(dump_layer=0;dump_layer<layers;dump_layer=dump_layer+1)begin
            if(dump_layer<9)filename=$sformatf("layer_0%0d_ln2.hex",dump_layer+1);
            else filename=$sformatf("layer_%0d_ln2.hex",dump_layer+1);
            dump_fd=$fopen(filename,"w");
            if(dump_fd==0)$fatal(1,"CANNOT OPEN %s",filename);
            for(dump_index=0;dump_index<6336;dump_index=dump_index+1)
                $fdisplay(dump_fd,"%04h",actual_ln[dump_layer*6336+dump_index]);
            $fclose(dump_fd);
        end
        dump_fd=$fopen("final_output_u32.hex","w");
        if(dump_fd==0)$fatal(1,"CANNOT OPEN final_output_u32.hex");
        for(dump_index=0;dump_index<3168;dump_index=dump_index+1)
            $fdisplay(dump_fd,"%08h",shared_ram.mem[(layers%2?'h1000:0)+dump_index]);
        $fclose(dump_fd);
        dump_fd=$fopen("execution.json","w");
        if(dump_fd==0)$fatal(1,"CANNOT OPEN execution.json");
        $fdisplay(dump_fd,"{");
        $fdisplay(dump_fd,"  \"execution_status\": \"PASS\",");
        $fdisplay(dump_fd,"  \"numerical_accuracy_checked\": false,");
        $fdisplay(dump_fd,"  \"layers\": %0d,",layers);
        $fdisplay(dump_fd,"  \"mode\": \"cpu_scheduled_single_layer_chain\",");
        $fdisplay(dump_fd,"  \"hardware_layers_per_start\": 1,");
        $fdisplay(dump_fd,"  \"completed_layers\": %0d,",completed_layers);
        $fdisplay(dump_fd,"  \"final_output_base_hex\": \"%08h\",",32'ha0000000+(layers%2?32'h4000:0));
        $fdisplay(dump_fd,"  \"irq_rises\": %0d,",irq_rises);
        $fdisplay(dump_fd,"  \"irq_clears\": %0d,",irq_clears);
        $fdisplay(dump_fd,"  \"layer_starts\": %0d,",layer_starts);
        $fdisplay(dump_fd,"  \"weight_beats\": %0d,",weight_beats);
        $fdisplay(dump_fd,"  \"param_beats\": %0d,",param_beats);
        $fdisplay(dump_fd,"  \"stage_count\": %0d,",stage_count);
        $fdisplay(dump_fd,"  \"ln_checks\": %0d,",ln_checks);
        $fdisplay(dump_fd,"  \"ff_checks\": %0d,",ff_checks);
        $fdisplay(dump_fd,"  \"dma_responses\": %0d,",dma_responses);
        $fdisplay(dump_fd,"  \"loader_payload_writes\": %0d,",loader_payload_writes);
        $fdisplay(dump_fd,"  \"loader_ready_writes\": %0d,",loader_ready_writes);
        $fdisplay(dump_fd,"  \"loader_request_reads\": %0d,",loader_request_reads);
        $fdisplay(dump_fd,"  \"clock_period_ns\": 100,");
        $fdisplay(dump_fd,"  \"shared_bytes\": 524288,");
        $fdisplay(dump_fd,"  \"shared_target\": \"behavioral_ICB_random_wait\",");
        $fdisplay(dump_fd,"  \"loader_path\": \"external_loader/extra_arb/CPU_DMA_arb/MEM_fabric/shared_target\",");
        $fdisplay(dump_fd,"  \"loader_requests\": %0d,",loader_requests);
        $fdisplay(dump_fd,"  \"loader_responses\": %0d,",loader_responses);
        $fdisplay(dump_fd,"  \"loader_contention_cycles\": %0d,",loader_collisions);
        $fdisplay(dump_fd,"  \"cpu_ready_reads_before_load\": %0d,",cpu_ready_reads_before_load);
        $fdisplay(dump_fd,"  \"load_first_cycle\": %0d,",load_first_cycle);
        $fdisplay(dump_fd,"  \"last_output_response_cycle\": %0d,",last_write_cycle);
        $fdisplay(dump_fd,"  \"load_first_valid_ns\": %0.1f,",load_first_ns);
        $fdisplay(dump_fd,"  \"last_output_response_ns\": %0.1f,",last_write_ns);
        $fdisplay(dump_fd,"  \"load_to_output_elapsed_ns\": %0.1f,",last_write_ns-load_first_ns);
        $fdisplay(dump_fd,"  \"load_to_output_elapsed_cycles\": %0.1f,",(last_write_ns-load_first_ns)/100.0);
        $fdisplay(dump_fd,"  \"cycles\": %0d,",cycles);
        $fdisplay(dump_fd,"  \"last_start_cycle\": %0d,",start_cycle);
        $fdisplay(dump_fd,"  \"last_irq_cycle\": %0d,",irq_cycle);
        $fdisplay(dump_fd,"  \"last_start_to_irq_cycles\": %0d,",irq_cycle-start_cycle);
        $fdisplay(dump_fd,"  \"dma_reads\": %0d,",dma_reads);
        $fdisplay(dump_fd,"  \"dma_writes\": %0d,",dma_writes);
        $fdisplay(dump_fd,"  \"cpu_shared\": %0d,",cpu_requests);
        $fdisplay(dump_fd,"  \"contention_cycles\": %0d,",collisions);
        $fdisplay(dump_fd,"  \"irq\": %0d,",irq_rises);
        $fdisplay(dump_fd,"  \"starts\": %0d,",starts);
        $fdisplay(dump_fd,"  \"plic_claims\": %0d,",plic_claims);
        $fdisplay(dump_fd,"  \"plic_completes\": %0d,",plic_completes);
        $fdisplay(dump_fd,"  \"cpu_irq_rises\": %0d,",cpu_irq_rises);
        $fdisplay(dump_fd,"  \"platform_path\": \"e203_subsys_main/sysper/MEM_fabric/PLIC17\",");
        $fdisplay(dump_fd,"  \"actual_output_word_hash_hex\": \"%08h\"",ram_hash);
        $fdisplay(dump_fd,"}");$fclose(dump_fd);
        dump_fd=$fopen("export_status.txt","w");
        if(dump_fd==0)$fatal(1,"CANNOT OPEN export_status.txt");
        $fdisplay(dump_fd,"PASS");$fclose(dump_fd);
        $display("PASS BATCH_ACTUAL_OUTPUT_EXPORT layers=%0d elements=%0d final_words=3168",layers,6336*layers);
        fd=$fopen("status.txt","w");$fdisplay(fd,"PASS");$fclose(fd);
        $display("PASS CPU_CHAIN_EXECUTION layers=%0d cycles=%0d dma_reads=%0d dma_writes=%0d cpu_shared=%0d contention_cycles=%0d irq=%0d starts=%0d",layers,cycles,dma_reads,dma_writes,cpu_requests,collisions,irq_rises,starts);
        $display("PASS END_TO_END_FUNCTIONAL load_to_output_cycles=%0.1f clock_period_ns=100 shared_target=behavioral",(last_write_ns-load_first_ns)/100.0);
        $finish;
    end
    initial begin #(64'd6100000000);$fatal(1,"TIMEOUT pc=%h stage=%0d layer=%0d",pc,soc.u_accel.stage,soc.u_accel.layer);end
endmodule
`undef ITCM
