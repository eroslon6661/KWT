#!/usr/bin/env python
"""Check actual CPU-scheduled encoder exports; Python 2.7/3 standard library.

Golden tensors and the classifier are used only AFTER simulation. The classifier
is software postprocessing with explicit binary32 rounding, not hardware logic
and not a claim of bit-for-bit TensorFlow reduction-order equivalence.
"""
from __future__ import print_function
import argparse
import ast
import hashlib
import io
import json
import math
import os
import re
import struct
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ELEMENTS = 6336
THRESHOLD = 0.03
RMS_FLOOR = 1e-8
MODE = 'cpu_scheduled_single_layer_chain'
CASE_IDS = ['01_yes', '02_no', '03_up', '04_down', '05_left',
            '06_right', '07_on', '08_off', '09_stop', '10_go']
LABELS = ['_silence_', '_unknown_', 'yes', 'no', 'up', 'down',
          'left', 'right', 'on', 'off', 'stop', 'go']
COUNTS_PER_LAYER = {
    'starts': 1, 'irq_rises': 1, 'irq_clears': 1, 'plic_claims': 1,
    'plic_completes': 1, 'cpu_irq_rises': 1, 'layer_starts': 1,
    'weight_beats': 12288, 'param_beats': 898, 'stage_count': 17,
    'ln_checks': 6336, 'ff_checks': 6336,
    'dma_reads': 16362, 'dma_writes': 3168, 'dma_responses': 19530
}


def read_bytes(path):
    with open(path, 'rb') as stream:
        return stream.read()


def sha256(path):
    return hashlib.sha256(read_bytes(path)).hexdigest()


def read_json(path):
    with io.open(path, encoding='utf-8') as stream:
        return json.load(stream)


def finite(value):
    return not math.isnan(value) and not math.isinf(value)


def read_hex(path, count, digits):
    tokens = read_bytes(path).decode('ascii').split()
    if len(tokens) != count:
        raise ValueError('%s: expected %d words, got %d' % (path, count, len(tokens)))
    pattern = re.compile(r'^[0-9a-fA-F]{%d}$' % digits)
    if any(pattern.match(token) is None for token in tokens):
        raise ValueError('%s: malformed hex, wrong word width, or X/Z value' % path)
    return [int(token, 16) for token in tokens]


def decode_half(bits):
    sign = -1.0 if bits & 0x8000 else 1.0
    exponent = (bits >> 10) & 31
    fraction = bits & 1023
    if exponent == 31:
        raise ValueError('Nonfinite hardware FP16 value: %04x' % bits)
    if exponent == 0:
        return sign * math.ldexp(float(fraction), -24)
    return sign * math.ldexp(float(1024 + fraction), exponent - 25)


def read_reference(path):
    """Only the pinned C-order <f4 (99,64) NPY v1.0 layout is accepted."""
    data = read_bytes(path)
    if len(data) < 10 or data[:8] != b'\x93NUMPY\x01\x00':
        raise ValueError('Reference must use NPY v1.0')
    header_len = struct.unpack('<H', data[8:10])[0]
    if header_len > 4096 or len(data) < 10 + header_len:
        raise ValueError('Invalid/truncated NPY header')
    try:
        header = ast.literal_eval(data[10:10 + header_len].decode('ascii').strip())
    except (ValueError, SyntaxError, UnicodeError):
        raise ValueError('Malformed NPY header')
    if (not isinstance(header, dict) or header.get('descr') != '<f4' or
            header.get('fortran_order') is not False or header.get('shape') != (99, 64)):
        raise ValueError('Reference must be C-order little-endian FP32 with shape (99,64)')
    payload = data[10 + header_len:]
    if len(payload) != ELEMENTS * 4:
        raise ValueError('Reference payload must contain exactly 6336 FP32 values')
    values = struct.unpack('<%df' % ELEMENTS, payload)
    if not all(finite(value) for value in values):
        raise ValueError('Reference contains nonfinite FP32 values')
    return values


def verify_package(root, expected_case='01_yes'):
    manifest = read_json(os.path.join(root, 'data', 'manifest.json'))
    if (not isinstance(manifest, dict) or manifest.get('schema') != 'kwt_chain_data_v1' or manifest.get('case_id') != expected_case or
            type(manifest.get('layers')) is not int or manifest['layers'] != 12 or
            manifest.get('shape') != [99, 64] or manifest.get('mode') != MODE or
            manifest.get('shared_ram_bytes') != 524288 or
            manifest.get('parameter_slot_bytes') != 53248):
        raise ValueError('Incorrect fixed sample/layer/shape/mode/memory manifest')
    expected_names = ['input.hex'] + ['params_%02d.hex' % n for n in range(1, 13)]
    if set(manifest['files']) != set(expected_names):
        raise ValueError('Prepared stimulus manifest must contain input and all twelve parameter slots')
    for name in expected_names:
        words = 3168 if name == 'input.hex' else 13312
        entry = manifest['files'][name]
        path = os.path.join(root, 'data', name)
        if (entry.get('path') != 'data/' + name or entry.get('words') != words or
                entry.get('word_bits') != 32 or entry.get('bytes') != words * 4 or
                sha256(path) != entry['text_sha256']):
            raise ValueError('Prepared stimulus identity mismatch: ' + name)
        binary = b''.join(struct.pack('<I', value) for value in read_hex(path, words, 8))
        if hashlib.sha256(binary).hexdigest() != entry['little_endian_bytes_sha256']:
            raise ValueError('Prepared stimulus byte identity mismatch: ' + name)
    provenance_path = os.path.join(root, 'references', 'provenance.json')
    if sha256(provenance_path) != manifest['reference_provenance']['sha256']:
        raise ValueError('Reference provenance hash mismatch')
    provenance = read_json(provenance_path)
    if (provenance.get('sample_id') != manifest['sample_id'] or
            provenance.get('case_id') != manifest['case_id'] or
            provenance.get('label') != manifest['label'] or
            provenance.get('encoder_input_fp16_sha256') !=
            manifest['files']['input.hex']['little_endian_bytes_sha256']):
        raise ValueError('Sample/input/reference pairing mismatch')
    expected_refs = set('layer_%02d_ln2.npy' % n for n in range(1, 13))
    if set(manifest['references']) != expected_refs or set(provenance['reference_files']) != expected_refs:
        raise ValueError('Native reference manifest must contain all twelve layers')
    for name in sorted(expected_refs):
        entry = manifest['references'][name]
        if (entry.get('path') != 'references/' + name or entry.get('shape') != [99, 64] or
                entry.get('dtype') != '<f4' or entry.get('elements') != ELEMENTS or
                sha256(os.path.join(root, 'references', name)) != entry['sha256']):
            raise ValueError('Native FP32 reference identity mismatch: ' + name)
        if provenance['reference_files'][name]['sha256'] != entry['sha256']:
            raise ValueError('Reference/provenance pairing mismatch: ' + name)
    return manifest, provenance


def load_cases(root=ROOT):
    """Read the fixed ten-case catalog; no arbitrary path/case selection."""
    catalog = read_json(os.path.join(root, 'cases.json'))
    if not isinstance(catalog, dict):
        raise ValueError('Invalid fixed ten-case catalog object')
    entries = catalog.get('cases')
    if (catalog.get('schema') != 'kwt_tcm_batch10_cases_v1' or
            type(catalog.get('count')) is not int or catalog['count'] != 10 or
            not isinstance(entries, list) or len(entries) != 10):
        raise ValueError('Invalid fixed ten-case catalog schema/count')
    samples = []
    for case_id, entry in zip(CASE_IDS, entries):
        if (not isinstance(entry, dict) or entry.get('case_id') != case_id or entry.get('label') != case_id[3:] or
                entry.get('root') != 'cases/' + case_id or
                not isinstance(entry.get('sample_id'), type(u'')) or
                not entry['sample_id'].startswith(entry['label'] + '/') or
                re.match(r'^[0-9a-f]{64}$', entry.get('manifest_sha256', '')) is None):
            raise ValueError('Invalid fixed case identity/root/hash: ' + case_id)
        samples.append(entry['sample_id'])
    if len(set(samples)) != 10:
        raise ValueError('Duplicate sample identity in fixed ten-case catalog')
    expected_parameters = set('params_%02d.hex' % n for n in range(1, 13))
    if set(catalog.get('common_parameter_text_sha256', {})) != expected_parameters:
        raise ValueError('Catalog must pin all twelve shared parameter hashes')
    return catalog


def authenticate_case(case_id, root=ROOT):
    """Authenticate catalog -> case manifest -> stimulus, references and head."""
    catalog = load_cases(root)
    if case_id not in CASE_IDS:
        raise ValueError('Unknown fixed case: ' + str(case_id))
    entry = catalog['cases'][CASE_IDS.index(case_id)]
    case_root = os.path.join(root, 'cases', case_id)
    manifest_path = os.path.join(case_root, 'data', 'manifest.json')
    if sha256(manifest_path) != entry['manifest_sha256']:
        raise ValueError('Case %s manifest identity mismatch' % case_id)
    manifest, provenance = verify_package(case_root, expected_case=case_id)
    if (manifest['sample_id'] != entry['sample_id'] or manifest['label'] != entry['label'] or
            manifest['classifier']['weights_sha256'] != catalog['classifier_weights_sha256']):
        raise ValueError('Case %s catalog/sample/classifier pairing mismatch' % case_id)
    for name, expected in catalog['common_parameter_text_sha256'].items():
        if manifest['files'][name]['text_sha256'] != expected:
            raise ValueError('Case %s shared parameter identity differs: %s' % (case_id, name))
    # Validate formats before simulator launch, not merely their hashes.
    for n in range(1, 13):
        read_reference(os.path.join(case_root, 'references', 'layer_%02d_ln2.npy' % n))
    load_classifier(case_root, manifest, provenance)
    return catalog, entry, case_root, manifest, provenance


def receipt_document(case_id, root=ROOT):
    catalog, entry, case_root, manifest, provenance = authenticate_case(case_id, root)
    receipt = {
        'schema': 'kwt_case_receipt_v1', 'status': 'PREPARED',
        'case_id': case_id, 'label': entry['label'], 'sample_id': entry['sample_id'],
        'case_root': entry['root'], 'manifest_sha256': entry['manifest_sha256'],
        'cases_manifest_sha256': sha256(os.path.join(root, 'cases.json')),
        'encoder_input_fp16_sha256': provenance['encoder_input_fp16_sha256'],
        'stimulus_files_sha256': dict((name, item['text_sha256'])
                                     for name, item in manifest['files'].items()),
        'scope': 'Authenticated prepared inputs only; not a simulation or numerical PASS'
    }
    return receipt, case_root


def verify_receipt(result, case_id, root=ROOT):
    expected, case_root = receipt_document(case_id, root)
    path = os.path.join(result, 'case_receipt.json')
    receipt = read_json(path)
    if receipt != expected:
        raise ValueError('Case %s receipt identity mismatch' % case_id)
    for name, digest in expected['stimulus_files_sha256'].items():
        if sha256(os.path.join(result, name)) != digest:
            raise ValueError('Case %s actual copied stimulus identity mismatch: %s' % (case_id, name))
    return expected, case_root


def verify_execution(result, layers):
    if type(layers) is not int or not 1 <= layers <= 12:
        raise ValueError('Requested layers must be an integer from 1 through 12')
    for marker in ('status.txt', 'export_status.txt'):
        if read_bytes(os.path.join(result, marker)).strip() != b'PASS':
            raise ValueError('Simulation/export did not pass: ' + marker)
    execution = read_json(os.path.join(result, 'execution.json'))
    if (execution.get('execution_status') != 'PASS' or execution.get('mode') != MODE or
            type(execution.get('layers')) is not int or execution['layers'] != layers or
            type(execution.get('completed_layers')) is not int or
            execution['completed_layers'] != layers):
        raise ValueError('Execution PASS, mode, requested layers or completed_layers mismatch')
    if execution.get('shared_bytes') != 524288:
        raise ValueError('Execution must use exactly 512 KiB shared RAM')
    expected_base = 'a0000000' if layers % 2 == 0 else 'a0004000'
    if execution.get('final_output_base_hex') != expected_base:
        raise ValueError('Final ping-pong output base mismatch')
    for field, per_layer in sorted(COUNTS_PER_LAYER.items()):
        value = execution.get(field)
        if type(value) is not int or value != per_layer * layers:
            raise ValueError('Execution count mismatch: %s expected=%d actual=%r' %
                             (field, per_layer * layers, value))
    expected = set('layer_%02d_%s.hex' % (n, kind)
                   for n in range(1, layers + 1) for kind in ('ln2', 'output_u32'))
    observed = set(name for name in os.listdir(result)
                   if re.match(r'^layer_.*_(ln2|output_u32)\.hex$', name))
    if observed != expected:
        raise ValueError('Missing, stale or unexpected layer exports: expected %d files, got %d' %
                         (len(expected), len(observed)))
    return execution


def calculate_metrics(actual, reference):
    differences = [h - r for h, r in zip(actual, reference)]
    count = len(reference)
    if len(actual) != count or not count:
        raise ValueError('Numerical tensor sizes differ or are empty')
    error_sse = math.fsum(value * value for value in differences)
    reference_sse = math.fsum(value * value for value in reference)
    rmse = math.sqrt(error_sse / count)
    reference_rms = math.sqrt(reference_sse / count)
    nrmse = rmse / max(reference_rms, RMS_FLOOR)
    if not all(finite(value) for value in (error_sse, reference_sse, rmse, reference_rms, nrmse)):
        raise ValueError('Nonfinite numerical metric')
    worst = max(range(count), key=lambda index: abs(differences[index]))
    return {
        'elements': count, 'nrmse': nrmse, 'nrmse_percent': 100.0 * nrmse,
        'threshold': THRESHOLD, 'within_threshold': nrmse <= THRESHOLD,
        'rmse': rmse, 'reference_rms': reference_rms, 'reference_rms_floor': RMS_FLOOR,
        'error_sse': error_sse, 'reference_sse': reference_sse,
        'max_abs_error': abs(differences[worst]),
        'worst_index': {'flat': worst, 'token': worst // 64, 'channel': worst % 64},
        'worst_actual': actual[worst], 'worst_reference': reference[worst]
    }


def f32(value):
    result = struct.unpack('<f', struct.pack('<f', value))[0]
    if not finite(result):
        raise ValueError('Nonfinite software FP32 classifier result')
    return result


def load_classifier(root, manifest, provenance):
    entry = manifest['classifier']
    metadata_path = os.path.join(root, 'references', 'classifier.json')
    weights_path = os.path.join(root, 'references', 'classifier_fp32.bin')
    if (entry.get('metadata_path') != 'references/classifier.json' or
            entry.get('weights_path') != 'references/classifier_fp32.bin' or
            sha256(metadata_path) != entry['metadata_sha256'] or
            sha256(weights_path) != entry['weights_sha256']):
        raise ValueError('Software classifier file identity mismatch')
    metadata = read_json(metadata_path)
    if (metadata.get('schema') != 'kwt_classifier_fp32_v1' or
            metadata.get('kernel_shape') != [64, 12] or metadata.get('bias_shape') != [12] or
            metadata.get('labels') != LABELS or metadata.get('sha256') != entry['weights_sha256'] or
            metadata.get('checkpoint_files_sha256') != provenance['checkpoint_files_sha256']):
        raise ValueError('Software classifier/checkpoint pairing mismatch')
    raw = read_bytes(weights_path)
    if len(raw) != 3120:
        raise ValueError('Original classifier must contain exactly 780 FP32 values')
    values = struct.unpack('<780f', raw)
    if not all(finite(value) for value in values):
        raise ValueError('Nonfinite classifier weights')
    return values[:768], values[768:], metadata


def classify(matrix, kernel, bias):
    """Token 0, ordered binary32 non-fused dot product, then binary32 bias."""
    token = [f32(value) for value in matrix[:64]]
    if len(token) != 64 or len(kernel) != 768 or len(bias) != 12:
        raise ValueError('Invalid software classifier shapes')
    logits, real_logits, bounds = [], [], []
    # Conservative floating-point summation diagnostic. This is not a guarantee
    # about TensorFlow's unspecified reduction order or floating-point mode.
    gamma = (130.0 * 2.0 ** -24) / (1.0 - 130.0 * 2.0 ** -24)
    for j in range(12):
        accumulator = 0.0
        products = [token[i] * kernel[i * 12 + j] for i in range(64)]
        for product in products:
            accumulator = f32(accumulator + f32(product))
        logits.append(f32(accumulator + bias[j]))
        real_logits.append(math.fsum(products + [bias[j]]))
        bounds.append(gamma * math.fsum([abs(value) for value in products] + [abs(bias[j])]) +
                      130.0 * 2.0 ** -149)
    prediction = max(range(12), key=lambda j: logits[j])
    runner_up = max(logits[j] for j in range(12) if j != prediction)
    return {
        'prediction_index': prediction, 'prediction': LABELS[prediction],
        'logits_fp32': logits, 'top1_margin': logits[prediction] - runner_up,
        'max_abs_difference_from_fp64_sum': max(abs(a - b) for a, b in zip(logits, real_logits)),
        'max_conservative_rounding_bound': max(bounds),
        'ranking_stable_under_reported_bound':
            real_logits[prediction] - bounds[prediction] >
            max(real_logits[j] + bounds[j] for j in range(12) if j != prediction)
    }


def compare(result, layers=12, root=ROOT, expected_case='01_yes'):
    manifest, provenance = verify_package(root, expected_case=expected_case)
    execution = verify_execution(result, layers)
    per_layer = []
    last_packed = None
    for layer in range(1, layers + 1):
        name = 'layer_%02d_ln2.hex' % layer
        packed_name = 'layer_%02d_output_u32.hex' % layer
        actual_path = os.path.join(result, name)
        packed_path = os.path.join(result, packed_name)
        reference_path = os.path.join(root, 'references', 'layer_%02d_ln2.npy' % layer)
        halves = read_hex(actual_path, ELEMENTS, 4)
        packed = read_hex(packed_path, ELEMENTS // 2, 8)
        expected = [halves[i] | (halves[i + 1] << 16) for i in range(0, ELEMENTS, 2)]
        if packed != expected:
            raise ValueError('Layer %d DMA packed output differs from exported LayerNorm output' % layer)
        actual = [decode_half(value) for value in halves]
        reference = read_reference(reference_path)
        metrics = calculate_metrics(actual, reference)
        metrics.update({'layer': layer, 'exact_dma_packing_match': True,
                        'actual_layer_hex_sha256': sha256(actual_path),
                        'actual_packed_hex_sha256': sha256(packed_path),
                        'reference_sha256': sha256(reference_path)})
        per_layer.append(metrics)
        last_packed = packed
    final_path = os.path.join(result, 'final_output_u32.hex')
    if read_hex(final_path, ELEMENTS // 2, 8) != last_packed:
        raise ValueError('Final packed output differs from last completed layer')
    worst = max(per_layer, key=lambda item: item['nrmse'])
    count = ELEMENTS * layers
    total_error = math.fsum(item['error_sse'] for item in per_layer)
    total_reference = math.fsum(item['reference_sse'] for item in per_layer)
    global_rmse = math.sqrt(total_error / count)
    global_rms = math.sqrt(total_reference / count)
    global_nrmse = global_rmse / max(global_rms, RMS_FLOOR)
    classification = None
    if layers == 12 and 'classifier' in manifest:
        kernel, bias, metadata = load_classifier(root, manifest, provenance)
        hw = classify(actual, kernel, bias)
        ref = classify(reference, kernel, bias)
        classification = {
            'scope': 'Software postprocessing of one sample, not accelerator hardware classification or full-dataset Top-1 accuracy',
            'arithmetic': metadata['arithmetic'], 'tensorflow_bit_exact_claim': False,
            'true_label': manifest['label'], 'hardware_output': hw, 'native_fp32_output': ref,
            'hardware_correct': hw['prediction'] == manifest['label'],
            'reference_correct': ref['prediction'] == manifest['label'],
            'prediction_agreement': hw['prediction'] == ref['prediction'],
            'max_logit_abs_difference': max(abs(a - b) for a, b in
                                           zip(hw['logits_fp32'], ref['logits_fp32'])),
            'weights_sha256': manifest['classifier']['weights_sha256'],
            'used_for_nrmse_pass_decision': False
        }
    status = 'PASS' if worst['nrmse'] <= THRESHOLD else 'FAIL'
    return {
        'schema': 'kwt_chain_numerical_v1', 'status': status,
        'numerical_evaluation_complete': True, 'mode': MODE,
        'case_id': manifest['case_id'], 'sample_id': manifest['sample_id'],
        'layers': layers, 'full_12_layer_coverage': layers == 12,
        'shape_per_layer': [99, 64], 'elements': count,
        'scope': 'One fixed sample from the ten-case subset, CPU-scheduled single-layer STARTs chained through actual shared-RAM outputs; not a single-START hardware loop or full-dataset accuracy result',
        'reference': 'Native original-checkpoint TensorFlow FP32 LayerNorm-2 outputs',
        'formula': 'sqrt(sum((HW-FP32)^2)/N) / max(sqrt(sum(FP32^2)/N),1e-8)',
        'per_layer': per_layer, 'worst_layer': worst['layer'],
        'worst_nrmse': worst['nrmse'], 'threshold': THRESHOLD,
        'all_layers_within_threshold': status == 'PASS',
        'global_tensor_nrmse': global_nrmse,
        'global_tensor_rmse': global_rmse, 'global_reference_rms': global_rms,
        'global_error_sse': total_error, 'global_reference_sse': total_reference,
        'global_metric_is_supplemental_not_threshold_gate': True,
        'exact_dma_packing_match_all_layers': True, 'final_matches_last_layer': True,
        'final_output_base_hex': execution['final_output_base_hex'],
        'classification_evaluated': classification is not None,
        'software_classification': classification,
        'execution_sha256': sha256(os.path.join(result, 'execution.json')),
        'final_output_hex_sha256': sha256(final_path),
        'data_manifest_sha256': sha256(os.path.join(root, 'data', 'manifest.json')),
        'encoder_input_fp16_sha256': provenance['encoder_input_fp16_sha256'],
        'checkpoint_files_sha256': provenance['checkpoint_files_sha256'],
        'reference_source_files_sha256': provenance['reference_source_files_sha256']
    }


def compare_case(result, case_id, layers=12, root=ROOT):
    """Public batch API: authenticate runtime stimulus identity before scoring."""
    try:
        receipt, case_root = verify_receipt(result, case_id, root)
        report = compare(result, layers, case_root, expected_case=case_id)
        report.update({
            'case_receipt_sha256': sha256(os.path.join(result, 'case_receipt.json')),
            'cases_manifest_sha256': receipt['cases_manifest_sha256'],
            'authenticated_case_manifest_sha256': receipt['manifest_sha256'],
            'runtime_stimulus_sha256': receipt['stimulus_files_sha256'],
            'runtime_stimulus_identity_verified': True
        })
        return report
    except (ValueError, KeyError, TypeError, IOError, OSError, struct.error, OverflowError) as exc:
        raise ValueError('Case %s: %s' % (case_id, exc))


def write_ascii(path, text):
    with open(path, 'wb') as stream:
        stream.write(text.encode('ascii'))


def run_comparison(result, layers=12, root=ROOT, case_id='01_yes'):
    result = os.path.abspath(result)
    if not os.path.isdir(result):
        raise ValueError('Result directory does not exist: ' + result)
    status_path = os.path.join(result, 'numerical_status.txt')
    write_ascii(status_path, 'INCOMPLETE\n')
    try:
        report = compare_case(result, case_id, layers, root)
        code = 0 if report['status'] == 'PASS' else 1
    except (ValueError, KeyError, TypeError, IOError, OSError, struct.error, OverflowError) as exc:
        report = {'schema': 'kwt_chain_numerical_v1', 'status': 'FAIL', 'mode': MODE,
                  'case_id': case_id, 'layers': layers, 'error': str(exc),
                  'numerical_evaluation_complete': False}
        code = 2
    write_ascii(os.path.join(result, 'numerical.json'),
                json.dumps(report, indent=2, sort_keys=True, ensure_ascii=True,
                           allow_nan=False) + '\n')
    write_ascii(status_path, report['status'] + '\n')
    return code, report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--result', required=True, help='Directory of actual simulator exports')
    parser.add_argument('--case', dest='case_id', default='01_yes', choices=CASE_IDS,
                        help='Authenticated fixed case; defaults to 01_yes')
    parser.add_argument('--layers', type=int, default=12, choices=range(1, 13),
                        help='Expected executed layers; defaults to the complete twelve-layer chain')
    args = parser.parse_args()
    try:
        code, report = run_comparison(args.result, args.layers, case_id=args.case_id)
    except (ValueError, IOError, OSError) as exc:
        print('FAIL CHAIN_NUMERICAL error=%s' % exc, file=sys.stderr)
        return 2
    if 'worst_nrmse' in report:
        message = '%s CHAIN_NUMERICAL case=%s layers=%d worst_layer=%d worst_NRMSE=%.10g global_NRMSE=%.10g threshold=0.03' % (
            report['status'], args.case_id, args.layers, report['worst_layer'], report['worst_nrmse'], report['global_tensor_nrmse'])
        if report['classification_evaluated']:
            item = report['software_classification']
            message += ' software_Top1_HW=%s software_Top1_FP32=%s truth=%s' % (
                item['hardware_output']['prediction'], item['native_fp32_output']['prediction'], item['true_label'])
        print(message)
    else:
        print('FAIL CHAIN_NUMERICAL error=%s' % report['error'])
    return code


if __name__ == '__main__':
    sys.exit(main())
