#!/usr/bin/env python
"""Prepare one authenticated case in an empty run directory; Python 2.7/3."""
from __future__ import print_function
import argparse
import json
import os
import shutil
import sys

import compare_chain

ROOT = compare_chain.ROOT


def prepare_payload(result, case_id, root=ROOT):
    """Copy only thirteen stimulus files; publish the receipt after verification."""
    result = os.path.abspath(result)
    if os.path.exists(result) and (not os.path.isdir(result) or os.listdir(result)):
        raise ValueError('Case %s requires a new or empty result directory: %s' % (case_id, result))
    receipt, case_root = compare_chain.receipt_document(case_id, root)
    if not os.path.exists(result):
        os.makedirs(result)
    if os.listdir(result):
        raise ValueError('Case %s result directory is no longer empty' % case_id)
    for name, digest in sorted(receipt['stimulus_files_sha256'].items()):
        target = os.path.join(result, name)
        shutil.copyfile(os.path.join(case_root, 'data', name), target)
        if compare_chain.sha256(target) != digest:
            raise ValueError('Case %s payload copy verification failed: %s' % (case_id, name))
    compare_chain.write_ascii(os.path.join(result, 'case_receipt.json'),
                              json.dumps(receipt, indent=2, sort_keys=True, ensure_ascii=True,
                                         allow_nan=False) + '\n')
    return receipt


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--case', dest='case_id', required=True, choices=compare_chain.CASE_IDS)
    parser.add_argument('--result', required=True)
    args = parser.parse_args()
    try:
        receipt = prepare_payload(args.result, args.case_id)
    except (ValueError, KeyError, TypeError, IOError, OSError) as exc:
        print('FAIL CASE_PAYLOAD case=%s error=%s' % (args.case_id, exc), file=sys.stderr)
        return 2
    print('PREPARED CASE_PAYLOAD case=%s sample=%s files=13 manifest=%s' %
          (args.case_id, receipt['sample_id'], receipt['manifest_sha256']))
    return 0


if __name__ == '__main__':
    sys.exit(main())
