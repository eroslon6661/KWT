#!/usr/bin/env python
"""Prepare an explicit SRAM model filelist and content manifest (Python 2.7/3).

Default discovery is limited to RAMSP{1024,2048,4096}X16/verilog trees.
An override filelist accepts one unquoted source path or +incdir+DIR per line;
multiple directories separated by '+' are supported. Relative paths are relative
to that filelist. No nested filelists, shell/env expansion or compiler switches.
All literal `include dependencies are resolved conservatively, including those
inside conditional branches. Missing, macro-expanded or ambiguous includes fail.
The generated list does not define macros: compile it with +define+ARM_UD_MODEL.
"""
from __future__ import print_function
import argparse
import hashlib
import io
import json
import os
import re
import sys

MODELS = ('RAMSP1024X16', 'RAMSP2048X16', 'RAMSP4096X16')
TOKEN = re.compile(r'"(?:\\.|[^"\\])*"|//[^\n]*|/\*.*?\*/', re.S)
MODULE = re.compile(r'\bmodule\s+(?:automatic\s+)?([A-Za-z_][A-Za-z0-9_$]*)')
INCLUDE = re.compile(r'^\s*`include\s+(.+?)\s*$', re.M)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read(path):
    with open(path, 'rb') as stream:
        return stream.read()


def clean(text, strings=False):
    def replace(match):
        value = match.group(0)
        if value.startswith('"') and not strings:
            return value
        return '\n' * value.count('\n') + ' '
    return TOKEN.sub(replace, text)


def source_text(path):
    # Some vendor comments use non-UTF8 encodings. ASCII syntax is unchanged.
    return read(path).decode('latin1')


def absolute(path, base):
    if not path or any(c.isspace() for c in path) or any(c in path for c in '+"\'`$*?'):
        raise ValueError('Unsupported path syntax (use paths without spaces/expansions): ' + path)
    path = path if os.path.isabs(path) else os.path.join(base, path)
    return os.path.realpath(os.path.abspath(path))


def unique(items):
    result = []
    for item in items:
        if item not in result:
            result.append(item)
    return result


def limited_walk(base, depth):
    if not os.path.isdir(base):
        return
    for current, dirs, files in os.walk(base, followlinks=False):
        dirs.sort(); files.sort()
        relative = os.path.relpath(current, base)
        level = 0 if relative == '.' else len(relative.split(os.sep))
        if level >= depth:
            dirs[:] = []
        yield current, dirs, files


def discover(library):
    if not os.path.isdir(library):
        raise ValueError('SRAM library directory does not exist: ' + library)
    candidates = []
    for model in MODELS:
        roots = []
        for current, dirs, files in limited_walk(library, 2):
            if os.path.basename(current).lower() == model.lower():
                roots.append(current)
                dirs[:] = []
        if not roots:
            raise ValueError('Missing SRAM macro directory: ' + model + ' under ' + library)
        found = []
        for root in roots:
            for current, dirs, files in limited_walk(root, 2):
                if os.path.basename(current).lower() == 'verilog':
                    for folder, children, names in limited_walk(current, 3):
                        found.extend(os.path.join(folder, name) for name in names if name.lower().endswith('.v'))
                    dirs[:] = []
        if not found:
            raise ValueError('No .v files in ' + model + '/verilog (search is depth-limited)')
        for path in found:
            declarations = MODULE.findall(clean(source_text(path), strings=True))
            if any(name in MODELS for name in declarations):
                candidates.append(absolute(path, library))
    return unique(sorted(candidates)), []


def parse_filelist(path):
    base = os.path.dirname(path)
    sources, includes = [], []
    with io.open(path, 'r', encoding='utf-8-sig') as stream:
        for number, line in enumerate(stream, 1):
            line = line.strip()
            if not line or line.startswith(('#', '//')):
                continue
            try:
                if line.startswith('+incdir+'):
                    parts = line[len('+incdir+'):].split('+')
                    if not all(parts):
                        raise ValueError('Empty +incdir entry')
                    includes.extend(absolute(item, base) for item in parts)
                elif line.startswith(('-', '+')) or not line.lower().endswith(('.v', '.sv')):
                    raise ValueError('Only source paths and +incdir+DIR are supported')
                else:
                    sources.append(absolute(line, base))
            except ValueError as exc:
                raise ValueError('%s:%d: %s' % (path, number, exc))
    if not sources:
        raise ValueError('Override filelist contains no Verilog sources: ' + path)
    for folder in includes:
        if not os.path.isdir(folder):
            raise ValueError('Include directory does not exist: ' + folder)
    return unique(sources), unique(includes)


def dependencies(path, include_dirs, records, edges, stack=None):
    stack = [] if stack is None else stack
    if path in stack:
        raise ValueError('Recursive `include is unsupported: ' + ' -> '.join(stack + [path]))
    if len(stack) > 32:
        raise ValueError('SRAM include nesting exceeds 32: ' + path)
    if not os.path.isfile(path):
        raise ValueError('Missing SRAM source/dependency: ' + path)
    if path in records:
        return
    blob = read(path)
    records[path] = dict(path=path, sha256=sha(blob), bytes=len(blob))
    for expression in INCLUDE.findall(clean(blob.decode('latin1'))):
        match = re.match(r'^"([^"\r\n]+)"$', expression)
        if not match:
            raise ValueError('Only literal `include "file" is supported: %s: %s' % (path, expression))
        name = match.group(1)
        choices = []
        search = unique([os.path.dirname(path)] + include_dirs)
        for folder in search:
            candidate = absolute(name, folder)
            if os.path.isfile(candidate) and candidate not in choices:
                choices.append(candidate)
        if not choices:
            raise ValueError('Missing `include %s referenced by %s; add its directory with +incdir' % (name, path))
        if len(set(sha(read(item)) for item in choices)) != 1:
            raise ValueError('Ambiguous `include %s referenced by %s:\n%s' % (name, path, '\n'.join(choices)))
        dependency = choices[0]
        edges.append(dict(source=path, include=name, path=dependency))
        dependencies(dependency, include_dirs, records, edges, stack + [path])


def prepare(library, output, filelist=None):
    output = os.path.abspath(output)
    if os.path.exists(output):
        raise ValueError('Output must not exist; choose a new directory: ' + output)
    library = os.path.realpath(os.path.abspath(library))
    filelist = os.path.realpath(os.path.abspath(filelist)) if filelist else None
    candidates, include_dirs = parse_filelist(filelist) if filelist else discover(library)
    # Source-local include lookup is made explicit in the generated filelist.
    include_dirs = unique(include_dirs + [os.path.dirname(path) for path in candidates])
    all_records, all_edges = {}, []
    for path in candidates:
        dependencies(path, include_dirs, all_records, all_edges)
    # Byte-identical sources are deduplicated only after include ambiguity checks.
    selected, copies, hashes = [], [], {}
    for path in candidates:
        digest = all_records[path]['sha256']
        if digest in hashes:
            copies.append(dict(path=path, same_as=hashes[digest], sha256=digest))
        else:
            hashes[digest] = path
            selected.append(path)
    declared = {}
    for path in selected:
        for name in sorted(set(MODULE.findall(clean(source_text(path), strings=True)))):
            declared.setdefault(name, []).append(path)
    for name in MODELS:
        if name not in declared:
            raise ValueError('Missing module declaration: ' + name)
    for name, paths in sorted(declared.items()):
        if len(paths) != 1:
            raise ValueError('Ambiguous module %s; select one model version with --filelist:\n%s' % (name, '\n'.join(paths)))
    # Rebuild the closure after deduplication; keep alias paths only as evidence.
    records, edges = {}, []
    for path in selected:
        dependencies(path, include_dirs, records, edges)
    include_dirs = unique(include_dirs + [os.path.dirname(p) for p in sorted(records)])
    # Check lookup once more with the final include search path.
    final_records, final_edges = {}, []
    for path in selected:
        dependencies(path, include_dirs, final_records, final_edges)
    manifest = dict(schema='kwt_sram_models_v1', mode='ARM_UD_MODEL',
        source_kind='EXPLICIT_FILELIST' if filelist else 'LIBRARY_DISCOVERY',
        library=library, input_filelist=filelist,
        input_filelist_sha256=sha(read(filelist)) if filelist else None,
        modules=dict((name, declared[name][0]) for name in MODELS),
        sources=[final_records[path] for path in selected],
        dependencies=[final_records[p] for p in sorted(final_records) if p not in selected],
        include_dirs=include_dirs, include_edges=final_edges, deduplicated_sources=copies,
        include_policy='ALL_LITERAL_INCLUDES_INCLUDING_CONDITIONAL_BRANCHES',
        verification='SOURCE_DISCOVERY_AND_HASHING_ONLY_NOT_SIMULATION_PASS')
    os.makedirs(output)
    with io.open(os.path.join(output, 'sram.f'), 'w', encoding='utf-8', newline='\n') as stream:
        for folder in include_dirs:
            stream.write(u'+incdir+%s\n' % folder.replace('\\', '/'))
        for path in selected:
            stream.write(u'%s\n' % path.replace('\\', '/'))
    with io.open(os.path.join(output, 'sram_manifest.json'), 'w', encoding='utf-8', newline='\n') as stream:
        stream.write(json.dumps(manifest, indent=2, sort_keys=True, ensure_ascii=True) + u'\n')
    return manifest


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--library', default='/storage1/admin_public_dir/SRAM_Lib_2025')
    parser.add_argument('--output', required=True)
    parser.add_argument('--filelist')
    args = parser.parse_args()
    try:
        manifest = prepare(args.library, args.output, args.filelist)
    except (ValueError, IOError, OSError) as exc:
        print('ERROR:', str(exc), file=sys.stderr)
        return 2
    print('PREPARED SRAM: %d source files, %d include dependencies; mode ARM_UD_MODEL' %
          (len(manifest['sources']), len(manifest['dependencies'])))
    print(os.path.join(os.path.abspath(args.output), 'sram.f'))
    return 0


if __name__ == '__main__':
    sys.exit(main())
