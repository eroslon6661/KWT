#!/usr/bin/env python
"""Adapt a NEW prepared E203 platform copy to the reviewed 256 KiB TCMs.

Python 2.7 / 3, standard library only. No public archive or vendor model changes.
The caller compiles rtl/kwt_tcm_4096x16.v and the external RAMSP4096X16 model.
"""
from __future__ import print_function
import argparse
import hashlib
import io
import json
import os
import re
import sys

COMMENT = re.compile(r'//[^\n]*|/\*.*?\*/', re.S)
MODULE = re.compile(r'\bmodule\s+([A-Za-z_][A-Za-z0-9_$]*)\b')
CODE_TOKEN = re.compile(r'"(?:\\.|[^"\\])*"|//[^\n]*|/\*.*?\*/', re.S)
EXTERNAL_MACROS = set(('RAMSP1024X16', 'RAMSP2048X16', 'RAMSP4096X16'))
try:
    TEXT = unicode
except NameError:
    TEXT = str


def read(path):
    with open(path, 'rb') as stream:
        return stream.read()


def digest(blob):
    return hashlib.sha256(blob).hexdigest()


def clean(text):
    return COMMENT.sub('', text)


def code_only(text):
    # Module names inside comments/diagnostic strings are not dependencies.
    return CODE_TOKEN.sub(lambda m: '\n' * m.group(0).count('\n') + ' ', text)


def canonical(text):
    return ''.join(clean(text).split())


def masked(text):
    return COMMENT.sub(lambda m: ''.join('\n' if c == '\n' else ' ' for c in m.group(0)), text)


def write(path, text):
    if not isinstance(text, TEXT):
        text = text.decode('utf-8')
    parent = os.path.dirname(path)
    if not os.path.isdir(parent):
        os.makedirs(parent)
    with io.open(path, 'w', encoding='utf-8', newline='\n') as stream:
        stream.write(text)


def header(kind):
    upper = kind.upper()
    return '''module e203_{kind}_ram(
    input sd, input ds, input ls, input cs, input we,
    input [`E203_{upper}_RAM_AW-1:0] addr,
    input [`E203_{upper}_RAM_MW-1:0] wem,
    input [`E203_{upper}_RAM_DW-1:0] din,
    output [`E203_{upper}_RAM_DW-1:0] dout,
    input rst_n, input clk
);
'''.format(kind=kind, upper=upper)


def generic_body(kind):
    upper = kind.upper()
    force = ('`ifndef E203_HAS_ECC\n.FORCE_X2ZERO(0),\n`endif\n'
             if kind == 'itcm' else '.FORCE_X2ZERO(1),\n')
    return '''sirv_gnrl_ram #(
{force}
.DP(`E203_{upper}_RAM_DP), .DW(`E203_{upper}_RAM_DW),
.MW(`E203_{upper}_RAM_MW), .AW(`E203_{upper}_RAM_AW)
) u_e203_{kind}_gnrl_ram(
.sd(sd), .ds(ds), .ls(ls), .rst_n(rst_n), .clk(clk),
.cs(cs), .we(we), .addr(addr), .din(din), .wem(wem), .dout(dout)
);
'''.format(force=force, upper=upper, kind=kind)


def old_macro_body(kind):
    geometry = '32KX64' if kind == 'itcm' else '64KX32'
    return '''`ifndef FPGA
sram_wrap_{geometry} u_sram_wrap_{geometry}(
.CLK(clk), .RSTN(rst_n), .ADDRESS(addr), .CS(cs), .WE(we),
.WEM(wem), .WDATA(din), .RDATA(dout)
);
`else
{generic}
`endif
'''.format(geometry=geometry, generic=generic_body(kind))


def adapted_body(kind):
    upper = kind.upper()
    aw, dw, mw = (15, 64, 8) if kind == 'itcm' else (16, 32, 4)
    return '''
    // sd/ds/ls were unused by the platform ASIC wrapper; retained as ports.
    // Reset changes bank selection only, not SRAM storage contents.
    kwt_tcm_4096x16 #(.WORD_WIDTH({dw}), .WORD_ADDR_WIDTH({aw})) u_kwt_tcm (
        .CLK(clk), .RSTN(rst_n), .ADDRESS(addr), .CS(cs), .WE(we),
        .WEM(wem), .WDATA(din), .RDATA(dout)
    );
    // synthesis translate_off
    initial begin
`ifdef FPGA
        $fatal(1, "TCM_CONFIG_ERROR FPGA must not be defined for this macro test");
`endif
`ifdef E203_CFG_HAS_ECC
        $display("TCM_CONFIG {upper} E203_CFG_HAS_ECC=1");
`else
        $display("TCM_CONFIG {upper} E203_CFG_HAS_ECC=0");
`endif
`ifdef E203_HAS_ECC
        $fatal(1, "TCM_CONFIG_ERROR E203_HAS_ECC is unsupported by this data-only wrapper");
`else
        $display("TCM_CONFIG {upper} E203_HAS_ECC=0");
`endif
        if (`E203_{upper}_RAM_AW != {aw} || `E203_{upper}_RAM_DW != {dw} ||
            `E203_{upper}_RAM_MW != {mw} || `E203_{upper}_RAM_DP != (1 << {aw}))
            $fatal(1, "TCM_CONFIG_ERROR {upper} AW=%0d DW=%0d MW=%0d DP=%0d",
                `E203_{upper}_RAM_AW, `E203_{upper}_RAM_DW,
                `E203_{upper}_RAM_MW, `E203_{upper}_RAM_DP);
        $display("TCM_INTERFACE {upper} AW=%0d DW=%0d MW=%0d BYTES=262144 MACROS=32",
            `E203_{upper}_RAM_AW, `E203_{upper}_RAM_DW, `E203_{upper}_RAM_MW);
    end
    // synthesis translate_on
'''.format(upper=upper, aw=aw, dw=dw, mw=mw)


def adapt(text, kind):
    name = 'e203_' + kind + '_ram'
    stripped = clean(text)
    if MODULE.findall(stripped) != [name] or len(re.findall(r'\bendmodule\b', stripped)) != 1:
        raise ValueError('Expected exactly one module: ' + name)
    # Match the entire reviewed source semantics, including outer guards.
    prefix = '`include "e203_defines.v"\n`ifdef E203_HAS_' + kind.upper() + '\n'
    ending = '\nendmodule\n`endif\n'
    formats = [('PUBLIC_GENERIC_RAM', generic_body(kind)),
               ('SERVER_ASIC_WRAPPER', old_macro_body(kind))]
    matched = [label for label, body in formats
               if canonical(text) == canonical(prefix + header(kind) + body + ending)]
    if len(matched) != 1:
        raise ValueError('TCM source differs from reviewed interface/body/guards: ' + name)
    # Preserve the original license/header and the exact existing port declaration.
    positions = masked(text)
    module_start = re.search(r'\bmodule\s+' + name + r'\s*\(', positions).start()
    body_start = positions.index(');', module_start) + 2
    end_start = re.search(r'\bendmodule\b', positions[body_start:]).start() + body_start
    return text[:body_start] + '\n' + adapted_body(kind) + text[end_start:], matched[0]


def prepare(platform):
    platform = os.path.realpath(os.path.abspath(platform))
    source_manifest_path = os.path.join(platform, 'source_manifest.json')
    tcm_manifest_path = os.path.join(platform, 'tcm_manifest.json')
    backup = os.path.join(platform, 'tcm_original')
    if os.path.exists(backup) or os.path.exists(tcm_manifest_path):
        raise ValueError('TCM adaptation already exists; use a new prepared platform directory')
    source_manifest_blob = read(source_manifest_path)
    manifest = json.loads(source_manifest_blob.decode('utf-8'))
    if manifest.get('schema') != 'kwt_platform_sources_v1':
        raise ValueError('Expected prepared platform source manifest v1')
    sources_path = os.path.join(platform, 'e203_sources.f')
    sources_blob = read(sources_path)
    sources = [line.strip() for line in sources_blob.decode('utf-8').splitlines() if line.strip()]
    if len(sources) != len(set(sources)):
        raise ValueError('Duplicate compilation source in prepared filelist')
    for path in sources:
        if not path.startswith('rtl/e203/') or '\\' in path or '..' in path.split('/'):
            raise ValueError('Unexpected source path: ' + path)
    replacements, originals, details = {}, {}, {}
    for kind in ('itcm', 'dtcm'):
        rel = 'core/e203_' + kind + '_ram.v'
        full = os.path.join(platform, 'e203', 'rtl', 'e203', rel)
        blob = read(full)
        record = manifest.get('files', {}).get(rel, {})
        if record.get('prepared_sha256') != digest(blob):
            raise ValueError('Prepared source hash differs from manifest: ' + rel)
        adapted, source_kind = adapt(blob.decode('utf-8-sig'), kind)
        originals[rel] = blob
        replacements[rel] = adapted
        details[rel] = dict(source_kind=source_kind, before_sha256=digest(blob),
                           after_sha256=digest(adapted.encode('utf-8')))
        if 'rtl/e203/' + rel not in sources:
            raise ValueError('TCM RAM module absent from prepared compilation list: ' + rel)

    # Preserve platform ROMs and other memories. The old TCM wrappers may stay
    # compiled: the adapted core no longer instantiates them. Exclude ONLY files
    # that would redefine the three macro types supplied by the runner.
    source_code, declared = {}, {}
    excluded = []
    for path in sources:
        rel = path[len('rtl/e203/'):]
        if rel not in manifest.get('files', {}):
            raise ValueError('Compilation source absent from manifest: ' + path)
        text = replacements.get(rel)
        if text is None:
            text = read(os.path.join(platform, 'e203', path)).decode('latin1')
        source_code[path] = code_only(text)
        declared[path] = set(MODULE.findall(source_code[path]))
        if declared[path] & EXTERNAL_MACROS:
            excluded.append(path)
    retained = [p for p in sources if p not in excluded]
    removed_modules = set()
    available_modules = set(EXTERNAL_MACROS)
    for path in excluded:
        removed_modules.update(declared[path])
    for path in retained:
        available_modules.update(declared[path])
    unavailable_modules = removed_modules - available_modules
    # A mixed source containing a duplicate SRAM and an unrelated needed ROM
    # cannot simply be discarded. Fail before writing rather than lose the ROM.
    for path in retained:
        tokens = set(re.findall(r'[A-Za-z_][A-Za-z0-9_$]*', source_code[path]))
        overlap = tokens & unavailable_modules
        if overlap:
            raise ValueError('Retained source references an excluded memory module: %s: %s' %
                             (path, ', '.join(sorted(overlap))))

    # All guards above are read-only; mutate only this generated platform copy.
    os.makedirs(backup)
    with open(os.path.join(backup, 'source_manifest.json'), 'wb') as stream:
        stream.write(source_manifest_blob)
    with open(os.path.join(backup, 'e203_sources.f'), 'wb') as stream:
        stream.write(sources_blob)
    for rel in sorted(replacements):
        original_path = os.path.join(backup, rel)
        if not os.path.isdir(os.path.dirname(original_path)):
            os.makedirs(os.path.dirname(original_path))
        with open(original_path, 'wb') as stream:
            stream.write(originals[rel])
        write(os.path.join(platform, 'e203', 'rtl', 'e203', rel), replacements[rel])
        manifest['files'][rel]['patched'] = True
        manifest['files'][rel]['prepared_sha256'] = details[rel]['after_sha256']
        manifest['files'][rel]['tcm_adaptation'] = details[rel]
    for path in excluded:
        rel = path[len('rtl/e203/'):]
        manifest['files'][rel]['compiled'] = False
        manifest['files'][rel]['excluded_reason'] = 'Duplicates explicitly supplied external SRAM macro types'
    tcm = dict(schema='kwt_tcm_adaptation_v1', files=details,
               verification='SOURCE_ADAPTATION_ONLY_NOT_CPU_SIMULATION_PASS',
               macro='RAMSP4096X16', itcm_bytes=262144, dtcm_bytes=262144,
               itcm_macros=32, dtcm_macros=32, original_backup='tcm_original',
               excluded_compilation_sources=excluded,
               excluded_module_names=sorted(removed_modules),
               externally_provided_modules=sorted(EXTERNAL_MACROS),
               compilation_policy='PRESERVE_PLATFORM_MEMORIES_EXCLUDE_EXTERNAL_MACRO_DUPLICATES_ONLY',
               runtime_checks='FPGA undefined; E203_HAS_ECC undefined; effective AW/DW/MW/DP assertions',
               required_extra_sources=['kwt_tcm_4096x16.v', 'vendor RAMSP4096X16 model'])
    manifest['tcm_adaptation'] = dict(manifest='tcm_manifest.json', macro='RAMSP4096X16',
                                     verification=tcm['verification'])
    write(sources_path, '\n'.join(retained) + '\n')
    write(source_manifest_path, json.dumps(manifest, indent=2, sort_keys=True) + '\n')
    write(tcm_manifest_path, json.dumps(tcm, indent=2, sort_keys=True) + '\n')
    return tcm


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--platform', required=True)
    args = parser.parse_args()
    try:
        result = prepare(args.platform)
    except (ValueError, IOError, OSError) as exc:
        print('ERROR:', str(exc), file=sys.stderr)
        return 2
    for rel in sorted(result['files']):
        print('TCM_ADAPTED %s %s' % (rel, result['files'][rel]['source_kind']))
    print('TCM_EXCLUDED_LEGACY_SOURCES %d' % len(result['excluded_compilation_sources']))
    print('TCM_PREPARED ITCM=262144 DTCM=262144; compile/run checks pending')
    return 0


if __name__ == '__main__':
    sys.exit(main())
