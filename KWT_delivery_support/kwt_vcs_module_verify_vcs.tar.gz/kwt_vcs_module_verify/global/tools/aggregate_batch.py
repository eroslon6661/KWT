#!/usr/bin/env python
"""Recheck ten independent simulator runs and summarize; Python 2.7/3 stdlib."""
from __future__ import print_function
import argparse
import json
import math
import os
import sys

import compare_chain as comparison

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CASES = ['01_yes', '02_no', '03_up', '04_down', '05_left',
         '06_right', '07_on', '08_off', '09_stop', '10_go']
LAYERS = 12


def execution_summary(result):
    execution = comparison.read_json(os.path.join(result, 'execution.json'))
    if (execution.get('hardware_layers_per_start') != 1 or
            execution.get('clock_period_ns') != 100 or
            execution.get('shared_target') != 'behavioral_ICB_random_wait'):
        raise ValueError('Execution clock, memory model or START mode differs from baseline')
    total = execution.get('cycles')
    elapsed = execution.get('load_to_output_elapsed_cycles')
    if (type(total) is not int or total <= 0 or isinstance(elapsed, bool) or
            not isinstance(elapsed, (int, float)) or not comparison.finite(elapsed) or
            elapsed <= 0 or elapsed > total):
        raise ValueError('Invalid actual functional cycle counts')
    if execution.get('irq') != 12:
        raise ValueError('Execution must complete twelve IRQs')
    return {'cycles': total, 'load_to_output_elapsed_cycles': elapsed,
            'clock_period_ns': 100, 'dma_reads': execution['dma_reads'],
            'dma_writes': execution['dma_writes'], 'starts': execution['starts'],
            'irq': execution['irq']}


def aggregate(run, root=ROOT):
    run = os.path.abspath(run)
    case_directory = os.path.join(run, 'cases')
    if not os.path.isdir(case_directory):
        raise ValueError('Run has no cases directory: ' + case_directory)
    unexpected = sorted(set(os.listdir(case_directory)) - set(CASES))
    rows = []
    full_reports = []
    for case_id in CASES:
        result = os.path.join(case_directory, case_id)
        row = {'case_id': case_id, 'status': 'FAIL', 'evaluated': False}
        try:
            # Recompute from authenticated stimulus, native references, raw HDL
            # exports and execution counts. Never trust a PASS string alone.
            fresh = comparison.compare_case(result, case_id, LAYERS, root)
            saved = comparison.read_json(os.path.join(result, 'numerical.json'))
            if saved != fresh:
                raise ValueError('Saved numerical report differs from freshly checked exports')
            marker = comparison.read_bytes(os.path.join(result, 'numerical_status.txt')).strip()
            if marker != fresh['status'].encode('ascii'):
                raise ValueError('Numerical status marker differs from checked report')
            classification = fresh['software_classification']
            if not fresh['classification_evaluated'] or classification is None:
                raise ValueError('Missing final-layer software classification')
            timing = execution_summary(result)
            row.update({
                'status': fresh['status'], 'evaluated': True,
                'sample_id': fresh['sample_id'], 'layers': LAYERS,
                'worst_layer': fresh['worst_layer'], 'worst_nrmse': fresh['worst_nrmse'],
                'global_tensor_nrmse': fresh['global_tensor_nrmse'],
                'true_label': classification['true_label'],
                'hardware_prediction': classification['hardware_output']['prediction'],
                'native_fp32_prediction': classification['native_fp32_output']['prediction'],
                'hardware_correct': classification['hardware_correct'],
                'reference_correct': classification['reference_correct'],
                'prediction_agreement': classification['prediction_agreement'],
                'numerical_json_sha256': comparison.sha256(os.path.join(result, 'numerical.json')),
                'execution_sha256': fresh['execution_sha256'],
                'input_sha256': fresh['encoder_input_fp16_sha256'],
                'execution': timing
            })
            full_reports.append(fresh)
        except (ValueError, KeyError, TypeError, IOError, OSError, OverflowError) as exc:
            row['error'] = str(exc)
        rows.append(row)
    complete = [row for row in rows if row['evaluated']]
    worst = max(complete, key=lambda row: row['worst_nrmse']) if complete else None
    elements = sum(report['elements'] for report in full_reports)
    error = math.fsum(report['global_error_sse'] for report in full_reports)
    reference = math.fsum(report['global_reference_sse'] for report in full_reports)
    pooled = (math.sqrt(error / elements) /
              max(math.sqrt(reference / elements), comparison.RMS_FLOOR)) if elements else None
    passed = sum(row['status'] == 'PASS' for row in rows)
    return {
        'schema': 'kwt_tcm_batch10_summary_v1',
        'status': 'PASS' if passed == 10 and not unexpected else 'FAIL',
        'scope': 'Ten fixed utterances, one per target command; not full evaluation-set accuracy',
        'pass_rule': 'All ten executions and all 120 individual layer NRMSE checks pass at <=0.03',
        'classification_is_software_postprocessing': True,
        'classification_correctness_is_not_nrmse_gate': True,
        'mode': comparison.MODE, 'hardware_layers_per_start': 1,
        'expected_samples': 10, 'evaluated_samples': len(complete), 'passed_samples': passed,
        'layers_per_sample': LAYERS, 'evaluated_layers': len(complete) * LAYERS,
        'unexpected_case_entries': unexpected, 'cases': rows,
        'worst_case': worst['case_id'] if worst else None,
        'worst_layer': worst['worst_layer'] if worst else None,
        'worst_nrmse': worst['worst_nrmse'] if worst else None,
        'pooled_tensor_nrmse_of_evaluated_cases': pooled,
        'pooled_metric_is_supplemental_not_threshold_gate': True,
        'threshold': comparison.THRESHOLD,
        'hardware_top1_correct': sum(row['hardware_correct'] for row in complete),
        'native_fp32_top1_correct': sum(row['reference_correct'] for row in complete),
        'hardware_native_prediction_agreements': sum(row['prediction_agreement'] for row in complete),
        'classification_denominator': len(complete),
        'total_functional_cycles': sum(row['execution']['cycles'] for row in complete),
        'total_load_to_output_elapsed_cycles': sum(row['execution']['load_to_output_elapsed_cycles'] for row in complete),
        'clock_period_ns': 100, 'shared_target': 'behavioral_ICB_random_wait',
        'timing_scope': 'Functional simulation only, not 150 MHz physical timing signoff',
        'cases_manifest_sha256': comparison.sha256(os.path.join(root, 'cases.json'))
    }


def write_summary(run, root=ROOT):
    if not os.path.isdir(run):
        raise ValueError('Run directory does not exist: ' + run)
    comparison.write_ascii(os.path.join(run, 'batch_status.txt'), 'INCOMPLETE\n')
    report = aggregate(run, root)
    comparison.write_ascii(os.path.join(run, 'batch_summary.json'),
                           json.dumps(report, indent=2, sort_keys=True, allow_nan=False) + '\n')
    comparison.write_ascii(os.path.join(run, 'batch_status.txt'), report['status'] + '\n')
    return report


def print_summary(report):
    for row in report['cases']:
        if row['evaluated']:
            print('%s CASE %s worst_layer=%d worst_NRMSE=%.10g HW=%s FP32=%s truth=%s' % (
                row['status'], row['case_id'], row['worst_layer'], row['worst_nrmse'],
                row['hardware_prediction'], row['native_fp32_prediction'], row['true_label']))
        else:
            print('FAIL CASE %s error=%s' % (row['case_id'], row.get('error', 'Incomplete')))
    print('%s BATCH10 samples=%d/10 evaluated_layers=%d/120 threshold=0.03' % (
        report['status'], report['passed_samples'], report['evaluated_layers']))
    if report['worst_case'] is not None:
        print('BATCH10_WORST case=%s layer=%d NRMSE=%.10g pooled_NRMSE=%.10g' % (
            report['worst_case'], report['worst_layer'], report['worst_nrmse'],
            report['pooled_tensor_nrmse_of_evaluated_cases']))
    print('BATCH10_SOFTWARE_TOP1 HW=%d/%d FP32=%d/%d agreement=%d/%d expected_samples=10' % (
        report['hardware_top1_correct'], report['classification_denominator'],
        report['native_fp32_top1_correct'], report['classification_denominator'],
        report['hardware_native_prediction_agreements'], report['classification_denominator']))
    print('Scope: ten-sample subset; software classifier; 100 ns functional clock; behavioral shared SRAM.')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run', required=True)
    args = parser.parse_args()
    try:
        report = write_summary(os.path.abspath(args.run))
        print_summary(report)
        return 0 if report['status'] == 'PASS' else 1
    except (ValueError, IOError, OSError) as exc:
        print('FAIL BATCH10 error=%s' % exc, file=sys.stderr)
        return 2


if __name__ == '__main__':
    sys.exit(main())
