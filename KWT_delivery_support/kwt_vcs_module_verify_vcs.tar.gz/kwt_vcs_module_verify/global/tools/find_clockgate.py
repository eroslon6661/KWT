#!/usr/bin/env python
"""Find the already-reviewed vendor gate model; no extraction or mutation."""
from __future__ import print_function
import glob
import hashlib
import json
import os
import sys

home = os.path.expanduser('~')
candidates = []
base = os.path.join(home, 'Desktop', 'kwt_platform_verify', 'runs')
for pattern in ('*/stdcell/standardcell_manifest.json',
                '*/return_platform/standardcell_manifest.json'):
    for path in glob.glob(os.path.join(base, pattern)):
        with open(path, 'rb') as stream:
            data = json.loads(stream.read().decode('utf-8-sig'))
        for item in data.get('sources', []):
            source = item.get('path', '')
            if os.path.isfile(source):
                with open(source, 'rb') as stream:
                    digest = hashlib.sha256(stream.read()).hexdigest()
                if digest == item.get('sha256'):
                    candidates.append(source)
index = os.path.join(home, 'kwt_project', 'library_index', 'S40_contents.txt')
if os.path.isfile(index):
    with open(index, 'rb') as stream:
        for line in stream.read().decode('utf-8-sig').splitlines():
            member = line.strip()
            if member.endswith('/scc40nll_vhsc40_rvt.v') and '..' not in member.split('/'):
                source = os.path.join(home, 'kwt_project', 'lib_models', member)
                if os.path.isfile(source):
                    candidates.append(source)
versions = {}
for source in sorted(set(candidates)):
    with open(source, 'rb') as stream:
        versions.setdefault(hashlib.sha256(stream.read()).hexdigest(), source)
if len(versions) != 1:
    print('ERROR: Cannot uniquely find the reviewed clock-gate model; set CLOCKGATE_LIB_V.', file=sys.stderr)
    for source in sorted(set(candidates)):
        print(source, file=sys.stderr)
    sys.exit(2)
print(next(iter(versions.values())))
