#!/usr/bin/env python
"""Validate and retarget one generated platform clock gate (Python 2.7/3).

This does not change the platform archive or the vendor model. It changes the
already-prepared GENERIC_CLOCKGATE_RVT instance to the verified 12TR40 model.
Only static-TE functional compatibility is intended; dynamic TE, physical,
timing and formal equivalence to the unavailable 8TR40 cell are not claimed.
"""
from __future__ import print_function
import argparse
import io
import json
import os
import re
import sys

from prepare_sram_models import absolute, clean, dependencies, read, sha, unique

try:
    TEXT = unicode
except NameError:
    TEXT = str

SOURCE_KEY = 'generic/GENERIC_RVT_SMIC.v'
WRAPPER = 'GENERIC_CLOCKGATE_RVT'
INSTANCE = 'u_donttouch_CLOCKGATE'
OLD_CELL = 'CLKLANAQV4_8TR40'
NEW_CELL = 'CLKLANAQV4_12TR40'
EXPECTED_WRAPPER = """
module GENERIC_CLOCKGATE_RVT (ECK, E, SE, CK);
output ECK;
input E, SE, CK;
`ifdef FPGA
reg latch_out;
always @ (CK or E or SE) begin
if(!CK) begin
latch_out = E | SE;
end
end
assign ECK = latch_out & CK;
`else
CLKLANAQV4_8TR40 u_donttouch_CLOCKGATE(.Q(ECK), .E(E), .TE(SE), .CK(CK));
`endif
endmodule
"""
COMMENT_OR_STRING = re.compile(r'"(?:\\.|[^"\\])*"|//[^\n]*|/\*.*?\*/', re.S)


def canonical(text):
    return ''.join(clean(text).split())


def masked(text):
    # Preserve character offsets when locating module blocks in the original.
    return COMMENT_OR_STRING.sub(lambda m: ''.join('\n' if c == '\n' else ' ' for c in m.group(0)), text)


def blocks(text, kind, name, end):
    pattern = r'\b' + kind + r'\s+' + re.escape(name) + r'\b.*?\b' + end + r'\b'
    return list(re.finditer(pattern, masked(text), re.S))


def text_write(path, value):
    if not isinstance(value, TEXT):
        value = value.decode('utf-8')
    with io.open(path, 'w', encoding='utf-8', newline='\n') as stream:
        stream.write(value)


def json_text(value):
    return json.dumps(value, indent=2, sort_keys=True, ensure_ascii=True) + u'\n'


def verify_model(model):
    includes = [os.path.dirname(model)]
    records, edges = {}, []
    dependencies(model, includes, records, edges)
    includes = unique(includes + [os.path.dirname(p) for p in sorted(records)])
    final_records, final_edges = {}, []
    dependencies(model, includes, final_records, final_edges)
    targets, udps = [], []
    for path in sorted(final_records):
        blob = read(path)
        if sha(blob) != final_records[path]['sha256']:
            raise ValueError('Vendor source changed during preparation: ' + path)
        text = blob.decode('latin1')
        for match in blocks(text, 'module', NEW_CELL, 'endmodule'):
            targets.append((path, text[match.start():match.end()]))
        for match in blocks(text, 'primitive', 'udp_tlat', 'endprimitive'):
            udps.append((path, text[match.start():match.end()]))
    if len(targets) != 1:
        raise ValueError('Expected exactly one vendor module ' + NEW_CELL + '; found ' + str(len(targets)))
    if targets[0][0] != model:
        raise ValueError('The selected vendor source must directly define ' + NEW_CELL)
    if len(udps) != 1:
        raise ValueError('Expected exactly one primitive udp_tlat in vendor dependency closure')
    body = canonical(targets[0][1])
    if not body.startswith('module' + NEW_CELL + '(Q,CK,E,TE);'):
        raise ValueError('Unexpected vendor clock gate port order/names')
    # Check the reviewed non-ANSI directions independently of grouping/layout.
    directions = {}
    for direction, names in re.findall(r'\b(input|output|inout)\s+([^;]+);', clean(targets[0][1])):
        for name in names.split(','):
            name = name.strip()
            if not re.match(r'^[A-Za-z_][A-Za-z0-9_$]*$', name) or name in directions:
                raise ValueError('Unexpected or repeated vendor clock gate pin declaration')
            directions[name] = direction
    if directions != {'Q':'output', 'CK':'input', 'E':'input', 'TE':'input'}:
        raise ValueError('Unexpected vendor clock gate pin directions')
    reviewed = ('udp_tlatI3(n1,xE,clk,xRN,xSN,NOTIFIER);',
                'orI4(n0,n1,xTE);', 'andI5(Q,n0,clk);')
    if any(body.count(token) != 1 for token in reviewed):
        raise ValueError('Vendor clock gate differs from reviewed latch/TE-after-latch structure')
    for output, source in (('clk', 'CK'), ('xTE', 'TE'), ('xE', 'E')):
        pattern = r'buf[A-Za-z_][A-Za-z0-9_$]*\(' + output + ',' + source + r'\);'
        if len(re.findall(pattern, body)) != 1:
            raise ValueError('Unexpected vendor input buffer connection: ' + output)
    if not ('supply1xRN,xSN;' in body or ('supply1xRN;' in body and 'supply1xSN;' in body)):
        raise ValueError('Vendor latch set/reset supplies differ from reviewed model')
    return final_records, final_edges, includes, targets[0], udps[0]


def prepare(platform, model, output):
    platform = os.path.realpath(os.path.abspath(platform))
    model = absolute(model, os.getcwd())
    output = os.path.abspath(output)
    if os.path.exists(output):
        raise ValueError('Output must not exist; choose a fresh directory: ' + output)
    manifest_path = os.path.join(platform, 'source_manifest.json')
    manifest_blob = read(manifest_path)
    manifest = json.loads(manifest_blob.decode('utf-8-sig'))
    if manifest.get('schema') != 'kwt_platform_sources_v1':
        raise ValueError('Unsupported platform source manifest')
    if manifest.get('technology_adaptation'):
        raise ValueError('Platform is already technology-adapted; prepare fresh platform sources')
    source = os.path.join(platform, 'e203', 'rtl', 'e203', *SOURCE_KEY.split('/'))
    blob = read(source)
    row = manifest.get('files', {}).get(SOURCE_KEY)
    if not isinstance(row, dict) or row.get('compiled') is not True:
        raise ValueError('Generated clock gate source is absent from compiled source manifest')
    if row.get('prepared_sha256') != sha(blob):
        raise ValueError('Generated clock gate source SHA256 mismatch')
    for field in ('original_byte_sha256', 'original_text_sha256'):
        if re.match(r'^[0-9a-f]{64}$', row.get(field, '')) is None:
            raise ValueError('Missing original platform source identity: ' + field)
    text = blob.decode('utf-8-sig')
    wrappers = blocks(text, 'module', WRAPPER, 'endmodule')
    if len(wrappers) != 1:
        raise ValueError('Expected exactly one ' + WRAPPER + ' module')
    match = wrappers[0]
    old_block = text[match.start():match.end()]
    expected_canonical = canonical(EXPECTED_WRAPPER)
    if canonical(old_block) != expected_canonical:
        raise ValueError('Clock gate mapping block differs from the reviewed platform screenshot')
    # Exact validated block, exact instance type; unrelated technology wrappers stay intact.
    anchor = re.compile(r'\b' + OLD_CELL + r'(\s+' + INSTANCE + r'\s*\()')
    new_block, count = anchor.subn(NEW_CELL + r'\1', old_block)
    if count != 1:
        raise ValueError('Clock gate replacement must match exactly one instance')
    patched = text[:match.start()] + new_block + text[match.end():]
    records, edges, includes, target, udp = verify_model(model)
    mapping = dict(wrapper_source=SOURCE_KEY, wrapper_module=WRAPPER, instance=INSTANCE,
        from_cell=OLD_CELL, to_cell=NEW_CELL,
        pins={'Q':'ECK', 'E':'E', 'TE':'SE', 'CK':'CK'},
        original_prepared_sha256=sha(blob), prepared_sha256=sha(patched.encode('utf-8')),
        original_block_canonical_sha256=sha(expected_canonical.encode('ascii')),
        patched_block_canonical_sha256=sha(canonical(new_block).encode('ascii')))
    model_manifest = dict(schema='kwt_clockgate_models_v1', source_kind='EXPLICIT_VENDOR_MODEL',
        verification='SOURCE_VALIDATION_AND_MAPPING_ONLY_NOT_SIMULATION_PASS',
        scope='STATIC_TE_FUNCTIONAL_COMPATIBILITY_ONLY',
        dynamic_te_equivalence_claimed=False, formal_equivalence_claimed=False,
        timing_equivalence_claimed=False, physical_equivalence_claimed=False,
        vendor_te_implementation='TE_OR_AFTER_LOW_LEVEL_E_LATCH',
        wrapper_fpga_implementation='LOW_LEVEL_LATCH_OF_E_OR_SE',
        qualification='TE must remain static; no equivalence for asynchronous TE transitions is claimed.',
        backend_requirement='Use this same adapted RTL and matching 12TR40 Liberty and physical views for DC/formal/PT.',
        mapping=mapping, defines=[], required_compile_defines=['functional'],
        simulation_scope='FUNCTIONAL_VENDOR_MODEL_NO_SDF', sources=[records[model]],
        dependencies=[records[p] for p in sorted(records) if p != model],
        include_dirs=includes, include_edges=edges,
        modules={NEW_CELL:target[0]}, primitives={'udp_tlat':udp[0]},
        vendor_module_canonical_sha256=sha(canonical(target[1]).encode('latin1')),
        vendor_udp_canonical_sha256=sha(canonical(udp[1]).encode('latin1')),
        include_policy='ALL_LITERAL_INCLUDES_INCLUDING_CONDITIONAL_BRANCHES')
    model_json = json_text(model_manifest)
    adaptation = dict(mapping)
    adaptation.update(name='SMIC40_RVT_CLOCKGATE_12TR40',
        scope=model_manifest['scope'], standardcell_manifest='standardcell_manifest.json',
        standardcell_manifest_sha256=sha(model_json.encode('utf-8')))
    manifest['technology_adaptation'] = adaptation
    row['prepared_sha256'] = mapping['prepared_sha256']
    row['patched'] = True
    # All validations precede mutation. Never write to the vendor source or ZIP.
    if read(source) != blob or read(manifest_path) != manifest_blob:
        raise ValueError('Generated platform changed concurrently; refusing to overwrite')
    os.makedirs(output)
    text_write(os.path.join(output,'standardcell_manifest.json'), model_json)
    filelist = u''.join(u'+incdir+%s\n' % p.replace('\\','/') for p in includes)
    filelist += model.replace('\\','/') + u'\n'
    text_write(os.path.join(output,'standardcell.f'), filelist)
    text_write(os.path.join(output,'patched_clockgate.v'), new_block + u'\n')
    try:
        text_write(source, patched)
        text_write(manifest_path, json_text(manifest))
    except Exception:
        # Restore only the two generated files for an interrupted local update.
        with open(source,'wb') as stream: stream.write(blob)
        with open(manifest_path,'wb') as stream: stream.write(manifest_blob)
        raise
    return model_manifest


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--platform', required=True)
    parser.add_argument('--model', required=True)
    parser.add_argument('--output', required=True)
    args = parser.parse_args()
    try:
        prepare(args.platform, args.model, args.output)
    except (ValueError, IOError, OSError) as exc:
        print('ERROR:', str(exc), file=sys.stderr)
        return 2
    print('PREPARED static-TE clock gate mapping; simulation validation is still required.')
    print(os.path.join(os.path.abspath(args.output), 'standardcell_manifest.json'))
    return 0


if __name__ == '__main__':
    sys.exit(main())
