#!/usr/bin/env python
# Python 2.7 / 3.x. Never changes the input platform archive or source tree.
from __future__ import print_function
import argparse
import hashlib
import io
import json
import os
import re
import zipfile

HERE = os.path.dirname(os.path.abspath(__file__))
try:
    text_type = unicode
except NameError:
    text_type = str
KNOWN = {
 'subsys/e203_subsys_main.v': '4258161cac87bc56ef19f22ee8c82dbcae9d3effb2f0159282d3f8acd85c015c',
 'subsys/e203_subsys_mems.v': 'dc63cbcc9ebe9331c824c27f6f3645f0f330740573ee1b9a52dc5ca259a339fd',
 'subsys/e203_subsys_perips.v': '9a7e4dd76b55e327eb2a81fbce44404b617fc045060a251e0898970ef2ddf1cb',
 'subsys/e203_subsys_plic.v': 'e4404a0972696a3a650b5e6d134b733798c09dcaed3248abce477337d30eb8f1',
 'subsys/e203_subsys_top.v': 'dcf1a6d8161f724926ef5fb58c52b67c9911444abbd08901b5fb9bd158b0339f',
 'soc/e203_soc_top.v': '97bfe3fd1119b4682589a48f57a60e108d496e2c1c1a53d7c0255b50fe79c02b'
}
SIGNALS = [('cmd_valid',1),('cmd_ready',1),('cmd_addr',32),('cmd_read',1),
           ('cmd_wdata',32),('cmd_wmask',4),('rsp_valid',1),('rsp_ready',1),
           ('rsp_rdata',32),('rsp_err',1)]
MASTER_OUT = ('cmd_valid','cmd_addr','cmd_read','cmd_wdata','cmd_wmask','rsp_ready')

def digest(data):
    return hashlib.sha256(data).hexdigest()

def config_semantics(text):
    # Keep preprocessor directives and values, but ignore comments/formatting.
    # This guards platform configuration beyond the two TCM size fields.
    text = re.sub(r'/\*.*?\*/', '', text, flags=re.S)
    text = re.sub(r'//[^\n]*', '', text)
    return ''.join(text.split())

def write(path, text):
    if not isinstance(text, text_type):
        text = text.decode('utf-8')
    parent = os.path.dirname(path)
    if not os.path.isdir(parent):
        os.makedirs(parent)
    with io.open(path, 'w', encoding='utf-8', newline='\n') as stream:
        stream.write(text)

def once(text, old, new):
    if text.count(old) != 1:
        raise ValueError('Patch anchor must occur exactly once: ' + old[:100])
    return text.replace(old, new, 1)

def bus_wires(prefix):
    return '\n'.join('wire %s%s_%s;' % (('['+str(w-1)+':0] ') if w>1 else '',prefix,n) for n,w in SIGNALS)

def patch_main(text):
    ports = ['input kwt_irq,','output kwt_bus_rst_n,','output [31:0] kwt_inspect_pc,','output kwt_cpu_irq,']
    for n,w in SIGNALS:
        direction = 'input' if n in MASTER_OUT else 'output'
        ports.append('%s %skwt_dma_%s,' % (direction, ('['+str(w-1)+':0] ') if w>1 else '', n))
    text = once(text, 'module e203_subsys_main(', 'module e203_subsys_main(\n  ' + '\n  '.join(ports))
    text = once(text, 'endmodule', '\n assign kwt_inspect_pc = inspect_pc;\n assign kwt_bus_rst_n = bus_rst_n;\n assign kwt_cpu_irq = plic_ext_irq;\nendmodule')
    text = once(text, 'e203_subsys_plic u_e203_subsys_plic(', 'e203_subsys_plic u_e203_subsys_plic(\n    .kwt_irq(kwt_irq),')
    anchor = 'e203_subsys_mems u_e203_subsys_mems('
    split = text.index(anchor)
    before, after = text[:split], text[split:]
    for n,w in SIGNALS:
        pattern = r'(\.mem_icb_' + n + r'\s*\()mem_icb_' + n + r'(\s*\))'
        after, count = re.subn(pattern, r'\1kwt_fabric_' + n + r'\2', after)
        if count != 1: raise ValueError('MEM patch count: '+n)
    conns = ['.clk(hfclk)', '.rst_n(bus_rst_n)']
    for port,wire in [('u','mem_icb'),('d','kwt_dma'),('s','kwt_fabric')]:
        conns += ['.%s_%s(%s_%s)'%(port,n,wire,n) for n,w in SIGNALS]
    arb = '\n' + bus_wires('kwt_fabric') + '\nkwt_icb_arb2 u_kwt_mem_arb(\n  '+',\n  '.join(conns)+'\n);\n'
    return before + arb + after

def main():
    parser = argparse.ArgumentParser()
    source = parser.add_mutually_exclusive_group(required=True)
    source.add_argument('--platform-zip')
    source.add_argument('--public-source')
    parser.add_argument('--output', required=True)
    args = parser.parse_args()
    out = os.path.abspath(args.output)
    if os.path.exists(out):
        raise ValueError('Output must not exist; use a new run directory: '+out)
    with io.open(os.path.join(HERE,'public_source_hashes.json'),encoding='utf-8') as stream:
        expected = json.load(stream)
    blobs = {}
    if args.platform_zip:
        prefix = 'e203_hbirdv2-master/rtl/e203/'
        with zipfile.ZipFile(args.platform_zip) as archive:
            for entry in archive.infolist():
                name=entry.filename
                if name.startswith(prefix) and name.endswith(('.v','.vh','.sv','.svh')):
                    rel=name[len(prefix):]
                    if '\\' in rel or '..' in rel.split('/') or rel.startswith('/') or rel in blobs:
                        raise ValueError('Unsafe/duplicate ZIP member: '+name)
                    if entry.file_size > 20*1024*1024: raise ValueError('Unexpected large source: '+name)
                    blobs[rel]=archive.read(entry)
        source_kind='SERVER_PLATFORM_ARCHIVE'
    else:
        base=os.path.join(os.path.abspath(args.public_source),'rtl','e203')
        for folder,dirs,files in os.walk(base):
            for filename in files:
                if filename.endswith(('.v','.vh','.sv','.svh')):
                    path=os.path.join(folder,filename)
                    with open(path,'rb') as stream: blobs[os.path.relpath(path,base).replace(os.sep,'/')]=stream.read()
        source_kind='LOCAL_PUBLIC_SOURCE_WITH_DERIVED_PLATFORM_TCM_CONFIG'
    # Byte hashes are recorded. Canonical text hashes allow line-ending-only differences.
    canonical={k:v.decode('utf-8-sig').replace('\r\n','\n').replace('\r','\n') for k,v in blobs.items()}
    for rel,known in KNOWN.items():
        if rel not in blobs: raise ValueError('Missing known platform source: '+rel)
        if digest(blobs[rel]) != known and digest(canonical[rel].encode('utf-8')) != expected[rel]['text_sha256']:
            raise ValueError('Known platform boundary changed; review required: '+rel)
    patch_path='perips/sirv_plic_top.v'
    if patch_path not in canonical or digest(canonical[patch_path].encode('utf-8')) != expected[patch_path]['text_sha256']:
        raise ValueError('PLIC extension source changed; review before patching.')
    cfg=canonical['core/config.v']
    for key in ('E203_CFG_ITCM_ADDR_WIDTH','E203_CFG_DTCM_ADDR_WIDTH'):
        pattern=r'(?m)^([ \t]*`define[ \t]+'+key+r'[ \t]+)(\d+)'
        values=re.findall(pattern,cfg)
        if len(values)!=1: raise ValueError('Configuration must have exactly one active definition: '+key)
        if args.public_source:
            cfg=re.sub(pattern,lambda m:m.group(1)+'18',cfg)
        elif values[0][1]!='18': raise ValueError('Expected platform TCM width18: '+key)
    if digest(config_semantics(cfg).encode('utf-8')) != expected['core/config.v']['platform_semantic_sha256']:
        raise ValueError('Platform configuration differs beyond expected TCM width18; review required.')
    original=dict(canonical)
    canonical['core/config.v']=cfg
    canonical['subsys/e203_subsys_main.v']=patch_main(canonical['subsys/e203_subsys_main.v'])
    plic=canonical['subsys/e203_subsys_plic.v']
    plic=once(plic,'module e203_subsys_plic(','module e203_subsys_plic(\n  input kwt_irq,')
    plic=once(plic,'sirv_plic_top u_sirv_plic_top(','sirv_plic_top u_sirv_plic_top(\n    .io_devices_0_16(kwt_irq),')
    canonical['subsys/e203_subsys_plic.v']=plic
    top=canonical[patch_path]
    top=once(top,'  input   io_devices_0_15,','  input   io_devices_0_15,\n  input   io_devices_0_16,')
    top=once(top,'localparam PLIC_IRQ_NUM = 17;','localparam PLIC_IRQ_NUM = 18;')
    top=once(top,'                  io_devices_0_15  ,','                  io_devices_0_16  ,\n                  io_devices_0_15  ,')
    canonical[patch_path]=top
    compiled=[]
    includes=set()
    differences=[]
    manifest={'schema':'kwt_platform_sources_v1','source_kind':source_kind,
              'source_path':os.path.abspath(args.platform_zip or args.public_source),
              'source_archive_sha256':None,
              'verification':'SOURCE_PREPARATION_ONLY_NOT_SIMULATION_PASS',
              'boundary':'e203_subsys_main with platform PPI/MEM/PLIC; external AON/debug inactive; no pad-ring verification',
              'irq_id':17,'itcm_bytes':262144,'dtcm_bytes':262144,'files':{}}
    if args.platform_zip:
        h=hashlib.sha256()
        with open(args.platform_zip,'rb') as stream:
            while True:
                block=stream.read(1024*1024)
                if not block: break
                h.update(block)
        manifest['source_archive_sha256']=h.hexdigest()
    for rel in sorted(canonical):
        text=canonical[rel]
        write(os.path.join(out,'e203','rtl','e203',*rel.split('/')),text)
        path='rtl/e203/'+rel
        # Exclude untouched outer wrappers not instantiated at this integration boundary.
        is_module=bool(re.search(r'(?m)^\s*module\s+',text))
        compile_this=is_module and not rel.startswith(('debug/','soc/')) and rel!='subsys/e203_subsys_top.v'
        if compile_this: compiled.append(path)
        includes.add(os.path.dirname(path).replace(os.sep,'/'))
        text_sha=digest(original[rel].encode('utf-8'))
        manifest['files'][rel]={'original_byte_sha256':digest(blobs[rel]),'original_text_sha256':text_sha,
            'prepared_sha256':digest(text.encode('utf-8')),'patched':original[rel]!=text,'compiled':compile_this,
            'matches_pinned_public_text': rel in expected and text_sha==expected[rel]['text_sha256']}
        if compile_this or rel=='core/config.v':
            if not manifest['files'][rel]['matches_pinned_public_text']:
                differences.append(rel+' '+text_sha)
    write(os.path.join(out,'e203_sources.f'),'\n'.join(compiled)+'\n')
    write(os.path.join(out,'include_dirs.txt'),'\n'.join(sorted(includes))+'\n')
    write(os.path.join(out,'source_manifest.json'),json.dumps(manifest,indent=2,sort_keys=True)+'\n')
    write(os.path.join(out,'source_differences.txt'),
          'Original compiled sources/config differing from pinned public text:\n'+
          ('\n'.join(differences) if differences else '(none)')+'\n'+
          'All originals and prepared source hashes are in source_manifest.json.\n'+
          'Expected platform config changes: ITCM/DTCM address width 18.\n')
    print('PREPARED '+source_kind+'; compiled files='+str(len(compiled)))
    print('Original source/config differences from pinned public: '+str(len(differences)))
    for item in differences: print('SOURCE_DIFFERENCE '+item)
    print('Root: '+out)

if __name__=='__main__':
    main()
