#ifndef KWT_PLATFORM_MAP_H
#define KWT_PLATFORM_MAP_H
#define KWT_CFG_BASE       0x11000000u
#define KWT_INPUT_BASE     0xa0000000u
#define KWT_OUTPUT_BASE    0xa0004000u
#define KWT_PARAM_BASE     0xa0010000u
#define KWT_PARAM_STRIDE   0x0000d000u
/* REPORT_BASE is also consumed by preprocessed assembly. */
#define KWT_REPORT_BASE    0xa007f000
#define KWT_SCRATCH_BASE   0xa007e000u
#define KWT_READY_SEQ      0xa007d000u
#define KWT_REQUEST_SEQ    0xa007d004u
#define KWT_COMPLETED_SEQ  0xa007f028u
#define KWT_LAYER_HASH_BASE 0xa007f100u
#define KWT_READY_MAX_POLLS 1000000u
#define KWT_IRQ_ID         17u
#define PLIC_PRIORITY     0x0c000044u
#define PLIC_ENABLE       0x0c002000u
#define PLIC_THRESHOLD    0x0c200000u
#define PLIC_CLAIM        0x0c200004u
#endif
