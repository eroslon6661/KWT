#include "platform_map.h"
typedef unsigned int u32;
#ifndef CHAIN_LAYERS
#define CHAIN_LAYERS 12
#endif
#if CHAIN_LAYERS < 1 || CHAIN_LAYERS > 12
#error CHAIN_LAYERS_must_be_between_1_and_12
#endif
#define MMIO(addr) (*(volatile u32 *)(addr))
#define REG(off) MMIO(KWT_CFG_BASE + (off))
#define REPORT(off) MMIO(KWT_REPORT_BASE + (off))
volatile u32 irq_seen, irq_error, irq_status, irq_claim;

__attribute__((noinline, used, section(".itcm_high")))
u32 itcm_high_probe(u32 value)
{
    return (value ^ 0x69c3a57eu) + 0x01020304u;
}

void accelerator_irq(void)
{
    u32 claimed = MMIO(PLIC_CLAIM);
    u32 status;
    irq_claim = claimed;
    if (claimed == 0u) return;
    if (claimed != KWT_IRQ_ID) {
        irq_error = 0x200u | claimed;
    } else {
        status = REG(0x08);
        irq_status = status;
        if (status & 4u) irq_error = REG(0x24) | 0x100u;
        if (status & 6u) REG(0x08) = status & 6u;
        else irq_error = 0x300u | status;
    }
    /* Clear the level source before completing the PLIC claim. */
    __asm__ volatile("fence iorw, iorw" ::: "memory");
    MMIO(PLIC_CLAIM) = claimed;
    __asm__ volatile("fence iorw, iorw" ::: "memory");
    irq_seen++;
}

int main(void)
{
    volatile u32 *scratch = (volatile u32 *)KWT_SCRATCH_BASE;
    u32 input_base = KWT_INPUT_BASE, output_base = KWT_OUTPUT_BASE;
    u32 total_ticks = 0, layer, i;
    u32 (*volatile high_fn)(u32) = itcm_high_probe;
    irq_seen = 0; irq_error = 0; irq_status = 0; irq_claim = 0;
    for (i = 0; i <= 0x28; i += 4) REPORT(i) = 0;
    for (i = 0; i < CHAIN_LAYERS; ++i)
        MMIO(KWT_LAYER_HASH_BASE + 4u * i) = 0;
    MMIO(KWT_REQUEST_SEQ) = 0;
    if (high_fn(0x13579bdfu) != ((0x13579bdfu ^ 0x69c3a57eu) + 0x01020304u))
        return 15;
    if (REG(0) != 0x4b575431u) return 10;
    if (REG(8) != 0) return 11;
    MMIO(PLIC_PRIORITY) = 1u;
    MMIO(PLIC_THRESHOLD) = 0u;
    MMIO(PLIC_ENABLE) = 0;
    for (layer = 0; layer < CHAIN_LAYERS; ++layer) {
        volatile u32 *output = (volatile u32 *)output_base;
        u32 expected = layer + 1u, ticks = 0, hash = 2166136261u, swap;

        /* READY belongs to the external ICB loader. A unique sequence prevents
           the previous parameter image from acknowledging this new request. */
        __asm__ volatile("fence iorw, iorw" ::: "memory");
        MMIO(KWT_REQUEST_SEQ) = expected;
        __asm__ volatile("fence iorw, iorw" ::: "memory");
        for (i = 0; i < KWT_READY_MAX_POLLS; ++i) {
            u32 ready = MMIO(KWT_READY_SEQ);
            if (ready > expected) return 16;
            if (ready == expected) break;
        }
        if (i == KWT_READY_MAX_POLLS) return 14;
        __asm__ volatile("fence iorw, iorw" ::: "memory");
        if (REG(8) != 0 || irq_seen != layer) return 11;
        irq_error = 0; irq_status = 0; irq_claim = 0;
        REG(0x10) = input_base;
        REG(0x14) = output_base;
        REG(0x18) = KWT_PARAM_BASE;
        REG(0x1c) = KWT_PARAM_STRIDE;
        /* Software chains layers; each hardware command executes one layer. */
        REG(0x20) = 1;
        REG(0x0c) = 1;
        if (REG(0x20) != 1u) return 12;
        MMIO(PLIC_ENABLE) = 1u << KWT_IRQ_ID;
        if (MMIO(PLIC_PRIORITY) != 1u || MMIO(PLIC_ENABLE) != (1u << KWT_IRQ_ID)) return 13;
        __asm__ volatile("csrs mie, %0" :: "r"(0x800u) : "memory");
        __asm__ volatile("csrsi mstatus, 8" ::: "memory");
        __asm__ volatile("fence iorw, iorw" ::: "memory");
        REG(4) = 1;
        /* Exercise CPU/DMA contention on every layer, with a per-layer bound. */
        while (irq_seen == layer) {
            ticks++;
            *scratch = ticks ^ 0x12345678u;
            if (*scratch != (ticks ^ 0x12345678u)) return 20;
            if (ticks > 1000000u) return 21;
        }
        __asm__ volatile("csrci mstatus, 8" ::: "memory");
        __asm__ volatile("csrw mie, zero" ::: "memory");
        MMIO(PLIC_ENABLE) = 0;
        __asm__ volatile("fence iorw, iorw" ::: "memory");
        if (irq_error) return 22;
        if (irq_seen != expected || irq_status != 2 || irq_claim != KWT_IRQ_ID) return 23;
        if (REG(8) != 0 || REG(0x24) != 0) return 24;
        REG(0x0c) = 0;
        for (i = 0; i < 3168; ++i) hash = (hash ^ output[i]) * 16777619u;
        total_ticks += ticks;
        REPORT(0) = irq_status; REPORT(4) = CHAIN_LAYERS;
        REPORT(8) = total_ticks; REPORT(12) = irq_seen;
        REPORT(16) = hash; REPORT(20) = irq_claim;
        MMIO(KWT_LAYER_HASH_BASE + 4u * layer) = hash;
        /* Publish completion only after the IRQ was cleared/completed and the
           actual output was hashed. The next request follows this publication. */
        __asm__ volatile("fence iorw, iorw" ::: "memory");
        MMIO(KWT_COMPLETED_SEQ) = expected;
        __asm__ volatile("fence iorw, iorw" ::: "memory");
        swap = input_base; input_base = output_base; output_base = swap;
    }
    /* No golden data is injected. Each next input is the actual prior output. */
    return 0;
}
