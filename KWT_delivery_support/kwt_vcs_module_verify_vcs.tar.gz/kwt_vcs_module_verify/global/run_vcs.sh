#!/usr/bin/env bash
# Compile once; run ten independent 12-layer CPU chains in fresh case directories.
set -eo pipefail
export LC_ALL=C
root=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
python_bin=${PYTHON_BIN:-python}
export CHAIN_LAYERS=${CHAIN_LAYERS:-12}
[[ "$CHAIN_LAYERS" == 12 ]] || { printf 'This batch requires CHAIN_LAYERS=12\n' >&2; exit 2; }
vcs_bin=${VCS_BIN:-vcs}
platform_zip=${PLATFORM_ZIP:-/storage1/admin_public_dir/SOC_RTL_2025/e203_hbirdv2-master_1013_update_sim.zip}
library=${SRAM_LIBRARY:-/storage1/admin_public_dir/SRAM_Lib_2025}
command -v "$python_bin" >/dev/null
command -v "$vcs_bin" >/dev/null
[[ -n "${RISCV_TOOLCHAIN:-}" ]] || source "$HOME/Desktop/kwt_e203_offline/env.sh"
# Resolve caller-relative overrides before any clock-gate/build directory change.
sram_filelist=
if [[ -n "${SRAM_FILELIST:-}" ]]; then sram_filelist=$(readlink -f -- "$SRAM_FILELIST"); fi
clockgate_lib=${CLOCKGATE_LIB_V:-}
if [[ -n "$clockgate_lib" ]]; then clockgate_lib=$(readlink -f -- "$clockgate_lib"); fi
mkdir -p "$root/runs"
run=$(mktemp -d "$root/runs/batch10_XXXXXXXX")
stage=package_check
stage_log="$run/$stage.log"
current_case=
completed=0
printf 'INCOMPLETE\n' > "$run/runner_status.txt"
printf 'Run directory: %s\n' "$run"
failure() {
    local status=$?
    trap - ERR
    set +e
    printf 'INCOMPLETE\n' > "$run/runner_status.txt"
    printf 'FAILED case=%s stage=%s completed=%s/10; logs=%s\n' \
        "${current_case:-setup}" "$stage" "$completed" "$run" >&2
    [[ ! -f "$stage_log" ]] || tail -n 45 "$stage_log" >&2
    # The aggregator may produce a useful partial summary. Its exit code must
    # never replace the original failed preparation/simulation/comparison code.
    if [[ -n "$current_case" && -f "$root/tools/aggregate_batch.py" ]]; then
        "$python_bin" "$root/tools/aggregate_batch.py" --run "$run" \
            > "$run/aggregate_incomplete.log" 2>&1
        printf 'Partial aggregation log: %s\n' "$run/aggregate_incomplete.log" >&2
    fi
    exit "$status"
}
trap failure ERR
require_pass_marker() {
    if [[ ! -f "$1" ]] || [[ "$(tr -d '\r\n' < "$1")" != PASS ]]; then
        printf 'Missing PASS marker: %s\n' "$1" >&2
        return 1
    fi
}
cd "$root"
sha256sum -c SHA256SUMS > "$stage_log" 2>&1
stage=platform_prepare
stage_log="$run/$stage.log"
"$python_bin" "$root/prepare_platform.py" --platform-zip "$platform_zip" --output "$run/platform" > "$stage_log" 2>&1
stage=tcm_prepare
stage_log="$run/$stage.log"
"$python_bin" "$root/tools/prepare_tcm.py" --platform "$run/platform" > "$stage_log" 2>&1
stdcell_list=
if [[ -f "$run/platform/e203/rtl/e203/generic/GENERIC_RVT_SMIC.v" ]] && \
   grep -q 'CLKLANAQV4_8TR40' "$run/platform/e203/rtl/e203/generic/GENERIC_RVT_SMIC.v"; then
    stage=clockgate_find
    stage_log="$run/$stage.log"
    if [[ -z "$clockgate_lib" ]]; then
        "$python_bin" "$root/tools/find_clockgate.py" > "$run/clockgate_path.txt" 2> "$run/$stage.log"
        clockgate_lib=$(cat "$run/clockgate_path.txt")
    fi
    stage=clockgate_prepare
    stage_log="$run/$stage.log"
    "$python_bin" "$root/tools/prepare_clockgate.py" --platform "$run/platform" \
        --model "$clockgate_lib" --output "$run/stdcell" > "$run/$stage.log" 2>&1
    stdcell_list="$run/stdcell/standardcell.f"
    mkdir -p "$run/clockgate_check"
    cd "$run/clockgate_check"
    stage=clockgate_compile
    stage_log="$run/$stage.log"
    "$vcs_bin" -full64 -sverilog -timescale=1ns/1ps +define+functional \
        -top tb_clockgate_lib -f "$stdcell_list" "$run/stdcell/patched_clockgate.v" \
        "$root/tb/tb_clockgate_lib.sv" -o "$run/clockgate_check/simv" > "$run/$stage.log" 2>&1
    stage=clockgate_simulation
    stage_log="$run/$stage.log"
    ./simv > "$run/$stage.log" 2>&1
    require_pass_marker clockgate_status.txt
fi
stage=sram_prepare
stage_log="$run/$stage.log"
sram_args=(--library "$library" --output "$run/sram")
if [[ -n "$sram_filelist" ]]; then
    sram_args+=(--filelist "$sram_filelist")
fi
"$python_bin" "$root/tools/prepare_sram_models.py" "${sram_args[@]}" > "$run/$stage.log" 2>&1
stage=firmware_build
stage_log="$run/$stage.log"
bash "$root/build_firmware.sh" "$run/build" > "$run/$stage.log" 2>&1
options=(-full64 -sverilog -timescale=1ns/1ps +define+ARM_UD_MODEL -top tb_tcm_chain12)
if [[ -n "$stdcell_list" ]]; then options+=(+define+functional -f "$stdcell_list"); fi
options+=(-f "$run/sram/sram.f")
while IFS= read -r inc || [[ -n "$inc" ]]; do
    [[ -z "$inc" ]] || options+=("+incdir+$run/platform/e203/$inc")
done < "$run/platform/include_dirs.txt"
options+=("+incdir+$root/accel_rtl" "+incdir+$root/rtl")
while IFS= read -r file || [[ -n "$file" ]]; do
    [[ -z "$file" ]] || options+=("$run/platform/e203/$file")
done < "$run/platform/e203_sources.f"
while IFS= read -r file || [[ -n "$file" ]]; do
    [[ -z "$file" ]] || options+=("$root/$file")
done < "$root/accel_sources.f"
options+=("$root/rtl/kwt_icb_arb2.v" "$root/rtl/kwt_icb_window.v"
    "$root/rtl/kwt_platform_soc.v" "$root/rtl/kwt_tcm_4096x16.v"
    "$root/tb/icb_boot_ram.sv" "$root/tb/tb_tcm_chain12.sv"
    -o "$run/build/simv" -l "$run/compile.log")
cd "$run/build"
"$python_bin" -c 'import json,sys; print(json.dumps(sys.argv[1:],indent=2))' \
    "$vcs_bin" "${options[@]}" > "$run/compile_command.json"
stage=compile_console
stage_log="$run/$stage.log"
printf 'Compiling the 12-layer CPU-chain simulator once for ten cases...\n'
"$vcs_bin" "${options[@]}" > "$run/$stage.log" 2>&1
[[ -x "$run/build/simv" && -f "$run/build/firmware_itcm.hex" ]]
mkdir "$run/cases"
cases=(01_yes 02_no 03_up 04_down 05_left 06_right 07_on 08_off 09_stop 10_go)
for current_case in "${cases[@]}"; do
    case_dir="$run/cases/$current_case"
    stage=case_payload
    stage_log="$run/${current_case}_payload.log"
    mkdir "$case_dir"
    printf '[%02d/10] %s: preparing a fresh case directory\n' "$((completed+1))" "$current_case"
    # case_payload owns input/parameter provenance and requires an empty result
    # directory. Keep its log outside that directory until preparation succeeds.
    "$python_bin" "$root/tools/case_payload.py" --case "$current_case" --result "$case_dir" \
        > "$stage_log" 2>&1
    cp -- "$run/build/firmware_itcm.hex" "$case_dir/firmware_itcm.hex"
    # Preserve the original executable and its generated runtime directory.
    # The local alias also supports VCS versions that open simv.daidir by cwd.
    if [[ -d "$run/build/simv.daidir" ]]; then
        ln -s "$run/build/simv.daidir" "$case_dir/simv.daidir"
    fi
    cd "$case_dir"
    sha256sum firmware_itcm.hex > firmware_sha256.txt
    "$python_bin" -c 'import json,sys; print(json.dumps(sys.argv[1:],indent=2))' \
        "$run/build/simv" +CHAIN_LAYERS=12 -l "$case_dir/simulation.log" \
        > simulation_command.json
    stage=simulation_console
    stage_log="$case_dir/$stage.log"
    printf '[%02d/10] %s: running the CPU-scheduled 12-layer chain\n' "$((completed+1))" "$current_case"
    LD_LIBRARY_PATH="$run/build:$run/build/simv.daidir${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}" \
        "$run/build/simv" +CHAIN_LAYERS=12 -l "$case_dir/simulation.log" > "$stage_log" 2>&1
    stage=simulation_status
    stage_log="$case_dir/simulation.log"
    require_pass_marker status.txt
    require_pass_marker export_status.txt
    grep -q 'PASS CPU_CHAIN_EXECUTION layers=12 ' "$stage_log"
    grep -E 'TCM_INTERFACE|TCM_EFFECTIVE|PASS CPU_CHAIN_EXECUTION|PASS END_TO_END_FUNCTIONAL|PASS BATCH_ACTUAL_OUTPUT_EXPORT' \
        "$stage_log" | sed "s/^/[$current_case] /"
    stage=numerical_comparison
    stage_log="$case_dir/$stage.log"
    "$python_bin" "$root/tools/compare_chain.py" --case "$current_case" --result "$case_dir" --layers 12 \
        > "$stage_log" 2>&1
    cat "$stage_log"
    require_pass_marker numerical_status.txt
    completed=$((completed+1))
    printf '[%02d/10] %s: PASS execution and numerical comparison\n' "$completed" "$current_case"
done
[[ "$completed" -eq 10 ]]
current_case=
stage=batch_aggregation
stage_log="$run/$stage.log"
"$python_bin" "$root/tools/aggregate_batch.py" --run "$run" > "$stage_log" 2>&1
cat "$stage_log"
require_pass_marker "$run/batch_status.txt"
printf 'PASS\n' > "$run/runner_status.txt"
trap - ERR
printf 'PASS: ten fresh cases, each CPU-scheduled through 12 layers, compiled once.\nLogs: %s\n' "$run"
