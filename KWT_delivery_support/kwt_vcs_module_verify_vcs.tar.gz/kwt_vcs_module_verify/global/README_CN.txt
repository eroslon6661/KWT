KWT Stage 5：E203 + 工艺模型TCM + 加速器，十样本十二层回归

编译修复版：移除额外的-Mdir及分离路径参数，恢复Stage4已通过的默认生成目录。
主仿真器仍在每次新建的build目录编译。修复后完整十样本待服务器确认。

本包承接服务器已通过的01_yes十二层验证。复用同一RTL、TB和CPU固件，
一次编译，依次启动十个独立仿真进程；每个样本独立复位，完整执行十二层。
样本固定为yes/no/up/down/left/right/on/off/stop/go各一条语音。
它是十样本回归子集，不能代表完整测试集准确率。

运行（先在独立目录解压）
  source "$HOME/Desktop/kwt_e203_offline/env.sh"
  bash run_vcs.sh

固定CHAIN_LAYERS=12；其他值会被拒绝，避免把不完整层数当作批量通过。
每次新建runs/batch10_*，保留所有旧工程和证据。失败时打印阶段与日志位置。
十个完整仿真比单样本耗时更长；屏幕会显示当前样本及每例完成结果。

执行路径
ITCM与DTCM各256KiB，分别使用32个RAMSP4096X16工艺库模型。
加速器内部SRAM也使用服务器工艺库模型；22个冻结加速器文件不变。
512KiB共享RAM继续使用带确定性等待/背压的行为模型。
每层由CPU单独启动、经PLIC IRQ17完成；每个样本12次START、12次IRQ。
参数逐层经ICB写入同一个0xD000字节槽，输入只装载一次。
层间由硬件实际输出ping-pong传递；FP32参考值仅在仿真结束后比较。
这不是LAYER_COUNT=12的一次硬件START模式；二者性能数字不可混用。

存储与检查
共享RAM范围：A0000000..A007FFFF，共512KiB。
输入/输出Ping：A0000000；Pong：A0004000；参数槽：A0010000。
READY_SEQ：A007D000；REQUEST_SEQ：A007D004；CPU竞争访存：A007E000。
每例从空目录准备输入和12层参数，记录case_receipt.json。
比较器核验case ID、样本、输入、参数、参考文件和运行目录实际刺激的哈希。
汇总器重新核验全部原始输出和执行计数；缺样本、旧报告、混用输入均不通过。

每例预期
START/IRQ/PLIC claim/complete：各12；计算stage：204。
DMA读196344次、写38016次；逐层LN2/FFN2元素各76032。
每层6336个实际FP16值与同一样本原checkpoint的原生FP32输出比较。
NRMSE = sqrt(mean((HW-reference)^2)) / max(sqrt(mean(reference^2)),1e-8)。
所有10×12=120层均须NRMSE<=0.03；整体平均不能掩盖某层超限。
NRMSE显示为比例，例如0.01833约为1.833%。

最终屏幕输出
  PASS CASE 01_yes ... HW=... FP32=... truth=yes
  ...其余9个样本...
  PASS BATCH10 samples=10/10 evaluated_layers=120/120 threshold=0.03
  BATCH10_WORST case=... layer=... NRMSE=... pooled_NRMSE=...
  BATCH10_SOFTWARE_TOP1 HW=.../10 FP32=.../10 agreement=.../10

HW与FP32的Top-1均是原checkpoint分类头在服务器Python中后处理的结果，
不是硬件分类头。分类正确数单列报告；BATCH10 PASS以执行及逐层NRMSE为准，
不会隐含“分类10/10”。不提前假设尚未运行的九个样本会通过。
服务器仅需Python2.7/3标准库，无需NumPy、TensorFlow或下载输出。

结果文件
runs/batch10_*/batch_summary.json 与 batch_status.txt：整批结果。
cases/<case>/simulation.log：VCS日志；execution.json：实际计数。
cases/<case>/numerical.json：逐层误差与软件分类；layer_*：实际输出。
case_receipt.json及复制的input/params：本次输入身份。

验证边界
Stage4服务器截图已证明01_yes完整十二层通过，最差层NRMSE=0.0183309885，
HW/FP32软件分类均为yes。该截图记录在validation/chain12_server_baseline.json。
新包的本地测试记录在validation/batch_validation.json、comparator_validation.json。
本地脚本或比较器fixture测试不属于服务器VCS结果；完整十样本待服务器执行。
功能时钟为100ns；周期计数不能作为150MHz物理时序签核。
本阶段不改变DC综合面积结果，也不执行布局布线。
