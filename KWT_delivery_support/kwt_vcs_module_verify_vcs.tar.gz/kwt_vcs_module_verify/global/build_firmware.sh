#!/usr/bin/env bash
set -euo pipefail
export LC_ALL=C
root=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
out=${1:?Usage: bash build_firmware.sh OUTPUT_DIRECTORY}
[[ $# -eq 1 ]] || exit 2
python_bin=${PYTHON_BIN:-python}
chain_layers=${CHAIN_LAYERS:-12}
[[ "$chain_layers" =~ ^([1-9]|1[0-2])$ ]] || { printf 'Invalid CHAIN_LAYERS\n' >&2; exit 2; }
prefix="${RISCV_TOOLCHAIN:?Source the verified RISC-V toolchain env.sh first}/bin/riscv-nuclei-elf"
command -v "$python_bin" >/dev/null
"$python_bin" -c 'import sys; assert sys.version_info >= (2,7), sys.version'
mkdir -p "$out"
out=$(cd -- "$out" && pwd)
"$prefix-gcc" --version > "$out/compiler_version.txt"
"$prefix-gcc" -DCHAIN_LAYERS="$chain_layers" -march=rv32imac -mabi=ilp32 -mcmodel=medany \
    -Os -Wall -Wextra -Werror -ffreestanding -fno-builtin -fno-pic \
    -fno-asynchronous-unwind-tables -fno-unwind-tables -msmall-data-limit=0 \
    -nostdlib -nostartfiles -Wl,--no-relax \
    -T "$root/firmware/link.ld" -Wl,-Map,"$out/firmware.map" \
    "$root/firmware/start.S" "$root/firmware/main.c" -o "$out/firmware.elf"
"$prefix-readelf" -h -A "$out/firmware.elf" > "$out/firmware_info.txt"
"$prefix-objdump" -d "$out/firmware.elf" > "$out/firmware.dis"
"$prefix-nm" -n "$out/firmware.elf" > "$out/firmware_symbols.txt"
"$prefix-objcopy" -O binary "$out/firmware.elf" "$out/firmware.bin"
grep -q 'Class:.*ELF32' "$out/firmware_info.txt"
grep -q 'Machine:.*RISC-V' "$out/firmware_info.txt"
grep -q 'Entry point address:.*0x80000000' "$out/firmware_info.txt"
grep -Eq '^80020000 [tT] itcm_high_probe$' "$out/firmware_symbols.txt"

# Explicit little-endian packing, independent of host byte order; Python 2.7/3.
"$python_bin" - "$out" <<'PY'
from __future__ import print_function
import os
import struct
import sys
out = sys.argv[1]
with open(os.path.join(out, 'firmware.bin'), 'rb') as stream:
    image = stream.read()
size = len(image)
if not 0x20000 < size <= 262144:
    raise SystemExit('Invalid ITCM image size/high-address function: %d' % size)
image += b'\x00' * (262144 - size)
with open(os.path.join(out, 'firmware_itcm.hex'), 'wb') as stream:
    for offset in range(0, len(image), 8):
        value = struct.unpack('<Q', image[offset:offset + 8])[0]
        stream.write(('%016x\n' % value).encode('ascii'))
print('Firmware: %d binary bytes; 32768 x 64-bit ITCM words' % size)
PY
cd "$out"
sha256sum firmware.bin firmware_itcm.hex > firmware_sha256.txt
printf 'Firmware built: entry=80000000 high_probe=80020000 mailbox=A007F000\n'
