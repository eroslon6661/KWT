#!/usr/bin/env python
"""Generate a separate, bounded VCD monitor. Python 2.7/3; never edits DUT."""
from __future__ import print_function
import argparse
import io
import re

p = argparse.ArgumentParser()
p.add_argument('--output', required=True)
p.add_argument('--scope', required=True)
p.add_argument('--trigger', default='time')
p.add_argument('--start', type=int, default=0)
p.add_argument('--duration', type=int, default=200000)
p.add_argument('--depth', type=int, default=2)
a = p.parse_args()
segment = r'[A-Za-z_][A-Za-z0-9_$]*(?:\[[0-9]+\])*'
name = r'^' + segment + r'(?:\.' + segment + r')*$'
if not re.match(name, a.scope) or (a.trigger != 'time' and not re.match(name, a.trigger)):
    p.error('scope/trigger must be a plain hierarchical signal name (or trigger=time)')
if a.start < 0 or a.duration <= 0 or a.depth < 0:
    p.error('start>=0, duration>0, depth>=0 required; depth=0 means all levels')
trigger = '' if a.trigger == 'time' else 'wait (%s === 1\'b1);' % a.trigger
text = '''`timescale 1ns/1ps
module kwt_wave_dump;
  initial begin
    if (!$test$plusargs("NO_WAVE")) begin
      %s
      #(%d);
      $dumpfile("wave.vcd");
      $dumpvars(%d, %s);
      $display("WAVE_BEGIN time_ns=%%0d scope=%s", $time);
      #(%d);
      $dumpoff;
      $dumpflush;
      $display("WAVE_END time_ns=%%0d", $time);
    end
  end
endmodule
''' % (trigger, a.start, a.depth, a.scope, a.scope, a.duration)
with io.open(a.output, 'w', encoding='ascii', newline='\n') as f:
    f.write(text.decode('ascii') if isinstance(text, bytes) else text)
