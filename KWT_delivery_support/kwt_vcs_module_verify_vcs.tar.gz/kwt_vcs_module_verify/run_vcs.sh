#!/usr/bin/env bash
# Unit/block verification. No files are written to the baseline project.
set -eo pipefail
export LC_ALL=C
root=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
test_name=${1:-operators}
if [[ $# -gt 1 ]]; then echo 'Usage: bash run_vcs.sh TEST' >&2; exit 2; fi
case "$test_name" in
  --list) printf '%s\n' operators pe matrix vector dequant icb_cfg icb_master dma arbiter sram controller accel accel_fault tcm global_layer1 global_chain12 global_batch10; exit 0 ;;
  global_*) exec bash "$root/run_global.sh" "$test_name" ;;
esac
case "$test_name" in
  operators|pe|matrix|vector|dequant|icb_cfg|icb_master|dma|arbiter|sram|controller|accel|accel_fault) top="tb_$test_name" ;;
  tcm) top=tb_tcm_256k ;;
  *) echo "Unknown test: $test_name (use --list)" >&2; exit 2 ;;
esac
if [[ "${SRAM_MODE:-behavioral}" == vendor && "$test_name" != sram && "$test_name" != tcm ]]; then
  echo 'SRAM_MODE=vendor is supported for sram/tcm only; use global_* for vendor CPU/accelerator integration.' >&2
  exit 2
fi
python_bin=${PYTHON_BIN:-python}
vcs_bin=${VCS_BIN:-vcs}
command -v "$python_bin" >/dev/null
command -v "$vcs_bin" >/dev/null
mkdir -p "$root/runs"
run=$(mktemp -d "$root/runs/${test_name}_XXXXXXXX")
printf 'Run directory: %s\n' "$run"
printf 'INCOMPLETE\n' > "$run/status.txt"
failure() { local code=$?; trap - ERR; printf 'FAIL: logs retained in %s\n' "$run" >&2; tail -n 35 "$run/compile_console.log" "$run/simulation.log" 2>/dev/null || true; exit "$code"; }
trap failure ERR
(cd "$root" && sha256sum -c SHA256SUMS) > "$run/package_check.log"
opts=(-full64 -sverilog -timescale=1ns/1ps -debug_access+all -top "$top" -top kwt_wave_dump
  "+incdir+$root/accel_rtl" "+incdir+$root/rtl")
if [[ "$test_name" == tcm || "${SRAM_MODE:-behavioral}" == vendor ]]; then
  args=(--library "${SRAM_LIBRARY:-/storage1/admin_public_dir/SRAM_Lib_2025}" --output "$run/sram")
  [[ -z "${SRAM_FILELIST:-}" ]] || args+=(--filelist "$(readlink -f -- "$SRAM_FILELIST")")
  "$python_bin" "$root/global/tools/prepare_sram_models.py" "${args[@]}" > "$run/sram_prepare.log" 2>&1
  opts+=(+define+ARM_UD_MODEL -f "$run/sram/sram.f")
else
  [[ "${SRAM_MODE:-behavioral}" == behavioral ]]
  opts+=(+define+KWT_SRAM_BEHAV)
fi
while IFS= read -r f || [[ -n "$f" ]]; do
  f=${f%$'\r'}
  [[ -z "$f" ]] || opts+=("$root/$f")
done < "$root/accel_sources.f"
opts+=("$root/rtl/kwt_icb_arb2.v" "$root/rtl/kwt_icb_window.v" "$root/rtl/kwt_tcm_4096x16.v")
"$python_bin" "$root/tools/make_wave.py" --output "$run/wave_dump.sv" --scope "${WAVE_SCOPE:-$top}" \
  --trigger "${WAVE_TRIGGER:-time}" --start "${WAVE_START_NS:-0}" --duration "${WAVE_DURATION_NS:-200000}" --depth "${WAVE_DEPTH:-2}"
opts+=("$root/tb/$top.sv" "$run/wave_dump.sv" -o "$run/simv" -l "$run/compile.log")
mkdir -p "$run/results"
if [[ -d "$root/vectors/integration" ]]; then
  mkdir -p "$run/vectors"
  cp -R -- "$root/vectors/integration" "$run/vectors/"
fi
cd "$run"
"$python_bin" -c 'import json,sys; print(json.dumps(sys.argv[1:],indent=2))' "$vcs_bin" "${opts[@]}" > compile_command.json
"$vcs_bin" "${opts[@]}" > compile_console.log 2>&1
sim_opts=(-l simulation.log)
[[ "${DUMP:-1}" != 0 ]] || sim_opts+=(+NO_WAVE)
./simv "${sim_opts[@]}" > simulation_console.log 2>&1
if [[ "$test_name" == tcm ]]; then
  [[ -f tcm_status.txt && "$(tr -d '\r\n' < tcm_status.txt)" == PASS ]]
else
  grep -Eq "^PASS ${top}([[:space:]]|$)" simulation.log
fi
if [[ "${DUMP:-1}" != 0 ]]; then
  [[ -s wave.vcd ]] || { echo 'Wave trigger/window was not reached; adjust WAVE_* settings.' >&2; exit 1; }
fi
printf 'PASS\n' > status.txt
grep 'PASS' simulation.log
printf 'PASS %s\nResults: %s\n' "$test_name" "$run"
