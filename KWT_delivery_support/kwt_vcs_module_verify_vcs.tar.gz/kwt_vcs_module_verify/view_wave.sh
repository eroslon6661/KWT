#!/usr/bin/env bash
set -eo pipefail
[[ $# -ge 1 && $# -le 2 ]] || { echo 'Usage: bash view_wave.sh RUN_DIRECTORY [dve|gtkwave|verdi]' >&2; exit 2; }
run=$(cd -- "$1" && pwd)
[[ -s "$run/wave.vcd" ]] || { echo "Missing waveform: $run/wave.vcd" >&2; exit 1; }
case "${2:-dve}" in
  dve)
    command -v vcd2vpd >/dev/null
    command -v dve >/dev/null
    vcd2vpd "$run/wave.vcd" "$run/wave.vpd"
    exec dve -vpd "$run/wave.vpd" ;;
  gtkwave) exec gtkwave "$run/wave.vcd" ;;
  verdi) exec verdi -ssf "$run/wave.vcd" ;;
  *) echo 'Viewer must be dve, gtkwave, or verdi' >&2; exit 2 ;;
esac
