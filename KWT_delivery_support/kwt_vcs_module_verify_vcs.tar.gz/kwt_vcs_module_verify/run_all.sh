#!/usr/bin/env bash
# Quick unit/block suite. Longer inference and vendor/CPU tests are explicit.
set -eo pipefail
root=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
for test_name in operators pe matrix vector dequant icb_cfg icb_master dma arbiter sram controller; do
  bash "$root/run_vcs.sh" "$test_name"
done
printf 'PASS all quick module tests\n'
