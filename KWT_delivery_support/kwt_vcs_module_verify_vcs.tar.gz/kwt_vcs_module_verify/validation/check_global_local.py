"""One-layer CPU preflight using PUBLIC E203 and SYNTHETIC macros, not VCS."""
from pathlib import Path
import hashlib,json,shutil,subprocess,sys,tempfile
ROOT=Path(__file__).resolve().parents[1]
WS=ROOT.parents[1]
BASE=ROOT/'global'
BIN=Path('E:/modelsim/win64')
CC=WS/'artifacts/kwt_e203_boot_local_tools/gcc/bin/riscv-nuclei-elf-gcc.exe'
RUN=Path(tempfile.mkdtemp(prefix='global_local_',dir=str(ROOT/'validation')))
print('LOCAL_CPU_RUN '+str(RUN),flush=True)
def call(args,log,timeout=180,cwd=RUN):
    with (RUN/log).open('w') as out:
        r=subprocess.run([str(a) for a in args],cwd=cwd,stdout=out,stderr=subprocess.STDOUT,timeout=timeout)
    text=(RUN/log).read_text(errors='replace')
    if r.returncode: raise RuntimeError(text[-6000:])
    return text
call([sys.executable,BASE/'prepare_platform.py','--public-source',WS/'artifacts/kwt_e203_boot/third_party/e203','--output',RUN/'platform'],'prepare.log')
call([sys.executable,BASE/'tools/prepare_tcm.py','--platform',RUN/'platform'],'tcm.log')
call([CC,'-DCHAIN_LAYERS=1','-march=rv32imac','-mabi=ilp32','-mcmodel=medany','-Os','-Wall','-Wextra','-Werror',
      '-ffreestanding','-fno-builtin','-fno-pic','-fno-asynchronous-unwind-tables','-fno-unwind-tables','-msmall-data-limit=0',
      '-nostdlib','-nostartfiles','-Wl,--no-relax','-T',BASE/'firmware/link.ld',BASE/'firmware/start.S',BASE/'firmware/main.c',
      '-o',RUN/'firmware.elf'],'firmware.log')
call([CC.with_name('riscv-nuclei-elf-objcopy.exe'),'-O','binary',RUN/'firmware.elf',RUN/'firmware.bin'],'objcopy.log')
result=RUN/'case'
call([sys.executable,BASE/'tools/case_payload.py','--case','01_yes','--result',result],'payload.log')
raw=(RUN/'firmware.bin').read_bytes(); assert 0x20000<len(raw)<=262144
raw=raw.ljust(262144,b'\0')
(result/'firmware_itcm.hex').write_bytes(''.join('%016x\n'%int.from_bytes(raw[i:i+8],'little') for i in range(0,len(raw),8)).encode())
fixture=(WS/'artifacts/kwt_tcm_layer1/validation/ramsp4096x16_fixture.v').read_text()
fixtures=fixture+fixture.replace('RAMSP4096X16','RAMSP2048X16').replace('[11:0] A','[10:0] A').replace('[0:4095]','[0:2047]')
fixtures+=fixture.replace('RAMSP4096X16','RAMSP1024X16').replace('[11:0] A','[9:0] A').replace('[0:4095]','[0:1023]')
(RUN/'fixtures.v').write_text(fixtures)
call([sys.executable,ROOT/'tools/make_wave.py','--output',RUN/'wave_dump.sv','--scope','tb_tcm_chain12.soc.u_accel',
      '--trigger','tb_tcm_chain12.soc.u_accel.u_core.start_valid','--duration','100000','--depth','2'],'wave.log')
sources=[RUN/'platform/e203'/p for p in (RUN/'platform/e203_sources.f').read_text().splitlines() if p]
sources += [ROOT/p for p in (ROOT/'accel_sources.f').read_text().splitlines() if p]
sources += [ROOT/'rtl'/n for n in ['kwt_icb_arb2.v','kwt_icb_window.v','kwt_platform_soc.v','kwt_tcm_4096x16.v']]
sources += [RUN/'fixtures.v',BASE/'tb/icb_boot_ram.sv',BASE/'tb/tb_tcm_chain12.sv',RUN/'wave_dump.sv']
includes=[RUN/'platform/e203'/p for p in (RUN/'platform/include_dirs.txt').read_text().splitlines() if p]+[ROOT/'accel_rtl',ROOT/'rtl']
call([BIN/'vlib.exe',result/'work'],'vlib.log')
call([BIN/'vlog.exe','-work',result/'work','-sv','-timescale','1ns/1ps','+define+ARM_UD_MODEL']+['+incdir+'+p.as_posix() for p in includes]+sources,'compile.log')
print('LOCAL_CPU_COMPILED',flush=True)
text=call([BIN/'vsim.exe','-c','-onfinish','exit','-voptargs=+acc','work.tb_tcm_chain12','work.kwt_wave_dump','+CHAIN_LAYERS=1',
           '-do','onbreak {quit -code 3}; onerror {quit -code 2}; run -all; quit -code 0'],'simulation.log',1200,result)
assert (result/'status.txt').read_text().strip()=='PASS'
assert (result/'export_status.txt').read_text().strip()=='PASS'
assert (result/'wave.vcd').stat().st_size>100
compare=call([sys.executable,BASE/'tools/compare_chain.py','--result',result,'--case','01_yes','--layers','1'],'numerical.log')
assert (result/'numerical_status.txt').read_text().strip()=='PASS'
report={'status':'PASS','case':'01_yes','layers':1,'simulator':'ModelSim','vcs_tested':False,'vendor_models_tested':False,
        'public_e203':True,'synthetic_sram_fixture':True,'new_wave_monitor_tested':True,'run':str(RUN),
        'wave_bytes':(result/'wave.vcd').stat().st_size,'pass_lines':[l for l in text.splitlines() if 'PASS ' in l],
        'numerical':json.loads((result/'numerical.json').read_text())}
(ROOT/'validation/global_local_summary.json').write_text(json.dumps(report,indent=2)+'\n')
print(compare,flush=True)
print('LOCAL_CPU_WAVE_PASS',flush=True)
