"""Hermetic runner orchestration checks with labelled stubs, NOT RTL simulation."""
from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[1]
BASH = Path('C:/Users/24750/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/git/usr/bin/sh.exe')


def posix(p):
    s = str(Path(p).resolve()).replace('\\', '/')
    return '/' + s[0].lower() + s[2:] if len(s) > 2 and s[1] == ':' else s


def write(path, text):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(text.encode())


def manifest(folder):
    rows = []
    for p in sorted(folder.rglob('*')):
        if p.is_file() and p.name != 'SHA256SUMS' and 'runs' not in p.relative_to(folder).parts:
            rows.append(hashlib.sha256(p.read_bytes()).hexdigest() + '  ' + p.relative_to(folder).as_posix())
    write(folder / 'SHA256SUMS', '\n'.join(rows) + '\n')


def main():
    work = Path(tempfile.mkdtemp(prefix='shell_stub_', dir=ROOT / 'validation'))
    package = work / 'package'
    for name in ['run_vcs.sh', 'run_global.sh', 'run_all.sh', 'view_wave.sh', 'tools/make_wave.py']:
        target = package / name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(ROOT / name, target)
    # Placeholders only allow the fake compiler to inspect assembled arguments.
    write(package / 'accel_sources.f', 'accel_rtl/stub.v\n')
    write(package / 'accel_rtl/stub.v', '// STUB: not real RTL\n')
    for name in ['kwt_icb_arb2', 'kwt_icb_window', 'kwt_platform_soc', 'kwt_tcm_4096x16']:
        write(package / ('rtl/' + name + '.v'), '// STUB: not real RTL\n')
    for name in ['tb_operators', 'tb_tcm_256k']:
        write(package / ('tb/' + name + '.sv'), '// STUB testbench\n')
    base = package / 'global'
    write(base / 'build_firmware.sh', '''#!/usr/bin/env bash
set -e
mkdir -p "$1"
printf '%s\\n' "$CHAIN_LAYERS" > "$1/stub_firmware_layers.txt"
printf '0000000000000000\\n' > "$1/firmware_itcm.hex"
''')
    write(base / 'prepare_platform.py', '''import argparse,os
p=argparse.ArgumentParser();p.add_argument('--platform-zip');p.add_argument('--output');a=p.parse_args()
os.makedirs(os.path.join(a.output,'e203'))
open(os.path.join(a.output,'e203_sources.f'),'w').close()
open(os.path.join(a.output,'include_dirs.txt'),'w').close()
print('STUB PLATFORM')
''')
    write(base / 'tools/prepare_tcm.py', "print('STUB TCM')\n")
    write(base / 'tools/prepare_sram_models.py', '''import argparse,os
p=argparse.ArgumentParser();p.add_argument('--library');p.add_argument('--filelist');p.add_argument('--output');a=p.parse_args()
os.makedirs(a.output);open(os.path.join(a.output,'sram.f'),'w').close()
print('STUB SRAM')
''')
    write(base / 'tools/case_payload.py', '''import argparse,os
p=argparse.ArgumentParser();p.add_argument('--case');p.add_argument('--result');a=p.parse_args();os.makedirs(a.result)
print('STUB PAYLOAD')
''')
    write(base / 'tools/compare_chain.py', '''import argparse,os,sys
p=argparse.ArgumentParser();p.add_argument('--case');p.add_argument('--result');p.add_argument('--layers');a=p.parse_args()
bad=os.environ.get('STUB_MODE')=='compare_fail'
open(os.path.join(a.result,'numerical_status.txt'),'w').write('FAIL\\n' if bad else 'PASS\\n')
open(os.path.join(a.result,'stub_comparison_layers.txt'),'w').write(a.layers)
print('STUB COMPARISON');sys.exit(31 if bad else 0)
''')
    write(base / 'tools/aggregate_batch.py', '''import argparse,os
p=argparse.ArgumentParser();p.add_argument('--run');a=p.parse_args()
open(os.path.join(a.run,'batch_status.txt'),'w').write('PASS\\n');print('STUB AGGREGATION')
''')
    write(base / 'tb/icb_boot_ram.sv', '// STUB\n')
    write(base / 'tb/tb_tcm_chain12.sv', '// STUB\n')
    manifest(base)
    manifest(package)
    compiler = work / 'vcs_stub'
    write(compiler, '''#!/usr/bin/env bash
set -e
top=;out=simv
while [[ $# -gt 0 ]]; do
 case "$1" in
 -top) [[ -n "$top" ]] || top=$2; shift 2 ;;
 -o) out=$2; shift 2 ;;
 *) shift ;;
 esac
done
[[ "$STUB_MODE" != compile_fail ]] || exit 19
mkdir -p "$(dirname "$out")"
printf '#!/usr/bin/env bash\\ntop=%q\\n' "$top" > "$out"
cat >> "$out" <<'SIM'
set -e
wave=1
for arg in "$@"; do [[ "$arg" != +NO_WAVE ]] || wave=0; done
if [[ "$top" == tb_tcm_chain12 ]]; then
 printf 'PASS CPU_CHAIN_EXECUTION\\nPASS END_TO_END_FUNCTIONAL\\n' > simulation.log
 printf 'PASS\\n' > status.txt
 [[ "$STUB_MODE" == missing_export ]] || printf 'PASS\\n' > export_status.txt
else
 if [[ "$STUB_MODE" == missing_marker ]]; then printf 'STUB NO PASS\\n' > simulation.log
 elif [[ "$STUB_MODE" == false_marker ]]; then printf 'FAIL expected PASS %s\\n' "$top" > simulation.log
 else printf 'PASS %s\\n' "$top" > simulation.log; fi
fi
[[ "$STUB_MODE" != simulation_fail ]] || exit 23
if [[ "$wave" == 1 && "$STUB_MODE" != no_wave ]]; then
 printf '$date STUB $end\\n' > wave.vcd
fi
SIM
chmod +x "$out"
''')
    toolbin = work / 'tools'
    write(toolbin / 'bash', '#!/bin/sh\nexec "$KWT_TEST_SH" "$@"\n')
    # The bundled Git runtime lacks sha256sum and chmod. The hash shim performs
    # a real SHA256 manifest check; chmod is irrelevant to Windows ACLs here.
    write(toolbin / 'chmod', '#!/bin/sh\nexit 0\n')
    write(toolbin / 'sha256sum', '#!/bin/sh\nexec "$PYTHON_BIN" "$KWT_TEST_HASH" "$@"\n')
    write(toolbin / 'hash_check.py', '''import hashlib,sys
assert len(sys.argv)==3 and sys.argv[1]=='-c'
for line in open(sys.argv[2]):
 h,p=line.rstrip().split('  ',1)
 assert hashlib.sha256(open(p,'rb').read()).hexdigest()==h,p
 print(p+': OK')
''')
    env = os.environ.copy()
    env.update(PYTHON_BIN=posix(sys.executable), VCS_BIN=posix(compiler), RISCV_TOOLCHAIN='STUB_ONLY',
               PLATFORM_ZIP=posix(work / 'platform.zip'), SRAM_LIBRARY=posix(work),
               KWT_TEST_SH=posix(BASH),KWT_TEST_HASH=posix(toolbin/'hash_check.py'))
    env['PATH'] = str(toolbin) + os.pathsep + str(BASH.parent) + os.pathsep + env.get('PATH', '')
    write(work / 'platform.zip', 'STUB')
    tests = []

    def run_case(name, command, mode='normal', success=True, dump='1', extra=None):
        before = set((package / 'runs').glob('*')) if (package / 'runs').exists() else set()
        settings = env.copy();settings.update(STUB_MODE=mode, DUMP=dump)
        if extra: settings.update(extra)
        result = subprocess.run([str(BASH), *command], cwd=package, env=settings,
                                stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=60)
        output = result.stdout.decode(errors='replace')
        write(work / (name + '.log'), output)
        after = set((package / 'runs').glob('*')) if (package / 'runs').exists() else set()
        created = list(after - before)
        status = None
        if created:
            f = created[0] / ('runner_status.txt' if 'global' in name else 'status.txt')
            if f.exists(): status = f.read_text().strip()
        ok = (result.returncode == 0) == success
        if name not in ('list', 'unknown'): ok = ok and len(created) == 1
        if name == 'compile_failure': ok = ok and result.returncode == 19
        if name == 'simulation_failure_even_with_PASS': ok = ok and result.returncode == 23
        if name == 'global_comparison_failure': ok = ok and result.returncode == 31
        if name == 'unknown': ok = ok and result.returncode == 2
        if created and not success: ok = ok and status != 'PASS'
        tests.append(dict(name=name, expected_success=success, returncode=result.returncode,
                          status=status, passed=ok))
        print(name, 'PASS' if ok else 'FAIL', 'rc='+str(result.returncode), flush=True)
        if not ok: print(output[-2500:], flush=True)
        return created

    run_case('list', ['run_vcs.sh', '--list'])
    run_case('unknown', ['run_vcs.sh', 'bad'], success=False)
    normal = run_case('module_success', ['run_vcs.sh', 'operators'])
    if normal and (normal[0] / 'compile_command.json').exists():
        args=json.loads((normal[0] / 'compile_command.json').read_text())
        assert args.count('-top') == 2 and 'tb_operators' in args and 'kwt_wave_dump' in args
    run_case('compile_failure', ['run_vcs.sh', 'operators'], 'compile_fail', False)
    run_case('simulation_failure_even_with_PASS', ['run_vcs.sh', 'operators'], 'simulation_fail', False)
    run_case('missing_marker', ['run_vcs.sh', 'operators'], 'missing_marker', False)
    run_case('false_marker', ['run_vcs.sh', 'operators'], 'false_marker', False)
    run_case('missing_wave', ['run_vcs.sh', 'operators'], 'no_wave', False)
    run_case('dump_off', ['run_vcs.sh', 'operators'], 'no_wave', True, '0')
    run_case('bad_wave_parameter', ['run_vcs.sh', 'operators'], success=False, extra={'WAVE_DURATION_NS':'0'})
    global_one=run_case('global_layer1_success', ['run_global.sh', 'global_layer1'], dump='0')
    if global_one and (global_one[0] / 'cases/01_yes/stub_comparison_layers.txt').exists():
        assert (global_one[0] / 'build/stub_firmware_layers.txt').read_text().strip() == '1'
        assert (global_one[0] / 'cases/01_yes/stub_comparison_layers.txt').read_text().strip() == '1'
    run_case('global_missing_export', ['run_global.sh', 'global_layer1'], 'missing_export', False, '0')
    run_case('global_comparison_failure', ['run_global.sh', 'global_layer1'], 'compare_fail', False, '0')
    global_ten=run_case('global_batch10_success', ['run_global.sh', 'global_batch10'], dump='0')
    if global_ten:
        assert len(list((global_ten[0]/'cases').iterdir())) == 10
    write(package/'accel_rtl/stub.v','// Changed after manifest creation\n')
    run_case('package_hash_mismatch', ['run_vcs.sh', 'operators'], success=False)
    report={'scope':'Shell orchestration only, mocked compiler/simulator/platform/numerical comparison; NOT RTL/VCS proof',
            'fixture':str(work),'tests':tests,'status':'PASS' if all(x['passed'] for x in tests) else 'FAIL',
            'script_sha256':{n:hashlib.sha256((package/n).read_bytes()).hexdigest() for n in ['run_vcs.sh','run_global.sh','tools/make_wave.py']}}
    write(ROOT/'validation/shell_orchestration.json', json.dumps(report,indent=2)+'\n')
    print('REPORT',report['status'],str(work),flush=True)
    return 0 if report['status']=='PASS' else 1


if __name__ == '__main__':
    sys.exit(main())
