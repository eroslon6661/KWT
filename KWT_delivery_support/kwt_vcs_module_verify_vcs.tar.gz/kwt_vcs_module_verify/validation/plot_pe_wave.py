"""Plot the actual ModelSim VCD from run_local.py pe; not a hand-drawn waveform."""
from pathlib import Path
import json,sys,re,hashlib
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT.parents[1]/'artifacts/real_speech_compare/plot_deps'))
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
report=json.loads((ROOT/'validation/wave_pe_result.json').read_text())
source=Path(report['log_directory'])/'wave.vcd'
lines=source.read_text().splitlines()
names=['clk','rst','step','w_load','w_data','data_in','psum_in','psum_out','want']
widths={n:(1 if n in names[:4] else 16 if n in names[4:6] else 32) for n in names}
codes={};stack=[];start=0
for i,l in enumerate(lines):
    tok=l.split()
    if l.startswith('$scope'):stack.append(tok[2])
    elif l.startswith('$upscope'):stack.pop()
    elif l.startswith('$var') and stack==['tb_pe'] and tok[4] in names:
        idx=None
        if len(tok)>6 and re.fullmatch(r'\[\d+\]',tok[5]):idx=int(tok[5][1:-1])
        codes[tok[3]]=(tok[4],idx)
    elif l.startswith('$enddefinitions'):start=i+1;break
assert '1ps' in '\n'.join(lines[:15])
state={n:['x']*widths[n] for n in names};history={n:[] for n in names};now=0
def flush():
    for n in names:
        value=''.join(state[n][::-1])
        if not history[n] or history[n][-1][1]!=value:history[n].append((now/1000.0,value))
for l in lines[start:]:
    if l.startswith('#'):flush();now=int(l[1:]);continue
    if not l or l.startswith('$'):continue
    if l[0]=='b':
        value,code=l[1:].split()
    elif l[0] in '01xzXZ':value,code=l[0].lower(),l[1:]
    else:continue
    if code not in codes:continue
    n,idx=codes[code]
    if idx is None:
        pad='x' if 'x' in value else 'z' if 'z' in value else '0'
        state[n]=list(value.rjust(widths[n],pad)[::-1])
    else:state[n][idx]=value
flush()
fig,axes=plt.subplots(len(names),1,figsize=(15,7.2),sharex=True)
end=180
for ax,n in zip(axes,names):
    events=[(t,v) for t,v in history[n] if t<=end]
    events.append((end,events[-1][1]))
    ax.set_ylim(-.25,1.25);ax.set_yticks([]);ax.set_ylabel(n,rotation=0,ha='right',va='center',family='monospace')
    ax.grid(axis='x',alpha=.2)
    for s in ['top','left','right']:ax.spines[s].set_visible(False)
    if widths[n]==1:
        ax.step([t for t,v in events],[int(v) if v in ['0','1'] else .5 for t,v in events],where='post',color='#126a92',lw=1.4)
    else:
        for (t,v),(t2,_) in zip(events,events[1:]):
            color='#13835e' if n=='psum_out' else '#636a77'
            ax.plot([t,t,t2,t2],[.2,.85,.85,.2],color=color,lw=1)
            ax.plot([t,t2],[.2,.2],color=color,lw=1)
            if t2-t>=9:
                label='X' if any(x in v for x in 'xz') else ('%0*x'%((widths[n]+3)//4,int(v,2)))
                ax.text((t+t2)/2,.48,label,ha='center',va='center',fontsize=8,family='monospace',clip_on=True)
axes[-1].set_xlabel('Simulation time (ns)');axes[-1].set_xlim(0,end)
axes[-1].set_xticks(list(range(0,end+1,10)))
fig.suptitle('PE multiply-accumulate: real ModelSim VCD | 3 enabled-step pipeline | local preflight, not VCS',fontsize=12)
fig.tight_layout(rect=[0,0,1,.96])
for ext in ['png','svg']:fig.savefig(ROOT/'docs'/('pe_wave_example.'+ext),dpi=160)
(ROOT/'docs/pe_wave_example.vcd').write_bytes(source.read_bytes())
(ROOT/'docs/pe_wave_provenance.json').write_text(json.dumps({'source':'validation/wave_pe_result.json','simulator':'ModelSim','vcs':False,
    'vcd_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'plot_window_ns':[0,end]},indent=2)+'\n')
print('PE waveform plot generated from actual VCD')
