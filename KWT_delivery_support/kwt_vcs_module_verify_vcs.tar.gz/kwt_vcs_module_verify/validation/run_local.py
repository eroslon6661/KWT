"""Windows ModelSim preflight; NOT a VCS or vendor-library verification claim."""
from pathlib import Path
import json, os, shutil, subprocess, sys, tempfile

ROOT = Path(__file__).resolve().parents[1]
BIN = Path('E:/modelsim/win64')
name = sys.argv[1] if len(sys.argv) > 1 else 'pe'
top = 'tb_' + name
run = Path(tempfile.mkdtemp(prefix='wave_' + name + '_', dir=str(ROOT/'validation')))
print('RUN '+str(run), flush=True)
def call(cmd, logfile, timeout=300):
    with (run/logfile).open('w') as out:
        result = subprocess.run([str(c) for c in cmd], cwd=run, stdout=out, stderr=subprocess.STDOUT, timeout=timeout)
    text = (run/logfile).read_text(errors='replace')
    if result.returncode: raise RuntimeError(text[-6000:])
    return text
call([sys.executable,ROOT/'tools/make_wave.py','--output',run/'wave_dump.sv','--scope',top,
      '--duration','200000','--depth','2'], 'wave_generate.log')
sources = [ROOT/p for p in (ROOT/'accel_sources.f').read_text().splitlines() if p]
sources += [ROOT/'rtl'/p for p in ['kwt_icb_arb2.v','kwt_icb_window.v','kwt_tcm_4096x16.v']]
sources += [ROOT/'tb'/(top+'.sv'),run/'wave_dump.sv']
(run/'results').mkdir()
if (ROOT/'vectors/integration').is_dir():
    shutil.copytree(ROOT/'vectors/integration',run/'vectors/integration')
call([BIN/'vlib.exe','work'],'vlib.log')
call([BIN/'vlog.exe','-sv','+define+KWT_SRAM_BEHAV','+incdir+'+(ROOT/'accel_rtl').as_posix()]+sources,'compile.log')
text=call([BIN/'vsim.exe','-c','-onfinish','exit','-voptargs=+acc','work.'+top,'work.kwt_wave_dump',
           '-do','onbreak {quit -code 3}; onerror {quit -code 2}; run -all; quit -code 0'], 'simulation.log', 1200)
assert 'PASS '+top in text, text[-6000:]
assert (run/'wave.vcd').stat().st_size>100
report={'test':name,'status':'PASS','simulator':'ModelSim','vcs_tested':False,
        'vendor_models_tested':False,'wave_vcd_bytes':(run/'wave.vcd').stat().st_size,
        'log_directory':str(run),'pass_lines':[line for line in text.splitlines() if 'PASS ' in line]}
(ROOT/'validation'/('wave_'+name+'_result.json')).write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
