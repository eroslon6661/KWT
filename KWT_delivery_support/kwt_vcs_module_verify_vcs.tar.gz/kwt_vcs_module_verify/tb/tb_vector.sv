`timescale 1ns/1ps
// Independent real-valued softmax/LN/GELU references with explicit tolerances.
module tb_vector;
  reg clk=0,rst_n=0,job_valid=0,v_wr_ready=0,m_logits_tready=0;
  always #5 clk=~clk;
  reg [195:0] job=0;
  wire job_ready,job_done,job_error,v_rd_en,v_wr_en,param_rd_en;
  wire [17:0] v_rd_addr,v_wr_addr;
  wire [19:0] param_rd_addr;
  reg [511:0] v_rd_data=0;
  reg [63:0] param_rd_data=0;
  wire [511:0] v_wr_data;
  wire [63:0] v_wr_strb;
  wire [191:0] m_logits_tdata;
  wire m_logits_tvalid,m_logits_tlast;
  wire [3:0] m_logits_tclass;
  kwt_vector_fp16 dut(clk,rst_n,job_valid,job_ready,job,job_done,job_error,
    v_rd_en,v_rd_addr,v_rd_data,v_wr_en,v_wr_addr,v_wr_data,v_wr_strb,v_wr_ready,
    param_rd_en,param_rd_addr,param_rd_data,m_logits_tdata,m_logits_tvalid,
    m_logits_tready,m_logits_tclass,m_logits_tlast);
  reg [7:0] mem[0:8191],params[0:1023];
  real golden[0:127];
  reg seen[0:127];
  integer cycles=0,checked=0,case_checked=0,cases=0,stalls=0;
  integer test_rows=0,test_cols=0,test_df=3,test_kind=0;
  integer j,rel,row,col,lane,index,read_lane;
  reg checking=0,stalled=0,logits_seen=0;
  reg [17:0] held_addr;
  reg [511:0] held_data;
  reg [63:0] held_strb,wanted_strb;
  real actual,err,tolerance;
  function automatic [31:0] exact_quarter(input integer q);
    integer mag,top,k;reg [7:0] e;reg [22:0] f;
    begin
      mag=q<0?-q:q;top=0;
      for(k=0;k<23;k=k+1)if(mag>=(1<<k))top=k;
      e=125+top;f=(mag-(1<<top))<<(23-top);
      exact_quarter=mag==0?32'd0:{(q<0),e,f};
    end
  endfunction
  function automatic real decode32(input [31:0] v);
    real value;
    begin
      value=(v[30:23]==0)?v[22:0]*(2.0**(-149)):
        (1.0+v[22:0]/8388608.0)*(2.0**(integer'(v[30:23])-127));
      decode32=v[31]?-value:value;
    end
  endfunction
  function automatic real decode16(input [15:0] v);
    real value;
    begin
      value=(v[14:10]==0)?v[9:0]*(2.0**(-24)):
        (1.0+v[9:0]/1024.0)*(2.0**(integer'(v[14:10])-15));
      decode16=v[15]?-value:value;
    end
  endfunction
  task automatic put32(input bit parameter_space,input integer address,input [31:0] v);
    integer k;
    begin for(k=0;k<4;k=k+1)begin
      if(parameter_space)params[address+k]=v[8*k+:8];else mem[address+k]=v[8*k+:8];
    end end
  endtask
  always @(negedge clk)begin
    if(!rst_n)begin cycles=0;v_wr_ready=0;m_logits_tready=0;end
    else begin cycles=cycles+1;v_wr_ready=(cycles%9>=4);m_logits_tready=(cycles%11>=6);end
  end
  always @(posedge clk)if(rst_n)begin
    if(v_rd_en)begin
      if((^v_rd_addr)===1'bx || v_rd_addr+63>=8192 || v_rd_addr[5:0]!=0)$fatal(1,"VPU read address");
      for(read_lane=0;read_lane<64;read_lane=read_lane+1)v_rd_data[8*read_lane+:8]<=mem[v_rd_addr+read_lane];
    end
    if(param_rd_en)begin
      if((^param_rd_addr)===1'bx || param_rd_addr+7>=1024 || param_rd_addr[2:0]!=0)$fatal(1,"VPU parameter address");
      for(read_lane=0;read_lane<8;read_lane=read_lane+1)param_rd_data[8*read_lane+:8]<=params[param_rd_addr+read_lane];
    end
    if(stalled && (v_wr_en!==1 || v_wr_addr!==held_addr || v_wr_data!==held_data || v_wr_strb!==held_strb))
      $fatal(1,"VPU write changed under backpressure");
    stalled=v_wr_en&&!v_wr_ready;
    if(stalled)begin held_addr=v_wr_addr;held_data=v_wr_data;held_strb=v_wr_strb;stalls=stalls+1;end
    if(v_wr_en&&v_wr_ready)begin
      if(!checking || test_kind==9)$fatal(1,"Unexpected VPU write");
      if((^v_wr_addr)===1'bx || (^v_wr_data)===1'bx || (^v_wr_strb)===1'bx)$fatal(1,"VPU X output");
      rel=v_wr_addr-4096;row=rel/256;col=(rel%256)/(test_df==1?2:4);
      if(rel<0 || row>=test_rows || rel%64!=0 || col>=test_cols)$fatal(1,"VPU output bounds");
      wanted_strb=0;
      for(lane=0;lane<(test_df==1?32:16);lane=lane+1)begin
        if(col+lane<test_cols)begin
          index=row*test_cols+col+lane;
          if(seen[index])$fatal(1,"VPU duplicate output");
          seen[index]=1;case_checked=case_checked+1;checked=checked+1;
          if(test_df==1)begin
            wanted_strb[2*lane+:2]=2'b11;
            if(v_wr_data[16*lane+10+:5]==31)$fatal(1,"VPU nonfinite half");
            actual=decode16(v_wr_data[16*lane+:16]);
          end else begin
            wanted_strb[4*lane+:4]=4'hf;
            if(v_wr_data[32*lane+23+:8]==255)$fatal(1,"VPU nonfinite single");
            actual=decode32(v_wr_data[32*lane+:32]);
          end
          err=actual-golden[index];if(err<0)err=-err;
          tolerance=(test_df==1)?0.001:0.00005;
          if(err>tolerance)$fatal(1,"VPU kind=%0d row=%0d col=%0d got=%e want=%e err=%e",test_kind,row,col+lane,actual,golden[index],err);
        end
      end
      if(v_wr_strb!==wanted_strb)$fatal(1,"VPU tail strobes");
    end
    if(m_logits_tvalid)begin
      if(!checking || test_kind!=9 || m_logits_tclass!==4'd3 || m_logits_tlast!==1)$fatal(1,"VPU logits/class/last");
      for(j=0;j<12;j=j+1)begin
        if((^m_logits_tdata[16*j+:16])===1'bx || decode16(m_logits_tdata[16*j+:16])!=golden[j])$fatal(1,"VPU logits data");
      end
      if(m_logits_tready)begin
        if(logits_seen)$fatal(1,"Duplicate logits beat");
        logits_seen=1;
      end
    end
  end else stalled=0;
  task automatic submit(input bit expect_error);
    integer count;
    begin
      @(negedge clk);if(job_ready!==1)$fatal(1,"VPU not ready");job_valid=1;
      @(negedge clk);job_valid=0;job=0;count=0;
      while(job_done!==1 && count<10000)begin @(negedge clk);count=count+1;end
      if(job_done!==1 || job_error!==expect_error)$fatal(1,"VPU completion error=%b expected=%b cycles=%0d",job_error,expect_error,count);
      @(negedge clk);if(job_done!==0 || job_ready!==1)$fatal(1,"VPU recovery");
    end
  endtask
  task automatic run_case(input integer kind,nrows,ncols,dfmt);
    integer i,r,c,q,opcode,gamma_value,beta_value;
    real value,aux,denom,z,tn;
    begin
      cases=cases+1;test_kind=kind;test_rows=nrows;test_cols=ncols;test_df=dfmt;case_checked=0;logits_seen=0;
      for(i=0;i<8192;i=i+1)mem[i]=0;
      for(i=0;i<1024;i=i+1)params[i]=0;
      for(i=0;i<128;i=i+1)seen[i]=0;
      for(c=0;c<64;c=c+1)begin
        put32(1,c*4,exact_quarter(4*(1+c%2)));
        put32(1,256+c*4,exact_quarter(4*(c%3-1)));
      end
      put32(1,512,32'h3f800000); // epsilon=1 gives analytically simple references.
      for(r=0;r<nrows;r=r+1)begin
        denom=0;
        for(c=0;c<ncols;c=c+1)denom=denom+$exp(c%3-1.0);
        for(c=0;c<ncols;c=c+1)begin
          case(kind)
            0:q=4*r;
            1:q=4*(c%3-1);
            2,5:q=(c%2==0)?-4:4;
            3:q=8;
            9:q=(c==3 || c==7)?12:4*(c%3-1);
            default:q=2*(c%9-4);
          endcase
          value=q/4.0;aux=(kind==5)?value:1.0;
          put32(0,r*256+c*4,exact_quarter(q));
          put32(0,2048+r*256+c*4,(kind==5)?exact_quarter(q):32'h3f800000);
          gamma_value=1+c%2;beta_value=c%3-1;
          case(kind)
            0:golden[r*ncols+c]=1.0/ncols;
            1:golden[r*ncols+c]=$exp(value)/denom;
            2:golden[r*ncols+c]=value/$sqrt(2.0)*gamma_value+beta_value;
            3:golden[r*ncols+c]=beta_value;
            4:begin
              z=$sqrt(2.0/3.141592653589793)*(value+0.044715*value*value*value);
              tn=($exp(2*z)-1)/($exp(2*z)+1);
              golden[r*ncols+c]=0.5*value*(1+tn);
            end
            5:golden[r*ncols+c]=(value+aux)/$sqrt(5.0)*gamma_value+beta_value;
            6:golden[r*ncols+c]=value*0.5;
            7:golden[r*ncols+c]=value+aux;
            default:golden[r*ncols+c]=value;
          endcase
        end
      end
      case(kind)
        0,1:opcode=0;
        2,3:opcode=1;
        4:opcode=2;
        5:opcode=9;
        6:opcode=6;
        7:opcode=7;
        8:opcode=3;
        default:opcode=4;
      endcase
      if(kind==6)put32(1,0,32'h3f000000);
      job=0;job[195:192]=opcode;job[191:190]=3;job[189:188]=dfmt;job[187:186]=3;
      job[185:170]=nrows;job[169:154]=ncols;job[153:138]=256;job[137:122]=256;job[121:106]=256;
      job[73:56]=0;job[55:38]=4096;job[37:20]=2048;job[19:0]=0;
      checking=1;submit(0);checking=0;
      if(kind==9)begin if(!logits_seen)$fatal(1,"Missing logits transfer");end
      else if(case_checked!=nrows*ncols)$fatal(1,"Missing VPU outputs %0d/%0d",case_checked,nrows*ncols);
      $display("VECTOR_CASE_PASS kind=%0d op=%0d rows=%0d cols=%0d df=%0d",kind,opcode,nrows,ncols,dfmt);
    end
  endtask
  initial begin #2000000;$fatal(1,"tb_vector watchdog");end
  initial begin
    repeat(4)@(negedge clk);rst_n=1;
    run_case(0,2,64,3); // softmax equal inputs
    run_case(1,1,33,3); // nonuniform softmax, tail
    run_case(2,2,64,3); // LayerNorm nonzero variance + gamma/beta
    run_case(3,1,64,3); // LayerNorm zero variance -> beta
    run_case(4,1,33,3); // GELU approximate definition
    run_case(5,1,64,3); // residual + LayerNorm
    run_case(6,1,33,3); // scale
    run_case(7,2,33,3); // residual add
    run_case(8,1,33,1); // FP32 to FP16 store, tail
    run_case(9,1,12,1); // logits tie: first maximum index=3
    job=0;submit(1); // zero dimensions are rejected
    job=0;job[195:192]=8;submit(1); // unsupported operator
    if(stalls==0)$fatal(1,"Missing VPU backpressure coverage");
    $display("PASS tb_vector cases=%0d outputs=%0d stalls=%0d rejected_jobs=2",cases,checked,stalls);
    $finish;
  end
endmodule
