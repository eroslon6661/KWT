// Independent accelerator integration, ICB stimulus supplied by TB (no E203).
// +LAYERS=12, when supported, is accelerator autonomous scheduling, not CPU chaining.
`timescale 1ns/1ps
module tb_accel_fault;
  reg clk=0;always #5 clk=~clk;
  reg rst_n=0,cv=0,cread=1,sready=1;
  reg [31:0] ca=0,cwd=0;reg [3:0] cm=15;
  wire cr,sv,se,irq;wire [31:0] sd;
  wire mv,mread,mready;wire [31:0] ma,mwd;wire [3:0] mm;
  reg mrvalid=0,merr=0;reg [31:0] mrd=0;
  wire mrready;
  kwt_accel_icb dut(
    .clk(clk),.rst_n(rst_n),.s_icb_cmd_valid(cv),.s_icb_cmd_ready(cr),
    .s_icb_cmd_addr(ca),.s_icb_cmd_read(cread),.s_icb_cmd_wdata(cwd),.s_icb_cmd_wmask(cm),
    .s_icb_rsp_valid(sv),.s_icb_rsp_ready(sready),.s_icb_rsp_rdata(sd),.s_icb_rsp_err(se),
    .m_icb_cmd_valid(mv),.m_icb_cmd_ready(mready),.m_icb_cmd_addr(ma),
    .m_icb_cmd_read(mread),.m_icb_cmd_wdata(mwd),.m_icb_cmd_wmask(mm),
    .m_icb_rsp_valid(mrvalid),.m_icb_rsp_ready(mrready),.m_icb_rsp_rdata(mrd),.m_icb_rsp_err(merr),.irq(irq));

  integer mem_check;
  reg [31:0] memory[0:262143];
  reg pending=0,saved_error=0,force_stall=0,inject_output=0;
  reg [31:0] saved_data;
  integer cycles=0,delay_count=0,cmds=0,rsps=0,inject=-1;
  integer before_cmds,wait_count,errors_seen=0,fd;
  reg [31:0] result;
  assign mready=rst_n&&!force_stall&&!pending&&!mrvalid&&(cycles%7!=0);
  always @(posedge clk)begin
    cycles=cycles+1;
    if(!rst_n)begin pending<=0;mrvalid<=0;end
    else begin
      if(mv&&mready)begin
        saved_error<=(cmds==inject)||(!mread&&inject_output);saved_data<=memory[(ma-32'h80000000)>>2];
        cmds=cmds+1;pending<=1;delay_count<=cycles%5;
      end
      if(pending)begin
        if(delay_count==0)begin mrvalid<=1;merr<=saved_error;mrd<=saved_data;pending<=0;end
        else delay_count<=delay_count-1;
      end
      if(mrvalid&&mrready)begin mrvalid<=0;rsps=rsps+1;end
      if(dut.error)errors_seen=errors_seen+1;
      if(dut.error&&(pending||mrvalid||dut.u_run.dbusy))$fatal(1,"UNDRAINED ERROR");
    end
  end
  task csr(input bit rd,input [31:0] addr,input [31:0] value,input bit expected_error);
    begin
      @(negedge clk);cv=1;cread=rd;ca=addr;cwd=value;
      do @(posedge clk);while(!cr);
      @(negedge clk);cv=0;
      while(!sv)@(negedge clk);
      if(se!==expected_error)$fatal(1,"CSR ERROR %h",addr);
      result=sd;@(posedge clk);@(negedge clk);
    end
  endtask
  task configure;
    begin
      csr(0,'h10,32'h80000000,0);csr(0,'h14,32'h80004000,0);
      csr(0,'h18,32'h80010000,0);csr(0,'h1c,32'hd000,0);
      csr(0,'h20,1,0);csr(0,'hc,1,0);
    end
  endtask
  task await_error(input [7:0] code);
    begin
      wait_count=0;
      while(!irq&&wait_count<2000000)begin @(negedge clk);wait_count=wait_count+1;end
      if(!irq)$fatal(1,"ERROR TIMEOUT");
      csr(1,'h8,0,0);if(result!==4)$fatal(1,"ERROR STATUS %h",result);
      csr(1,'h24,0,0);if(result!==code)$fatal(1,"ERROR CODE got=%h expected=%h",result,code);
      if(cmds!=rsps)$fatal(1,"COMMAND RESPONSE COUNTS");
      csr(0,'h8,4,0);if(irq)$fatal(1,"IRQ CLEAR");
    end
  endtask
  initial begin
    fd=$fopen("results/fault_status.txt","w");if(fd==0)$fatal(1,"Cannot write fault status");$fdisplay(fd,"FAIL");$fclose(fd);
    $readmemh("vectors/integration/system.hex",memory);
    for(mem_check=0;mem_check<262144;mem_check=mem_check+1)
      if((^memory[mem_check])===1'bx)$fatal(1,"MISSING/X MEMORY INPUT %0d",mem_check);
    repeat(5)@(negedge clk);rst_n=1;configure;
    // Reject an illegal descriptor at START without touching memory.
    before_cmds=cmds;csr(0,'h20,0,0);csr(0,'h4,1,1);
    if(cmds!=before_cmds||dut.busy)$fatal(1,"INVALID CONFIG STARTED");
    csr(0,'h20,13,0);csr(0,'h4,1,1);
    csr(0,'h20,1,0);csr(0,'h18,32'hfffff000,0);csr(0,'h4,1,1);
    configure;
    // Bus fault during input, then retry without resetting the device.
    inject=cmds+7;csr(0,'h4,1,0);
    csr(0,'h18,32'hdead0000,1);csr(0,'h4,1,1);
    await_error(8'h14);inject=-1;
    // Header format error and recovery.
    memory['h4000]=0;csr(0,'h4,1,0);await_error(8'h20);
    memory['h4000]=32'h4b575431;
    // Bad weight scale must never set that matrix cache valid.
    memory['h4002]=0;csr(0,'h4,1,0);await_error(8'h30);
    if(dut.valid!=0)$fatal(1,"BAD SCALE CACHE VALID");
    $readmemh("vectors/integration/system.hex",memory);
    for(mem_check=0;mem_check<262144;mem_check=mem_check+1)
      if((^memory[mem_check])===1'bx)$fatal(1,"MISSING/X MEMORY INPUT %0d",mem_check);
    // Bus fault during weight loading (input + header + parameters + 9 weights).
    inject=cmds+3168+8+898+9;csr(0,'h4,1,0);await_error(8'h14);inject=-1;
    // Core fault while a valid bus command is stalled: drain, do not cancel.
    csr(0,'h4,1,0);
    wait(dut.u_run.state==10);@(negedge clk);force_stall=1;
    wait(mv);@(negedge clk);
    force dut.le=1;force dut.lec=4'd3;
    @(negedge clk);release dut.le;release dut.lec;
    repeat(8)begin @(negedge clk);if(!mv||!dut.busy||irq)$fatal(1,"CANCELLED STALLED COMMAND");end
    force_stall=0;await_error(8'h43);
    // Successful restart reaches a committed weight bank; coordinated reset is legal.
    csr(0,'h4,1,0);wait(dut.valid[0]);
    @(negedge clk);rst_n=0;repeat(3)@(negedge clk);
    if(mv||irq||dut.busy)$fatal(1,"RESET");
    rst_n=1;repeat(3)@(negedge clk);
    csr(1,0,0,0);if(result!==32'h4b575431)$fatal(1,"RESET RECOVERY");
    // A real full layer followed by an output write-response error.
    configure;inject_output=1;csr(0,'h4,1,0);await_error(8'h14);
    if(errors_seen!=6)$fatal(1,"FAULT COUNT %0d",errors_seen);
    fd=$fopen("results/fault_status.txt","w");if(fd==0)$fatal(1,"Cannot write fault status");$fdisplay(fd,"PASS");$fclose(fd);
    $display("PASS tb_accel_fault fault_cases=6 illegal_start_cases=3 busy_write_rejected restart_verified output_error_verified bus_cmds=%0d",cmds);
    $finish;
  end
  initial begin #30000000;$fatal(1,"WATCHDOG");end
endmodule
