`timescale 1ns/1ps
// Address and byte-lane scoreboard. No hierarchical memory initialization.
module sram_checker #(parameter AW=10, LANES=4)(output reg finished=0);
  localparam DW=LANES*16, BYTES=LANES*2, DEPTH=(1<<AW);
  reg clk=0; always #50 clk=~clk;
  reg en=0,we=0;
  reg [AW-1:0] addr=0;
  reg [DW-1:0] wdata=0;
  reg [BYTES-1:0] wstrb=0;
  wire [DW-1:0] rdata;
  reg [DW-1:0] expected[0:DEPTH-1];
  reg [DW-1:0] held,pattern;
  integer a,b,k,checks=0;
  kwt_sram_bank #(.AW(AW),.LANES(LANES)) dut(.*);
  task write_word(input integer index,input [DW-1:0] value,input [BYTES-1:0] mask,input enable);
    integer j;
    begin
      @(negedge clk);en=enable;we=1;addr=index;wdata=value;wstrb=mask;
      @(posedge clk);#25;
      if(enable) for(j=0;j<BYTES;j=j+1)
        if(mask[j]) expected[index][j*8+:8]=value[j*8+:8];
    end
  endtask
  task read_word(input integer index);
    begin
      @(negedge clk);en=1;we=0;addr=index;wstrb=0;
      @(posedge clk);#25;
      if(rdata!==expected[index])$fatal(1,"SRAM AW=%0d LANES=%0d address=%h got=%h expected=%h",AW,LANES,index,rdata,expected[index]);
      checks=checks+1;
    end
  endtask
  initial begin
    // Unique addresses and byte lanes catch aliases and endian/lane swaps.
    for(a=0;a<DEPTH;a=a+1)begin
      for(b=0;b<BYTES;b=b+1)pattern[b*8+:8]=(a*37+(a>>8)*17+b*53)^8'ha5;
      write_word(a,pattern,{BYTES{1'b1}},1);
    end
    for(a=DEPTH-1;a>=0;a=a-1)read_word(a);
    // Walking single byte, alternating bytes, zero mask and all-byte writes.
    for(k=0;k<BYTES;k=k+1)begin
      a=(k*67)%(DEPTH-1);
      pattern=~expected[a];
      write_word(a,pattern,({{(BYTES-1){1'b0}},1'b1}<<k),1);
      read_word(a);
      read_word((a+1)%DEPTH);
    end
    for(k=0;k<4;k=k+1)begin
      a=(k==0)?0:(k==1)?DEPTH/2-1:(k==2)?DEPTH/2:DEPTH-1;
      write_word(a,{DW{1'b1}},0,1);read_word(a);
      write_word(a,~expected[a],{BYTES{1'b1}},0);read_word(a);
    end
    read_word(DEPTH-1);held=rdata;
    @(negedge clk);en=0;addr=0;we=0;
    repeat(4)begin @(posedge clk);#25;if(rdata!==held)$fatal(1,"SRAM DISABLED READ HOLD AW=%0d",AW);end
    @(negedge clk);en=0;
    $display("SRAM_CASE_PASS AW=%0d LANES=%0d words=%0d checks=%0d",AW,LANES,DEPTH,checks);
    finished=1;
  end
endmodule
module tb_sram;
  wire f10,f11,f12;
  sram_checker #(.AW(10),.LANES(4)) s1024(f10);
  sram_checker #(.AW(11),.LANES(32)) s2048(f11);
  sram_checker #(.AW(12),.LANES(4)) s4096(f12);
  initial begin wait(f10&&f11&&f12);#1;$display("PASS tb_sram geometries=3 total_words=7168");$finish;end
  initial begin #2000000;$fatal(1,"SRAM TIMEOUT");end
endmodule
