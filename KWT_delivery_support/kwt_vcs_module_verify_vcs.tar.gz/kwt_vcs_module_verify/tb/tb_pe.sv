`timescale 1ns/1ps
module tb_pe;
  reg clk=0,rst=1,step=0,w_load=0;
  reg [15:0] w_data=0,data_in=0;
  reg [31:0] psum_in=0;
  wire [15:0] data_out;
  wire [31:0] psum_out;
  pe dut(clk,rst,step,w_load,w_data,data_in,psum_in,data_out,psum_out);
  always #5 clk=~clk;
  reg [31:0] q0=0,q1=0,want=0;
  reg [15:0] want_data=0;
  integer checked=0,i;
  task automatic cycle(input bit advance,load,input [15:0] weight,data,input [31:0] partial,new_sum);
    begin
      @(negedge clk);step=advance;w_load=load;w_data=weight;data_in=data;psum_in=partial;
      if(advance) begin want=q1;q1=q0;q0=new_sum;want_data=data;end
      @(posedge clk);#1;
      if(psum_out!==want || data_out!==want_data)
        $fatal(1,"PE latency/stall: got=%h want=%h data=%h want_data=%h",psum_out,want,data_out,want_data);
      checked=checked+1;
    end
  endtask
  task automatic reset_pipe;
    begin
      @(negedge clk);rst=1;step=0;w_load=0;#1;
      if(psum_out!==0 || data_out!==0)$fatal(1,"PE async reset");
      q0=0;q1=0;want=0;want_data=0;
      @(negedge clk);rst=0;
    end
  endtask
  initial begin #100000;$fatal(1,"tb_pe watchdog");end
  initial begin
    reset_pipe();
    cycle(0,1,16'h4000,0,0,0); // weight = 2; weight load is independent of step.
    cycle(1,0,0,16'h3c00,32'h40400000,32'h40a00000); // 1*2+3=5
    cycle(1,0,0,16'hc000,32'h3f800000,32'hc0400000); // -2*2+1=-3
    repeat(4)cycle(0,0,0,16'h7c00,32'hdeadbeef,0);
    cycle(1,0,0,16'h3800,32'hbf800000,32'h00000000); // .5*2-1=0
    cycle(1,1,16'hbc00,16'h4200,32'h40000000,32'h41000000); // simultaneous load uses OLD weight:3*2+2=8
    cycle(1,0,0,16'h4400,32'h3f800000,32'hc0400000); // new weight -1:4*-1+1=-3
    cycle(1,0,0,16'h0001,0,32'hb3800000); // smallest half subnormal * -1
    cycle(1,0,0,16'h7c00,0,32'hff800000);
    cycle(0,1,16'h0000,0,0,0);
    cycle(1,0,0,16'h7c00,0,32'h7fc00000); // infinity*zero invalid
    cycle(1,0,0,0,0,0);
    cycle(1,0,0,0,0,0);
    cycle(1,0,0,0,0,0);
    // Abort a pending nonzero operation, then prove reset cleared weight too.
    cycle(0,1,16'h3c00,0,0,0);
    cycle(1,0,0,16'h3c00,0,32'h3f800000);
    reset_pipe();
    for(i=0;i<5;i=i+1) cycle(1,0,0,16'h4400,0,0);
    $display("PASS tb_pe checked_cycles=%0d enabled_latency=3",checked);
    $finish;
  end
endmodule
