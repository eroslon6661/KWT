// Derived from the existing independently generated NumPy golden-vector regression.
`timescale 1ns/1ps
module tb_dequant;
  localparam integer VECTOR_COUNT = 15584;
  reg clk=0;always #5 clk=~clk;
  reg rst_n=0,sv=0,mr=0;
  wire sr,mv;
  reg [31:0] sd=0,sc=0;
  reg [3:0] sk=0;
  reg sl=0;
  wire [63:0] md;
  wire [7:0] ms;
  wire ml;
  wire [1:0] me;
  wire [3:0] mo;
  kwt_weight_dequant dut(.clk(clk),.rst_n(rst_n),
    .s_valid(sv),.s_ready(sr),.s_data(sd),.s_scale(sc),.s_keep(sk),.s_last(sl),
    .m_valid(mv),.m_ready(mr),.m_data(md),.m_strb(ms),.m_last(ml),.m_error(me),.m_overflow(mo));
  reg [511:0] vectors[0:VECTOR_COUNT-1];
  integer accept_cycle[0:VECTOR_COUNT-1];
  integer phase=0,sent=0,received=0,normalized=0,cycles=0,stalls=0;
  integer model_weights=0,errors_seen=0,overflow_seen=0,last_seen=0,previous_output_cycle=0;
  reg in_fire=0,held=0;
  reg [78:0] previous;
  wire [78:0] payload={mo,me,ml,ms,md};
  reg [31:0] random_state=32'h56e349b7;
  reg [511:0] item;
  integer fd,i,timeout_count;
  task tick;begin @(negedge clk);#1;end endtask

  always @(posedge clk)begin
    cycles=cycles+1;
    if(!rst_n)begin
      sent=0;received=0;normalized=0;held=0;in_fire=0;
      model_weights=0;errors_seen=0;overflow_seen=0;last_seen=0;
    end else begin
      in_fire=sv&&sr;
      if(in_fire)begin
        accept_cycle[sent]=cycles;sent=sent+1;
      end
      // Also compare the FP32 rounding stage, not only final FP16 data.
      if(dut.v1&&dut.r2)begin
        if({dut.f3,dut.f2,dut.f1,dut.f0}!==vectors[normalized][274:147])
          $fatal(1,"FP32 PRODUCT index=%0d got=%h expected=%h",normalized,
            {dut.f3,dut.f2,dut.f1,dut.f0},vectors[normalized][274:147]);
        normalized=normalized+1;
      end
      if(held&&(!mv||payload!==previous))$fatal(1,"OUTPUT HOLD");
      held=mv&&!mr;previous=payload;
      if(held)stalls=stalls+1;
      if(mv&&mr)begin
        if(received>=sent)$fatal(1,"UNSOLICITED OUTPUT");
        item=vectors[received];
        if(md!==item[132:69]||ms!==item[140:133]||ml!==item[68]||me!==item[142:141]||mo!==item[146:143])
          $fatal(1,"RESULT index=%0d data=%h expected=%h strb=%h err=%h ov=%h",received,md,item[132:69],ms,me,mo);
        if(phase==2&&received<1000)begin
          if(cycles-accept_cycle[received]!=3)$fatal(1,"PIPELINE LATENCY");
          if(received>0&&cycles-previous_output_cycle!=1)$fatal(1,"PIPELINE THROUGHPUT");
        end
        previous_output_cycle=cycles;
        if(item[282:275]==0)model_weights=model_weights+4;
        if(me[0])errors_seen=errors_seen+1;
        if(me[1])overflow_seen=overflow_seen+1;
        if(ml)last_seen=last_seen+1;
        received=received+1;
      end
      if(sent-received>3)$fatal(1,"ELASTIC CAPACITY");
    end
  end

  always @(negedge clk)begin
    random_state={random_state[30:0],random_state[31]^random_state[21]^random_state[1]^random_state[0]};
    if(!rst_n||phase==0)begin sv=0;mr=0;end
    else begin
      mr=(phase==1)?0:((received<1000)?1:((|random_state[3:0])&&(cycles%257>=64)));
      if(!sv||in_fire)begin
        if(sent<VECTOR_COUNT&&(phase==1||sent<1024||(|random_state[7:5])))begin
          sv=1;sd=vectors[sent][31:0];sc=vectors[sent][63:32];
          sk=vectors[sent][67:64];sl=vectors[sent][68];
        end else sv=0;
      end
    end
  end

  initial begin
    fd=$fopen("results/unit.status","w");if(fd==0)$fatal(1,"Cannot write results/unit.status");$fdisplay(fd,"FAIL");$fclose(fd);
    $readmemh("vectors/integration/dequant.hex",vectors);
    for(i=0;i<VECTOR_COUNT;i=i+1)if((^vectors[i])===1'bx)$fatal(1,"MISSING/X DEQUANT VECTOR %0d",i);
    repeat(3)tick;rst_n=1;phase=1;#1;
    timeout_count=0;
    while(sr&&timeout_count<20)begin tick;timeout_count=timeout_count+1;end
    if(sent!=3||received!=0||sr)$fatal(1,"PIPELINE NOT FULL");
    repeat(8)tick;
    #2;rst_n=0;#1;
    if(mv||sr)$fatal(1,"ASYNC RESET DID NOT FLUSH");
    phase=0;repeat(3)tick;rst_n=1;
    repeat(5)begin tick;if(mv)$fatal(1,"STALE OUTPUT AFTER RESET");end
    phase=2;
    timeout_count=0;
    while(received<VECTOR_COUNT&&timeout_count<1000000)begin tick;timeout_count=timeout_count+1;end
    if(received!=VECTOR_COUNT||sent!=VECTOR_COUNT||normalized!=VECTOR_COUNT||model_weights!=4096)$fatal(1,"COUNTS");
    repeat(5)begin tick;if(mv)$fatal(1,"EXTRA OUTPUT");end
    fd=$fopen("results/unit.status","w");if(fd==0)$fatal(1,"Cannot write results/unit.status");$fdisplay(fd,"PASS");$fclose(fd);
    $display("PASS tb_dequant beats=%0d fp32_products=%0d model_weights=%0d invalid_beats=%0d overflow_beats=%0d last_beats=%0d stalls=%0d",received,normalized*4,model_weights,errors_seen,overflow_seen,last_seen,stalls);
    $finish;
  end
  initial begin #20000000;$fatal(1,"WATCHDOG");end
endmodule
