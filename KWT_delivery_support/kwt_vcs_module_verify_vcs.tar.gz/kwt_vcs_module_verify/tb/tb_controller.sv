`timescale 1ns/1ps
module tb_controller;
  reg clk=0;always #5 clk=~clk;
  reg rst_n=0,start_valid=0,params_ready=0;
  reg [19:0] param_base=0;
  wire start_ready,busy,done,error,stage_done,gemm_valid,vec_valid;
  wire [3:0] error_code;
  wire [4:0] stage_id;
  wire [255:0] gemm_job;
  wire [195:0] vec_job;
  reg gemm_ready=0,gemm_done=0,gemm_error=0,vec_ready=0,vec_done=0,vec_error=0;
  integer issued=0,completed=0,finished=0,faults=0,s,k;
  reg [255:0] held_g;
  reg [195:0] held_v;
  kwt_encoder_layer_ctrl_local dut(.*);
  task tick;begin @(negedge clk);#1;end endtask
  function is_vector(input integer st);
    begin case(st)1,3,5,7,8,10,12,14,16:is_vector=1;default:is_vector=0;endcase end
  endfunction
  always @(posedge clk)if(rst_n)begin
    if(gemm_valid&&gemm_ready || vec_valid&&vec_ready)issued=issued+1;
    if(stage_done)completed=completed+1;
    if(done)finished=finished+1;
    if(error)faults=faults+1;
    if(gemm_valid&&vec_valid)$fatal(1,"CONTROLLER BOTH UNITS VALID");
  end
  task launch(input [19:0] base);
    begin
      tick;params_ready=1;param_base=base;#1;
      if(start_ready!==1)$fatal(1,"CONTROLLER START NOT READY");
      start_valid=1;@(posedge clk);#1;
      tick;start_valid=0;param_base=20'hfffff;
    end
  endtask
  task check_job(input integer st,input [19:0] base);
    reg [17:0] dst;
    reg [19:0] weight;
    integer ni,ki,op;
    begin
      if(stage_id!==st || gemm_valid!==!is_vector(st) || vec_valid!==is_vector(st))
        $fatal(1,"CONTROLLER STAGE ORDER stage=%0d expected=%0d",stage_id,st);
      if(is_vector(st))begin
        case(st)
          1,10:begin dst='h04000;op=3;end
          3:begin dst='h08000;op=3;end
          5:begin dst='h0c000;op=3;end
          7:begin dst='h10000;op=6;end
          8:begin dst='h10000;op=0;end
          12,16:begin dst=0;op=9;end
          14:begin dst='h04000;op=2;end
          default:$fatal(1,"BAD EXPECTED VECTOR STAGE");
        endcase
        if(vec_job[55:38]!==dst || vec_job[195:192]!==op[3:0] || vec_job[185:170]!==16'd99)
          $fatal(1,"CONTROLLER VECTOR DESCRIPTOR stage=%0d job=%h",st,vec_job);
      end else begin
        dst=(st==9||st==13)?18'h04000:(st==15)?18'h12000:18'h10000;
        ni=(st==6)?99:(st==13)?256:64;
        ki=(st==9)?99:(st==15)?256:64;
        case(st)
          0:weight=base;2:weight=base+'h02000;4:weight=base+'h04000;
          6:weight='h08000;9:weight='h0c000;11:weight=base+'h06000;
          13:weight=base+'h08000;15:weight=base+'h10000;
          default:$fatal(1,"BAD EXPECTED GEMM STAGE");
        endcase
        if(gemm_job[17:0]!==dst || gemm_job[171:156]!==16'd99 ||
           gemm_job[155:140]!==ni[15:0] || gemm_job[139:124]!==ki[15:0] || gemm_job[57:38]!==weight)
          $fatal(1,"CONTROLLER GEMM DESCRIPTOR stage=%0d job=%h",st,gemm_job);
      end
    end
  endtask
  task execute(input [19:0] base,input integer fail_stage);
    integer st,j,old_issued,old_completed,old_finished,old_faults;
    begin
      old_issued=issued;old_completed=completed;old_finished=finished;old_faults=faults;
      launch(base);
      for(st=0;st<17;st=st+1)begin
        while(!(gemm_valid||vec_valid))tick;
        check_job(st,base);held_g=gemm_job;held_v=vec_job;
        for(j=0;j<st%3+2;j=j+1)begin
          tick;
          if(!busy||done||error||stage_done||stage_id!==st||gemm_job!==held_g||vec_job!==held_v)
            $fatal(1,"CONTROLLER ISSUE STALL stage=%0d",st);
          check_job(st,base);
        end
        gemm_ready=!is_vector(st);vec_ready=is_vector(st);
        @(posedge clk);#1;tick;gemm_ready=0;vec_ready=0;
        repeat(3)begin
          if(gemm_valid||vec_valid||stage_done||done||error||!busy)$fatal(1,"CONTROLLER WAIT COMPLETION");
          tick;
        end
        if(is_vector(st))begin vec_done=1;vec_error=(st==fail_stage);end
        else begin gemm_done=1;gemm_error=(st==fail_stage);end
        @(posedge clk);#1;
        if(st==fail_stage)begin
          if(error!==1||done!==0||stage_done!==0||error_code!==(is_vector(st)?4'd3:4'd2))
            $fatal(1,"CONTROLLER ERROR PRIORITY stage=%0d",st);
        end else if(stage_done!==1||error!==0)$fatal(1,"CONTROLLER STAGE DONE stage=%0d",st);
        tick;gemm_done=0;vec_done=0;gemm_error=0;vec_error=0;
        @(posedge clk);#1;tick;
        if(st==fail_stage)st=17;
      end
      repeat(2)tick;
      if(fail_stage<0)begin
        if(issued!=old_issued+17||completed!=old_completed+17||finished!=old_finished+1||faults!=old_faults)
          $fatal(1,"CONTROLLER SUCCESS COUNTS");
      end else if(issued!=old_issued+fail_stage+1||completed!=old_completed+fail_stage||finished!=old_finished||faults!=old_faults+1)
        $fatal(1,"CONTROLLER FAILURE COUNTS");
      if(start_ready!==1||busy!==0)$fatal(1,"CONTROLLER IDLE RECOVERY");
    end
  endtask
  task bad_base(input [19:0] base);
    integer old_issued,old_faults;
    begin
      old_issued=issued;old_faults=faults;launch(base);
      while(!error)tick;
      if(error_code!==1||gemm_valid||vec_valid||done)$fatal(1,"CONTROLLER BAD BASE");
      repeat(3)tick;
      if(issued!=old_issued||faults!=old_faults+1||!start_ready)$fatal(1,"CONTROLLER BAD BASE SIDE EFFECT");
    end
  endtask
  initial begin
    repeat(4)tick;rst_n=1;
    // Parameter readiness gates START; no task may be issued before accepted START.
    start_valid=1;
    repeat(4)begin tick;if(start_ready!==0||busy!==0||gemm_valid||vec_valid)$fatal(1,"PARAMETERS NOT READY");end
    start_valid=0;
    execute(0,-1);
    execute(20'he71f8,-1); // Last 8-byte-aligned base whose parameter span fits.
    bad_base(1);
    bad_base(20'he7200);
    execute(0,0); // GEMM error wins over simultaneous done.
    execute(0,1); // Vector error wins over simultaneous done.
    // Abort by coordinated reset during a stalled issued job, then restart.
    launch(0);while(!gemm_valid)tick;
    rst_n=0;#1;
    if(gemm_valid!==0||vec_valid!==0||busy!==0||done!==0||error!==0)$fatal(1,"CONTROLLER RESET");
    tick;rst_n=1;tick;execute(0,-1);
    $display("PASS tb_controller full_layers=3 stages=%0d faults=%0d",completed,faults);
    $finish;
  end
  initial begin #100000;$fatal(1,"CONTROLLER TIMEOUT");end
endmodule
