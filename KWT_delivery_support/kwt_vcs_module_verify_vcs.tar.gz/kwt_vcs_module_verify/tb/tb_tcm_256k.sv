`timescale 1ns/1ps
// Standalone functional wiring test. Valid reads are sampled 25 ns after CLK.
// Scoreboard models software-visible words and bytes, not macro/bank internals.
module tcm_checker #(
    parameter WORD_WIDTH = 64,
    parameter WORD_ADDR_WIDTH = 15
)(input wire CLK, output reg done);
    localparam DEPTH = 1 << WORD_ADDR_WIDTH;
    localparam BYTES = WORD_WIDTH / 8;
    localparam BANKS = DEPTH / 4096;
    reg RSTN;
    reg [WORD_ADDR_WIDTH-1:0] ADDRESS;
    reg CS, WE;
    reg [BYTES-1:0] WEM;
    reg [WORD_WIDTH-1:0] WDATA;
    wire [WORD_WIDTH-1:0] RDATA;
    reg [WORD_WIDTH-1:0] expected [0:DEPTH-1];
    integer reads, writes, masked_writes, disabled_writes, idle_checks;
    integer phase, a, b, edge_index, byte_index, iteration;
    integer target;
    reg [BYTES-1:0] mask;
    reg [WORD_WIDTH-1:0] value;

    kwt_tcm_4096x16 #(
        .WORD_WIDTH(WORD_WIDTH), .WORD_ADDR_WIDTH(WORD_ADDR_WIDTH)
    ) dut (
        .CLK(CLK), .RSTN(RSTN), .ADDRESS(ADDRESS), .CS(CS), .WE(WE),
        .WEM(WEM), .WDATA(WDATA), .RDATA(RDATA)
    );

    // Every address has a unique word; lanes also differ. Phase 1 complements
    // every bit, exposing stuck data bits as well as address aliases.
    function automatic [WORD_WIDTH-1:0] address_pattern(
        input integer index, input integer phase_value
    );
        integer lane;
        reg [15:0] segment;
        begin
            for (lane = 0; lane < WORD_WIDTH/16; lane = lane+1) begin
                segment = index ^ (16'h3c57 + lane * 16'h1311);
                address_pattern[16*lane+:16] = phase_value ? ~segment : segment;
            end
        end
    endfunction

    task automatic write_word(
        input integer index,
        input reg [WORD_WIDTH-1:0] data,
        input reg [BYTES-1:0] byte_mask,
        input bit selected
    );
        integer k;
        begin
            @(negedge CLK);
            ADDRESS = index; WDATA = data; WEM = byte_mask;
            CS = selected; WE = 1;
            @(posedge CLK);
            #25;
            if (selected) begin
                writes = writes + 1;
                for (k=0; k<BYTES; k=k+1)
                    if (byte_mask[k]) expected[index][8*k+:8] = data[8*k+:8];
                if (byte_mask != {BYTES{1'b1}}) masked_writes = masked_writes+1;
            end else disabled_writes = disabled_writes + 1;
            // Q during a write is deliberately not part of this test contract.
        end
    endtask

    task automatic read_word(input integer index);
        reg [WORD_WIDTH-1:0] before_clock;
        begin
            @(negedge CLK);
            before_clock = RDATA;
            ADDRESS = index; WDATA = 0; WEM = 0; CS = 1; WE = 0;
            #1;
            if (RDATA !== before_clock)
                $fatal(1, "ASYNC_READ width=%0d word=%h before=%h got=%h",
                       WORD_WIDTH, index, before_clock, RDATA);
            @(posedge CLK);
            #25;
            if (RDATA !== expected[index])
                $fatal(1, "READ_MISMATCH width=%0d word=%h expected=%h got=%h",
                       WORD_WIDTH, index, expected[index], RDATA);
            reads = reads + 1;
        end
    endtask

    task automatic idle_cycle(input integer index);
        reg [WORD_WIDTH-1:0] previous;
        begin
            @(negedge CLK);
            previous = RDATA;
            ADDRESS = index; WDATA = {WORD_WIDTH{1'b1}};
            WEM = {BYTES{1'b1}}; CS = 0; WE = 0;
            @(posedge CLK);
            #25;
            if (RDATA !== previous)
                $fatal(1, "IDLE_OUTPUT_CHANGED width=%0d expected=%h got=%h",
                       WORD_WIDTH, previous, RDATA);
            idle_checks = idle_checks + 1;
        end
    endtask

    initial begin
        done=0; RSTN=0; ADDRESS=0; CS=0; WE=0; WEM=0; WDATA=0;
        reads=0; writes=0; masked_writes=0; disabled_writes=0; idle_checks=0;
        repeat (3) @(negedge CLK);
        RSTN=1;

        for (phase=0; phase<2; phase=phase+1) begin
            $display("TCM_SCAN width=%0d phase=%0d words=%0d", WORD_WIDTH, phase, DEPTH);
            // Write the WHOLE memory before checking; a write-then-read loop
            // at one address alone would miss address aliases.
            for (a=0; a<DEPTH; a=a+1)
                write_word(a, address_pattern(a, phase), {BYTES{1'b1}}, 1'b1);
            for (a=DEPTH-1; a>=0; a=a-1) read_word(a);
        end

        // Exercise each byte separately at BOTH ends of EVERY macro bank.
        // The scoreboard preserves every unselected byte.
        for (b=0; b<BANKS; b=b+1) begin
            for (edge_index=0; edge_index<2; edge_index=edge_index+1) begin
                target = b*4096 + (edge_index ? 4095 : 0);
                for (byte_index=0; byte_index<BYTES; byte_index=byte_index+1) begin
                    mask = 0; mask[byte_index] = 1'b1;
                    value = ~expected[target];
                    write_word(target, value, mask, 1'b1);
                    read_word(target);
                end
                for (iteration=0; iteration<2; iteration=iteration+1) begin
                    for (byte_index=0; byte_index<BYTES; byte_index=byte_index+1)
                        mask[byte_index] = ((byte_index+iteration) % 2) != 0;
                    write_word(target, ~expected[target], mask, 1'b1);
                    read_word(target);
                end
                write_word(target, ~expected[target], {BYTES{1'b0}}, 1'b1);
                read_word(target);
                write_word(target, ~expected[target], {BYTES{1'b1}}, 1'b0);
                read_word(target);
            end
        end

        // Alternating banks every cycle catches combinational/stale bank muxes.
        for (iteration=0; iteration<3; iteration=iteration+1)
            for (b=0; b<BANKS; b=b+1) begin
                read_word(b*4096 + iteration);
                read_word((BANKS-1-b)*4096 + 4095-iteration);
            end

        // CS low must not read another bank or change the selected read output.
        read_word(DEPTH-1);
        for (b=0; b<BANKS; b=b+1) idle_cycle(b*4096);

        // RSTN clears read-bank selection only. Memory must retain contents.
        @(negedge CLK);
        CS=0; WE=0; WEM=0; RSTN=0;
        repeat (3) @(negedge CLK);
        RSTN=1;
        for (a=0; a<DEPTH; a=a+1) read_word(a);

        @(negedge CLK);
        CS=0; WE=0; WEM=0;
        $display("TCM_CASE_PASS width=%0d bytes=%0d banks=%0d macros=32 reads=%0d writes=%0d masked_writes=%0d disabled_writes=%0d idle_checks=%0d reset_retention_words=%0d",
                 WORD_WIDTH, DEPTH*BYTES, BANKS, reads, writes, masked_writes,
                 disabled_writes, idle_checks, DEPTH);
        done=1;
    end
endmodule

module tb_tcm_256k;
    reg CLK = 0;
    wire itcm_done, dtcm_done;
    integer status_file;
    always #50 CLK = ~CLK;

    tcm_checker #(.WORD_WIDTH(64), .WORD_ADDR_WIDTH(15)) itcm(
        .CLK(CLK), .done(itcm_done));
    tcm_checker #(.WORD_WIDTH(32), .WORD_ADDR_WIDTH(16)) dtcm(
        .CLK(CLK), .done(dtcm_done));

    initial begin
        wait (itcm_done && dtcm_done);
        status_file = $fopen("tcm_status.txt", "w");
        if (!status_file) $fatal(1, "Cannot create tcm_status.txt");
        $fdisplay(status_file, "PASS");
        $fclose(status_file);
        $display("PASS TCM_256K ITCM=262144 DTCM=262144");
        $finish;
    end
    initial begin
        #100000000;
        $fatal(1, "TIMEOUT TCM_256K itcm_done=%b dtcm_done=%b", itcm_done, dtcm_done);
    end
endmodule
