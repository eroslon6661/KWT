`timescale 1ns/1ps
module tb_dma;
  reg clk=0;always #5 clk=~clk;
  reg rst_n=0,jv=0,jread=1,rr=0,wv=0,cr=0,sv=0,se=0;
  reg [31:0] ja=0,wd=0,sd=0;
  reg [23:0] jw=0;
  wire jr,busy,done,error,rv,rl,wr,cv,cread,sr;
  wire [31:0] rd,ca,cwd;
  wire [3:0] cm;
  wire [2:0] ec;
  kwt_dma32 dut(
    .clk(clk),.rst_n(rst_n),.job_valid(jv),.job_ready(jr),.job_read(jread),
    .job_addr(ja),.job_words(jw),.busy(busy),.done(done),.error(error),.error_code(ec),
    .rd_valid(rv),.rd_ready(rr),.rd_data(rd),.rd_last(rl),
    .wr_valid(wv),.wr_ready(wr),.wr_data(wd),
    .m_icb_cmd_valid(cv),.m_icb_cmd_ready(cr),.m_icb_cmd_read(cread),
    .m_icb_cmd_addr(ca),.m_icb_cmd_wdata(cwd),.m_icb_cmd_wmask(cm),
    .m_icb_rsp_valid(sv),.m_icb_rsp_ready(sr),.m_icb_rsp_rdata(sd),.m_icb_rsp_err(se));
  integer starts=0,successes=0,failures=0,commands=0,responses=0;
  integer read_beats=0,write_beats=0,fd,n;
  task tick;begin @(negedge clk);#1;end endtask
  always @(posedge clk)if(rst_n)begin
    if(jv&&jr)starts=starts+1;
    if(done)successes=successes+1;
    if(error)failures=failures+1;
    if(cv&&cr)commands=commands+1;
    if(sv&&sr)responses=responses+1;
    if(rv&&rr)read_beats=read_beats+1;
    if(wv&&wr)write_beats=write_beats+1;
    if(done&&error)$fatal(1,"DONE AND ERROR");
    if(busy&&jr)$fatal(1,"BUSY READY");
  end
  task bad_job(input [31:0] base,input [23:0] words,input [2:0] code);
    integer old_errors,old_commands;
    begin
      tick;old_errors=failures;old_commands=commands;
      if(!jr)$fatal(1,"INVALID JOB READY");
      jv=1;ja=base;jw=words;jread=1;
      @(posedge clk);#1;
      if(!error||ec!==code||busy||done)$fatal(1,"INVALID DESCRIPTOR");
      tick;jv=0;repeat(3)tick;
      if(failures!=old_errors+1||commands!=old_commands||error||cv||rv)$fatal(1,"INVALID JOB SIDE EFFECT");
    end
  endtask
  task transfer(input mode,input [31:0] base,input integer words,input integer fault);
    integer i,k,old_done,old_error,old_cmd,old_read,old_write,issued;
    reg [31:0] expected_addr,expected_word,expected_response;
    begin
      tick;old_done=successes;old_error=failures;old_cmd=commands;
      old_read=read_beats;old_write=write_beats;
      if(!jr)$fatal(1,"JOB READY");
      jv=1;jread=mode;ja=base;jw=words;rr=0;wv=0;cr=0;sv=0;
      @(posedge clk);#1;tick;jv=0;
      // Configuration is not allowed to change an accepted descriptor.
      ja=~base;jw=0;jread=~mode;
      issued=(fault<0)?words:fault+1;
      for(i=0;i<issued;i=i+1)begin
        expected_addr=base+4*i;
        expected_word=32'hbb951d3a^expected_addr;
        expected_response=32'ha1378cde^expected_addr;
        if(!mode)begin
          while(!wr)tick;
          repeat(i%4+1)begin
            if(cv||rv||!busy)$fatal(1,"WRITE SOURCE WAIT");
            tick;
          end
          wv=1;wd=expected_word;
          @(posedge clk);#1;tick;wv=0;wd=~expected_word;
        end
        while(!cv)tick;
        for(k=0;k<i%5+1;k=k+1)begin
          if(!cv||ca!==expected_addr||cread!==mode||cm!==4'hf||
             (!mode&&cwd!==expected_word)||!busy||rv)$fatal(1,"DMA COMMAND HOLD");
          tick;
        end
        cr=1;
        if(i%2==0)begin sv=1;sd=expected_response;se=(i==fault);end
        @(posedge clk);#1;tick;cr=0;sv=0;
        if(i%2!=0)begin
          repeat(i%7+1)begin
            if(rv||!busy||cv)$fatal(1,"DMA BUS RESPONSE WAIT");
            tick;
          end
          sv=1;sd=expected_response;se=(i==fault);
          @(posedge clk);#1;tick;sv=0;
        end
        sd=~expected_response;se=0;
        if(i==fault)begin
          // Even when the downstream read consumer is stalled, drain errors.
          if(rv)$fatal(1,"FORWARDED BAD DATA");
          while(!jr)tick;
          if(ec!==3'd4)$fatal(1,"BUS ERROR CODE");
        end else if(mode)begin
          while(!rv)tick;
          repeat(i%6+1)begin
            if(!rv||rd!==expected_response||rl!==(i==words-1)||!busy||cv)
              $fatal(1,"READ STREAM HOLD");
            tick;
          end
          rr=1;@(posedge clk);#1;tick;rr=0;
        end
      end
      while(!jr)tick;
      repeat(3)tick;
      if(commands!=old_cmd+issued||commands!=responses)$fatal(1,"DMA BUS COUNTS");
      if(successes!=old_done+(fault<0)||failures!=old_error+(fault>=0))$fatal(1,"DMA COMPLETION COUNTS");
      if(read_beats!=old_read+(mode?issued-(fault>=0):0))$fatal(1,"READ COUNTS");
      if(write_beats!=old_write+(!mode?issued:0))$fatal(1,"WRITE COUNTS");
      if(cv||rv||done||error||busy||wr)$fatal(1,"DMA TERMINATION");
    end
  endtask
  initial begin
    repeat(4)tick;rst_n=1;tick;
    bad_job(32'h1001,1,1);
    bad_job(32'h1000,0,2);
    bad_job(32'hfffffffc,2,3);
    bad_job(32'hffffff00,24'hffffff,3);
    transfer(1,32'hfffffffc,1,-1);
    transfer(0,32'hfffffffc,1,-1);
    for(n=0;n<96;n=n+1)begin
      // Read and write jobs, varying lengths, first/middle/last-word errors.
      transfer(n%2,32'h80000000+n*4096,n%17+1,
        (n%8==0)?0:(n%8==1)?(n%17/2):(n%8==2)?(n%17):-1);
    end
    if(starts!=102||successes!=62||failures!=40)$fatal(1,"FINAL COUNTS");
    rst_n=0;#1;
    if(jr||cv||rv||done||error||busy)$fatal(1,"DMA RESET");
    tick;rst_n=1;tick;
    if(!jr||ec)$fatal(1,"DMA RESET RECOVERY");
    $display("PASS tb_dma jobs=%0d success=%0d errors=%0d bus_transactions=%0d read_beats=%0d write_beats=%0d",
      starts,successes,failures,commands,read_beats,write_beats);
    $finish;
  end
  initial begin #1000000;$fatal(1,"WATCHDOG");end
endmodule
