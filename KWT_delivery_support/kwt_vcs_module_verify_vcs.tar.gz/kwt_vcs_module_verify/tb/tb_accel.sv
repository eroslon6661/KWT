// Independent accelerator integration, ICB stimulus supplied by TB (no E203).
// +LAYERS=12, when supported, is accelerator autonomous scheduling, not CPU chaining.
`timescale 1ns/1ps
module tb_accel;
  reg clk=0;always #5 clk=~clk;
  reg rst_n=0,cv=0,cread=1,sready=1;
  reg [31:0] ca=0,cwd=0;reg [3:0] cm=15;
  wire cr,sv,se,irq;wire [31:0] sd;
  wire mv,mread,mready;wire [31:0] ma,mwd;wire [3:0] mm;
  reg mrvalid=0,merr=0;reg [31:0] mrd=0;
  wire mrready;
  kwt_accel_icb dut(
    .clk(clk),.rst_n(rst_n),.s_icb_cmd_valid(cv),.s_icb_cmd_ready(cr),
    .s_icb_cmd_addr(ca),.s_icb_cmd_read(cread),.s_icb_cmd_wdata(cwd),.s_icb_cmd_wmask(cm),
    .s_icb_rsp_valid(sv),.s_icb_rsp_ready(sready),.s_icb_rsp_rdata(sd),.s_icb_rsp_err(se),
    .m_icb_cmd_valid(mv),.m_icb_cmd_ready(mready),.m_icb_cmd_addr(ma),
    .m_icb_cmd_read(mread),.m_icb_cmd_wdata(mwd),.m_icb_cmd_wmask(mm),
    .m_icb_rsp_valid(mrvalid),.m_icb_rsp_ready(mrready),.m_icb_rsp_rdata(mrd),.m_icb_rsp_err(merr),.irq(irq));
  integer mem_check;
  reg [31:0] memory[0:262143];
  reg [31:0] golden_ln[0:76031],golden_ff[0:76031];
  reg [31:0] lfsr=32'h7a912345;
  reg pending=0;reg [31:0] saved_result;
  integer delay_count=0,cycles=0,transactions=0,reads=0,writes=0;
  integer layers=1,i,j,k,r,c,idx,off,fd,ln_checks=0,ff_checks=0,layer_starts=0;
  integer weight_beats=0,param_beats=0,stage_count=0,overlap_cycles=0,stalls=0;
  reg [31:0] csr_result;
  string name,status_path;
  assign mready=rst_n&&!pending&&!mrvalid&&(|lfsr[3:0]);
  always @(posedge clk)begin
    if(!rst_n)begin pending<=0;mrvalid<=0;delay_count<=0;end
    else begin
      cycles=cycles+1;
      lfsr<={lfsr[30:0],lfsr[31]^lfsr[21]^lfsr[1]^lfsr[0]};
      if(mv&&!mready)stalls=stalls+1;
      if(mv&&mready)begin
        if(ma<32'h80000000||ma>=32'h80100000||ma[1:0]!=0)$fatal(1,"SYSTEM ADDRESS %h",ma);
        transactions=transactions+1;pending<=1;delay_count<=lfsr[6:4];
        saved_result<=memory[(ma-32'h80000000)>>2];
        if(mread)reads=reads+1;
        else begin
          writes=writes+1;
          if(ma<32'h80004000||ma>=32'h80007180||mm!=15)$fatal(1,"OUTPUT ADDRESS/MASK");
          memory[(ma-32'h80000000)>>2]<=mwd;
        end
      end
      if(pending)begin
        if(delay_count==0)begin mrvalid<=1;mrd<=saved_result;merr<=0;pending<=0;end
        else delay_count<=delay_count-1;
      end
      if(mrvalid&&mrready)mrvalid<=0;
      if(dut.error)$fatal(1,"RUN ERROR %h",dut.error_code);
      if(dut.ls&&dut.lr)layer_starts=layer_starts+1;
      if(dut.wl)weight_beats=weight_beats+1;
      if(dut.pl)param_beats=param_beats+1;
      if(dut.u_run.dbusy&&dut.cbusy)overlap_cycles=overlap_cycles+1;
      if(dut.ae+{1'b0,dut.be}+{1'b0,dut.ve}>1)$fatal(1,"ACT READ COLLISION");
      if((dut.ae||dut.be||dut.ve)&&(dut.ce||dut.xe||dut.de))$fatal(1,"ACT RW COLLISION");
      if(dut.we&&dut.wa<20'h18000&&dut.wl&&dut.active_bank==dut.wb)$fatal(1,"LIVE WEIGHT OVERWRITE");
      if(dut.pl&&(dut.pe||(dut.we&&dut.wa>=20'h18000)))$fatal(1,"PARAM COLLISION");
      if(dut.ae&&(dut.aa>=18'h20000||dut.aa[2:0]!=0))$fatal(1,"A ADDR");
      if(dut.be&&(dut.ba>=18'h20000||dut.ba[2:0]!=0))$fatal(1,"B ADDR");
      if(dut.ve&&(dut.va>=18'h20000||dut.va[5:0]!=0))$fatal(1,"V ADDR");
      if(dut.ce&&dut.cr)begin
        if(dut.ca>=18'h20000||dut.ca[4:0]!=0)$fatal(1,"C ADDR");
        if(dut.stage==15)for(j=0;j<8;j=j+1)if(dut.cs[j*4+:4]==15)begin
          idx=dut.layer*6336+((dut.ca-18'h12000)>>2)+j;
          if(dut.cd[j*32+:32]!==golden_ff[idx])$fatal(1,"FFN2 layer=%0d index=%0d actual=%h ref=%h",dut.layer,idx,dut.cd[j*32+:32],golden_ff[idx]);
          ff_checks=ff_checks+1;
        end
      end
      if(dut.xe&&dut.xr)begin
        if(dut.xa>=18'h20000||dut.xa[5:0]!=0)$fatal(1,"V WRITE ADDR");
        if(dut.stage==16)for(j=0;j<32;j=j+1)if(dut.xs[j*2+:2]==3)begin
          idx=dut.layer*6336+(dut.xa>>1)+j;
          if(dut.xd[j*16+:16]!==golden_ln[idx][15:0])$fatal(1,"LN2 layer=%0d index=%0d actual=%h ref=%h",dut.layer,idx,dut.xd[j*16+:16],golden_ln[idx]);
          ln_checks=ln_checks+1;
        end
      end
      if(dut.stage_done)begin
        stage_count=stage_count+1;
        if(dut.stage==16)$display("LAYER %0d VERIFIED cycles=%0d",dut.layer+1,cycles);
      end
    end
  end
  task csr(input bit read,input [31:0] address,input [31:0] data);
    begin
      @(negedge clk);cv=1;cread=read;ca=address;cwd=data;
      do @(posedge clk);while(!cr);
      @(negedge clk);cv=0;
      while(!sv)@(negedge clk);
      if(se)$fatal(1,"CSR ERROR addr=%h",address);
      csr_result=sd;
      @(posedge clk);@(negedge clk);
    end
  endtask
  initial begin
    if(!$value$plusargs("LAYERS=%d",layers))layers=1;
    if(layers!=1&&layers!=12)$fatal(1,"LAYERS");
    status_path=$sformatf("results/status_%0d.txt",layers);
    fd=$fopen(status_path,"w");if(fd==0)$fatal(1,"Cannot write status file");$fdisplay(fd,"INCOMPLETE");$fclose(fd);
    $readmemh("vectors/integration/system.hex",memory);
    for(mem_check=0;mem_check<262144;mem_check=mem_check+1)
      if((^memory[mem_check])===1'bx)$fatal(1,"MISSING/X MEMORY INPUT %0d",mem_check);
    for(i=0;i<layers;i=i+1)begin
      if(i<9)name=$sformatf("vectors/integration/golden/layer_0%0d_ln2.hex",i+1);
      else name=$sformatf("vectors/integration/golden/layer_%0d_ln2.hex",i+1);
      $readmemh(name,golden_ln,6336*i,6336*(i+1)-1);
      if(i<9)name=$sformatf("vectors/integration/golden/layer_0%0d_ffn2.hex",i+1);
      else name=$sformatf("vectors/integration/golden/layer_%0d_ffn2.hex",i+1);
      $readmemh(name,golden_ff,6336*i,6336*(i+1)-1);
    end
    for(i=0;i<6336*layers;i=i+1)
      if((^golden_ln[i])===1'bx || (^golden_ff[i])===1'bx)
        $fatal(1,"MISSING/X GOLDEN OUTPUT %0d",i);
    repeat(5)@(negedge clk);rst_n=1;
    csr(0,'h10,32'h80000000);csr(0,'h14,32'h80004000);
    csr(0,'h18,32'h80010000);csr(0,'h1c,32'hd000);csr(0,'h20,layers);
    csr(0,'hc,1);csr(0,'h4,1);
    wait(irq);repeat(3)@(negedge clk);
    csr(1,'h8,0);if(csr_result!==2)$fatal(1,"FINAL STATUS %h",csr_result);
    if(layer_starts!=layers||stage_count!=17*layers||weight_beats!=12288*layers||param_beats!=898*layers||
      ln_checks!=6336*layers||ff_checks!=6336*layers||writes!=3168||reads!=3168+13194*layers)$fatal(1,"FINAL COUNTS starts=%0d stages=%0d weights=%0d params=%0d writes=%0d reads=%0d",layer_starts,stage_count,weight_beats,param_beats,writes,reads);
    for(i=0;i<3168;i=i+1)
      if(memory['h1000+i]!=={golden_ln[(layers-1)*6336+2*i+1][15:0],golden_ln[(layers-1)*6336+2*i][15:0]})$fatal(1,"SYSTEM OUTPUT %0d",i);
    fd=$fopen(status_path,"w");if(fd==0)$fatal(1,"Cannot write status file");$fdisplay(fd,"PASS");$fclose(fd);
    $display("PASS tb_accel layers=%0d cycles=%0d transactions=%0d stalls=%0d prefetch_overlap_cycles=%0d",layers,cycles,transactions,stalls,overlap_cycles);
    $finish;
  end
  initial begin #300000000;$fatal(1,"WATCHDOG");end
endmodule
