`timescale 1ns/1ps
`include "kwt1_defs.vh"
// Exact signed half-integer GEMM against an integer dot-product oracle.
module tb_matrix;
  reg clk=0,rst_n=0,job_valid=0,c_wr_ready=0;
  always #5 clk=~clk;
  reg [255:0] job=0;
  wire job_ready,job_done,job_error,a_rd_en,b_act_rd_en,wgt_rd_en,c_wr_en;
  wire [17:0] a_rd_addr,b_act_rd_addr,c_wr_addr;
  wire [19:0] wgt_rd_addr;
  reg [63:0] a_rd_data=0,b_act_rd_data=0,wgt_rd_data=0;
  wire [255:0] c_wr_data;
  wire [31:0] c_wr_strb;
  matrix_array_8x8 dut(clk,rst_n,job_valid,job_ready,job_done,job_error,job,
    a_rd_en,a_rd_addr,a_rd_data,b_act_rd_en,b_act_rd_addr,b_act_rd_data,
    wgt_rd_en,wgt_rd_addr,wgt_rd_data,c_wr_en,c_wr_addr,c_wr_data,c_wr_strb,c_wr_ready);
  localparam A_BASE=0,B_BASE=4096,BIAS_BASE=12288,C_BASE=32768,MEM_SIZE=65536;
  reg [7:0] act_mem[0:MEM_SIZE-1],wgt_mem[0:MEM_SIZE-1];
  reg seen[0:1023];
  reg [31:0] golden[0:1023];
  integer test_m=0,test_n=0,test_cs=0,cycles=0,checked=0,case_checked=0,cases=0,stalls=0;
  integer lane,rel,row,col,index,read_lane;
  reg checking=0,stalled=0;
  reg [17:0] held_addr;
  reg [255:0] held_data;
  reg [31:0] held_strb,wanted_strb;
  function automatic integer aval(input integer m,k);
    aval=((m+3*k)%9)-4;
  endfunction
  function automatic integer bval(input integer k,n);
    bval=((2*k+n)%7)-3;
  endfunction
  function automatic [15:0] half_integer(input integer q);
    integer mag,top,k;
    reg [4:0] e;
    reg [9:0] f;
    begin
      mag=q<0?-q:q;top=0;
      for(k=0;k<10;k=k+1)if(mag>=(1<<k))top=k;
      e=14+top;f=(mag-(1<<top))<<(10-top);
      half_integer=(mag==0)?16'd0:{(q<0),e,f}; // q/2
    end
  endfunction
  function automatic [31:0] quarter_float(input integer q);
    integer mag,top,k;
    reg [7:0] e;
    reg [22:0] f;
    begin
      mag=q<0?-q:q;top=0;
      for(k=0;k<23;k=k+1)if(mag>=(1<<k))top=k;
      e=125+top;f=(mag-(1<<top))<<(23-top);
      quarter_float=(mag==0)?32'd0:{(q<0),e,f}; // q/4
    end
  endfunction
  task automatic put_half(input bit weights,input integer address,input [15:0] value);
    begin
      if(weights)begin wgt_mem[address]=value[7:0];wgt_mem[address+1]=value[15:8];end
      else begin act_mem[address]=value[7:0];act_mem[address+1]=value[15:8];end
    end
  endtask
  task automatic put_bias(input integer address,input [31:0] value);
    integer j;
    begin for(j=0;j<4;j=j+1)wgt_mem[address+j]=value[8*j+:8];end
  endtask
  // One-cycle synchronous memories. B can come from either memory address space.
  always @(posedge clk)begin
    if(rst_n)begin
      if(a_rd_en)begin
        if((^a_rd_addr)===1'bx || a_rd_addr+7>=MEM_SIZE || a_rd_addr[2:0]!=0)$fatal(1,"A address");
        for(read_lane=0;read_lane<8;read_lane=read_lane+1)a_rd_data[8*read_lane+:8]<=act_mem[a_rd_addr+read_lane];
      end
      if(b_act_rd_en)begin
        if((^b_act_rd_addr)===1'bx || b_act_rd_addr+7>=MEM_SIZE || b_act_rd_addr[2:0]!=0)$fatal(1,"B activation address");
        for(read_lane=0;read_lane<8;read_lane=read_lane+1)b_act_rd_data[8*read_lane+:8]<=act_mem[b_act_rd_addr+read_lane];
      end
      if(wgt_rd_en)begin
        if((^wgt_rd_addr)===1'bx || wgt_rd_addr+7>=MEM_SIZE || wgt_rd_addr[2:0]!=0)$fatal(1,"Weight address");
        for(read_lane=0;read_lane<8;read_lane=read_lane+1)wgt_rd_data[8*read_lane+:8]<=wgt_mem[wgt_rd_addr+read_lane];
      end
      if(stalled && (c_wr_en!==1 || c_wr_addr!==held_addr || c_wr_data!==held_data || c_wr_strb!==held_strb))
        $fatal(1,"Output changed under backpressure");
      stalled=c_wr_en&&!c_wr_ready;
      if(stalled)begin held_addr=c_wr_addr;held_data=c_wr_data;held_strb=c_wr_strb;stalls=stalls+1;end
      if(c_wr_en&&c_wr_ready)begin
        if(!checking)$fatal(1,"Unexpected write outside accepted legal job");
        if((^c_wr_addr)===1'bx || (^c_wr_data)===1'bx || (^c_wr_strb)===1'bx)$fatal(1,"Unknown write");
        rel=c_wr_addr-C_BASE;
        if(rel<0 || rel>=test_m*test_cs || rel%32!=0)$fatal(1,"Output bounds/alignment");
        row=rel/test_cs;col=(rel%test_cs)/4;wanted_strb=0;
        if(col>=test_n)$fatal(1,"Output column bounds");
        for(lane=0;lane<8;lane=lane+1)begin
          if(col+lane<test_n)begin
            wanted_strb[4*lane+:4]=4'hf;index=row*test_n+col+lane;
            if(seen[index])$fatal(1,"Duplicate output index=%0d",index);
            if(c_wr_data[32*lane+:32]!==golden[index])
              $fatal(1,"GEMM case=%0d row=%0d col=%0d got=%h want=%h",cases,row,col+lane,c_wr_data[32*lane+:32],golden[index]);
            seen[index]=1;case_checked=case_checked+1;checked=checked+1;
          end else if(c_wr_data[32*lane+:32]!==0)$fatal(1,"Nonzero inactive output lane");
        end
        if(c_wr_strb!==wanted_strb)$fatal(1,"Output strobes got=%h want=%h",c_wr_strb,wanted_strb);
      end
    end else stalled=0;
  end
  always @(negedge clk)begin
    if(!rst_n)begin cycles=0;c_wr_ready=0;end
    else begin cycles=cycles+1;c_wr_ready=((cycles%7)>=3);end
  end
  task automatic submit(input bit expect_error);
    integer timeout_cycles;
    begin
      @(negedge clk);
      if(job_ready!==1)$fatal(1,"Job interface not ready");
      job_valid=1;
      @(negedge clk);job_valid=0;
      // Once accepted, changing the upstream job must not alter execution.
      job=0;
      timeout_cycles=0;
      while(job_done!==1 && timeout_cycles<100000)begin @(negedge clk);timeout_cycles=timeout_cycles+1;end
      if(job_done!==1)$fatal(1,"Matrix job timeout");
      if(job_error!==expect_error)$fatal(1,"Job error got=%b expected=%b",job_error,expect_error);
      @(negedge clk);
      if(job_done!==0 || job_ready!==1)$fatal(1,"Job completion/recovery handshake");
    end
  endtask
  task automatic run_case(input integer m,k,n,input bit trans,b_from_act,bias);
    integer i,j,t,as_bytes,bs_bytes,cs_bytes,address,dot;
    begin
      cases=cases+1;test_m=m;test_n=n;case_checked=0;
      as_bytes=((2*k+7)/8)*8;
      bs_bytes=((2*(trans?k:n)+7)/8)*8;
      cs_bytes=((4*n+31)/32)*32;test_cs=cs_bytes;
      for(i=0;i<MEM_SIZE;i=i+1)begin act_mem[i]=0;wgt_mem[i]=0;end
      for(i=0;i<1024;i=i+1)seen[i]=0;
      for(i=0;i<m;i=i+1)for(t=0;t<k;t=t+1)put_half(0,A_BASE+i*as_bytes+2*t,half_integer(aval(i,t)));
      for(t=0;t<k;t=t+1)for(j=0;j<n;j=j+1)begin
        address=B_BASE+(trans?j*bs_bytes+2*t:t*bs_bytes+2*j);
        put_half(!b_from_act,address,half_integer(bval(t,j)));
      end
      for(j=0;j<n;j=j+1)put_bias(BIAS_BASE+4*j,quarter_float(j%5-2));
      for(i=0;i<m;i=i+1)for(j=0;j<n;j=j+1)begin
        dot=bias?(j%5-2):0;
        for(t=0;t<k;t=t+1)dot=dot+aval(i,t)*bval(t,j);
        golden[i*n+j]=quarter_float(dot);
      end
      job=0;job[187:186]=`FMT_FP16;job[185:184]=`FMT_FP16;
      job[183]=b_from_act;job[182]=trans;job[180]=bias;
      job[171:156]=m;job[155:140]=n;job[139:124]=k;
      job[123:108]=as_bytes;job[107:92]=bs_bytes;job[91:76]=cs_bytes;
      job[75:58]=A_BASE;job[57:38]=B_BASE;job[37:18]=BIAS_BASE;job[17:0]=C_BASE;
      checking=1;submit(0);checking=0;
      if(case_checked!=m*n)$fatal(1,"Missing outputs got=%0d want=%0d",case_checked,m*n);
      $display("MATRIX_CASE_PASS M=%0d K=%0d N=%0d transpose=%0d activation_B=%0d bias=%0d",m,k,n,trans,b_from_act,bias);
    end
  endtask
  initial begin #3000000;$fatal(1,"tb_matrix watchdog");end
  initial begin
    repeat(4)@(negedge clk);rst_n=1;
    run_case(2,3,4,0,0,0);
    run_case(33,9,11,0,0,1); // Cross M32/N8/K8 boundaries and all tails.
    run_case(3,7,10,1,1,1);
    // Rejected jobs must not issue memory writes and must recover to idle.
    job=0;submit(1);
    job=0;job[187:186]=`FMT_FP16;job[185:184]=`FMT_FP16;
    job[171:156]=1;job[155:140]=1;job[139:124]=1;
    job[123:108]=8;job[107:92]=8;job[91:76]=32;
    job[75:58]=1;job[17:0]=C_BASE;submit(1); // misaligned A
    run_case(1,1,1,0,0,0);
    if(stalls==0)$fatal(1,"Backpressure coverage absent");
    $display("PASS tb_matrix cases=%0d outputs=%0d stall_cycles=%0d rejected_jobs=2",cases,checked,stalls);
    $finish;
  end
endmodule
