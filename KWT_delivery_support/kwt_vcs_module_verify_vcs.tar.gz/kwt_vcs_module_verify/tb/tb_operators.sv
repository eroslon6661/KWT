`timescale 1ns/1ps
// Independent bit-pattern/exact-rational tests. No DUT function is a golden model.
module tb_operators;
  reg clk=0, rst_n=0;
  always #5 clk=~clk;
  reg [15:0] half_in=0;
  wire [31:0] single_out;
  reg [31:0] single_in=0, a=0, b=0;
  wire [15:0] half_out;
  wire [31:0] sum,product;
  wire gt;
  kwt_vpu_h2f u_h2f(half_in,single_out);
  kwt_vpu_f2h u_f2h(single_in,half_out);
  kwt_vpu_mul u_mul(a,b,product);
  kwt_pe_fp32_add u_add(a,b,sum);
  kwt_vpu_gt u_gt(a,b,gt);
  reg start=0;
  reg [1:0] op=0;
  reg [31:0] x=0;
  wire busy,done;
  wire [31:0] y;
  kwt_vpu_sfu u_sfu(clk,rst_n,start,op,x,busy,done,y);
  integer checks=0, sfu_checks=0, i, qa,qb;
  reg [31:0] expected;
  reg [15:0] expected_half;

  // IEEE binary16 decode by exponent/significand normalization.
  function automatic [31:0] half_reference(input [15:0] h);
    integer e,m,shift;
    reg [7:0] ef;
    reg [22:0] frac;
    begin
      e=h[14:10]; m=h[9:0]; shift=0;
      if(e==31) half_reference={h[15],8'hff,h[9:0],13'b0};
      else if(e==0 && m==0) half_reference={h[15],31'd0};
      else begin
        if(e==0) begin
          while(m<1024) begin m=m*2; shift=shift+1; end
          ef=113-shift;
        end else ef=e+112;
        frac=(m%1024)*8192;
        half_reference={h[15],ef,frac};
      end
    end
  endfunction

  // Exactly represent q * 2**(-fraction_bits); all caller magnitudes < 2**23.
  function automatic [31:0] exact_float(input integer q,input integer fraction_bits);
    integer mag,k,top;
    reg [7:0] e;
    reg [22:0] f;
    begin
      mag=(q<0)?-q:q; top=0;
      for(k=0;k<23;k=k+1) if(mag>=(1<<k)) top=k;
      e=127+top-fraction_bits; f=(mag-(1<<top))<<(23-top);
      exact_float=(mag==0)?32'd0:{(q<0),e,f};
    end
  endfunction
  function automatic real decode_float(input [31:0] value);
    real m;
    begin
      if(value[30:23]==0) m=value[22:0]*(2.0**(-149));
      else m=(1.0+value[22:0]/8388608.0)*(2.0**(integer'(value[30:23])-127));
      decode_float=value[31]?-m:m;
    end
  endfunction
  task automatic check_f2h(input [31:0] value,input [15:0] want);
    begin
      single_in=value; #1;
      if(half_out!==want) $fatal(1,"F2H f=%h got=%h want=%h",value,half_out,want);
      checks=checks+1;
    end
  endtask
  task automatic check_binary(input [31:0] av,bv,add_want,mul_want);
    begin
      a=av;b=bv;#1;
      if(sum!==add_want || product!==mul_want)
        $fatal(1,"BINARY a=%h b=%h add=%h/%h mul=%h/%h",a,b,sum,add_want,product,mul_want);
      checks=checks+2;
    end
  endtask
  task automatic check_sfu(input [1:0] opcode,input [31:0] arg,input real want,input bit expect_nan);
    integer wait_cycles;
    real actual,err,tol;
    begin
      @(negedge clk);
      if(busy!==0 || done!==0) $fatal(1,"SFU not idle before request");
      op=opcode;x=arg;start=1;
      @(posedge clk);#1;
      @(negedge clk);start=0;
      wait_cycles=0;
      while(done!==1 && wait_cycles<150) begin
        // Change the command after acceptance: the running operation must be latched.
        op=~opcode;x=32'hdeadbeef;
        @(posedge clk);#1;wait_cycles=wait_cycles+1;
        @(negedge clk);
      end
      if(done!==1) $fatal(1,"SFU timeout op=%0d x=%h",opcode,arg);
      if(expect_nan) begin
        if(y!==32'h7fc00000) $fatal(1,"SFU domain response op=%0d x=%h y=%h",opcode,arg,y);
      end else begin
        if((^y)===1'bx || y[30:23]==255) $fatal(1,"SFU nonfinite result %h",y);
        actual=decode_float(y); err=actual-want;if(err<0)err=-err;
        tol=0.000002+((want<0)?-want:want)*0.00002;
        if(err>tol) $fatal(1,"SFU op=%0d x=%h actual=%e expected=%e error=%e tolerance=%e",opcode,arg,actual,want,err,tol);
      end
      @(posedge clk);#1;
      if(done!==0 || busy!==0) $fatal(1,"SFU done is not a one-cycle pulse");
      sfu_checks=sfu_checks+1;
    end
  endtask
  initial begin
    #2000000;$fatal(1,"tb_operators watchdog");
  end
  initial begin
    repeat(3) @(negedge clk);rst_n=1;
    for(i=0;i<65536;i=i+1) begin
      half_in=i[15:0]; expected=half_reference(i[15:0]);#1;
      if(single_out!==expected) $fatal(1,"H2F h=%h got=%h want=%h",half_in,single_out,expected);
      single_in=expected;#1;
      expected_half=(i[14:10]==31 && i[9:0]!=0)?{i[15],5'h1f,10'h200}:i[15:0];
      if(half_out!==expected_half) $fatal(1,"F2H roundtrip h=%h got=%h want=%h",half_in,half_out,expected_half);
      checks=checks+2;
    end
    // Round-to-nearest-even around 1.0, denormal boundary, overflow, signed zero.
    check_f2h(32'h3f801000,16'h3c00);
    check_f2h(32'h3f801001,16'h3c01);
    check_f2h(32'h3f803000,16'h3c02);
    check_f2h(32'h33000000,16'h0000);
    check_f2h(32'h33000001,16'h0001);
    check_f2h(32'h33800000,16'h0001);
    check_f2h(32'h387fe000,16'h0400);
    check_f2h(32'h477fe000,16'h7bff);
    check_f2h(32'h477ff000,16'h7c00);
    check_f2h(32'h80000001,16'h8000);
    for(i=0;i<2048;i=i+1) begin
      qa=(i*37)%129-64; qb=(i*71+11)%129-64;
      a=exact_float(qa,3); b=exact_float(qb,3);#1;
      expected=exact_float(qa+qb,3);
      if(sum!==expected) $fatal(1,"ADD exact rational %h + %h = %h expected %h",a,b,sum,expected);
      expected=exact_float(qa*qb,6);
      // Zero products retain XOR sign in this implementation.
      if(qa*qb==0) expected[31]=a[31]^b[31];
      if(product!==expected) $fatal(1,"MUL exact rational %h * %h = %h expected %h",a,b,product,expected);
      if(gt!==(qa>qb)) $fatal(1,"GT finite compare");
      checks=checks+3;
    end
    check_binary(32'h7f800000,32'hff800000,32'h7fc00000,32'hff800000);
    check_binary(32'h00000000,32'h7f800000,32'h7f800000,32'h7fc00000);
    check_binary(32'h7fc12345,32'h3f800000,32'h7fc00000,32'h7fc00000);
    check_binary(32'h80000000,32'h80000000,32'h80000000,32'h00000000);
    // Explicitly characterize multiplier DAZ (subnormal input treated as zero).
    check_binary(32'h00000001,32'h3f800000,32'h3f800000,32'h00000000);
    check_binary(32'h3f800000,32'h33800000,32'h3f800000,32'h33800000);
    check_binary(32'h3f800001,32'h33800000,32'h3f800002,32'h33800001);
    a=32'h80000000;b=0;#1;if(gt!==0)$fatal(1,"GT signed zero");
    check_sfu(0,32'h00000000,1.0,0);
    check_sfu(0,32'hbf800000,$exp(-1.0),0);
    check_sfu(0,32'hc1200000,$exp(-10.0),0);
    check_sfu(0,32'hc2c80000,0.0,0);
    check_sfu(0,32'h3f800000,0.0,1);
    check_sfu(1,32'h00000000,0.0,0);
    check_sfu(1,32'h3f800000,($exp(2.0)-1.0)/($exp(2.0)+1.0),0);
    check_sfu(1,32'hbf800000,-($exp(2.0)-1.0)/($exp(2.0)+1.0),0);
    check_sfu(1,32'h41200000,1.0,0);
    check_sfu(1,32'hc1200000,-1.0,0);
    check_sfu(2,32'h40000000,0.5,0);
    check_sfu(2,32'h3e800000,4.0,0);
    check_sfu(2,32'h00000000,0.0,1);
    check_sfu(3,32'h40800000,0.5,0);
    check_sfu(3,32'h3e800000,2.0,0);
    check_sfu(3,32'hbf800000,0.0,1);
    // Reset aborts an in-flight multi-cycle operation.
    @(negedge clk);op=3;x=32'h40400000;start=1;
    @(negedge clk);start=0;
    repeat(2)@(negedge clk);rst_n=0;#1;
    if(busy!==0 || done!==0 || y!==0)$fatal(1,"SFU reset abort");
    @(negedge clk);rst_n=1;
    check_sfu(2,32'h40800000,0.25,0);
    $display("PASS tb_operators exact_checks=%0d sfu_checks=%0d",checks,sfu_checks);
    $finish;
  end
endmodule
