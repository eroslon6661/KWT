`timescale 1ns/1ps
module tb_icb_master;
  reg clk=0;always #5 clk=~clk;
  reg rst_n=0;
  reg rv=0,rrd=1,pr=0,mcr=0,mrv=0,mre=0;
  reg [31:0] ra=0,rwd=0,mrd=0;
  reg [3:0] rwm=0;
  wire rr,pv,pe,mcv,mcread,mrr;
  wire [31:0] pd,mca,mcwd;
  wire [3:0] mcwm;
  kwt_icb_master32 master(
    .clk(clk),.rst_n(rst_n),.req_valid(rv),.req_ready(rr),.req_read(rrd),
    .req_addr(ra),.req_wdata(rwd),.req_wmask(rwm),.rsp_valid(pv),.rsp_ready(pr),.rsp_rdata(pd),.rsp_err(pe),
    .m_icb_cmd_valid(mcv),.m_icb_cmd_ready(mcr),.m_icb_cmd_read(mcread),
    .m_icb_cmd_addr(mca),.m_icb_cmd_wdata(mcwd),.m_icb_cmd_wmask(mcwm),
    .m_icb_rsp_valid(mrv),.m_icb_rsp_ready(mrr),.m_icb_rsp_rdata(mrd),.m_icb_rsp_err(mre));
  integer master_req=0,master_cmd=0,master_bus_rsp=0,master_rsp=0;
  integer n,j;
  reg [31:0] random_state=32'hd21a9743;
  reg [31:0] expected_addr,expected_data,expected_result;
  reg [3:0] expected_mask;
  reg expected_read,expected_error;
  task tick;begin @(negedge clk);#1;end endtask
  always @(posedge clk)if(rst_n)begin
    if(rv&&rr)master_req=master_req+1;
    if(mcv&&mcr)master_cmd=master_cmd+1;
    if(mrv&&mrr)master_bus_rsp=master_bus_rsp+1;
    if(pv&&pr)master_rsp=master_rsp+1;
  end
  initial begin
    repeat(4)tick;rst_n=1;tick;
    for(n=0;n<512;n=n+1)begin
      random_state={random_state[30:0],random_state[31]^random_state[21]^random_state[1]^random_state[0]};
      expected_addr={random_state[31:2],2'b00};expected_data=random_state^32'hb8f29147;
      expected_mask=n%16;expected_read=n%2;expected_error=(n%13==0);
      expected_result=expected_addr^32'h5a5a37c9;
      rv=1;rrd=expected_read;ra=expected_addr;rwd=expected_data;rwm=expected_mask;
      mcr=0;mrv=0;pr=0;
      if(!rr)$fatal(1,"MASTER REQUEST READY");
      @(posedge clk);#1;tick;rv=0;
      // Change upstream payload after acceptance to catch missing latches.
      ra=~expected_addr;rwd=~expected_data;rrd=~expected_read;rwm=~expected_mask;
      for(j=0;j<n%5+1;j=j+1)begin
        if(!mcv||mca!==expected_addr||mcwd!==expected_data||mcwm!==expected_mask||mcread!==expected_read||rr)
          $fatal(1,"MASTER COMMAND HOLD txn=%0d",n);
        tick;
      end
      mcr=1;
      if(n%3==0)begin mrv=1;mrd=expected_result;mre=expected_error;end
      @(posedge clk);#1;tick;mcr=0;mrv=0;
      if(n%3!=0)begin
        for(j=0;j<n%7;j=j+1)begin
          if(mcv||pv||!mrr)$fatal(1,"MASTER WAIT RESPONSE");
          tick;
        end
        mrv=1;mrd=expected_result;mre=expected_error;
        @(posedge clk);#1;tick;mrv=0;
      end
      for(j=0;j<n%6+1;j=j+1)begin
        mrd=~expected_result;mre=~expected_error;
        if(!pv||pd!==expected_result||pe!==expected_error||rr||mcv||mrr)$fatal(1,"MASTER RESPONSE HOLD txn=%0d",n);
        tick;
      end
      pr=1;@(posedge clk);#1;tick;pr=0;
      if(!rr||pv||mcv||mrr)$fatal(1,"MASTER RETURN IDLE");
    end
    if(master_req!=512||master_cmd!=512||master_bus_rsp!=512||master_rsp!=512)$fatal(1,"MASTER COUNTS");

    rst_n=0;#1;
    if(pv!==0||mcv!==0||rr!==0||mrr!==0)$fatal(1,"MASTER RESET");
    tick;rst_n=1;tick;
    if(rr!==1||pv!==0)$fatal(1,"MASTER RESET RECOVERY");
    $display("PASS tb_icb_master transactions=%0d zero_latency=171 delayed=341",master_req);
    $finish;
  end
  initial begin #1000000;$fatal(1,"MASTER TIMEOUT");end
endmodule
