`timescale 1ns/1ps
module tb_arbiter;
reg clk=0;always #5 clk=~clk;reg rst_n=0;
wire u_cmd_valid;
wire u_cmd_ready;
wire [31:0] u_cmd_addr;
wire u_cmd_read;
wire [31:0] u_cmd_wdata;
wire [3:0] u_cmd_wmask;
wire u_rsp_valid;
wire u_rsp_ready;
wire [31:0] u_rsp_rdata;
wire u_rsp_err;
wire d_cmd_valid;
wire d_cmd_ready;
wire [31:0] d_cmd_addr;
wire d_cmd_read;
wire [31:0] d_cmd_wdata;
wire [3:0] d_cmd_wmask;
wire d_rsp_valid;
wire d_rsp_ready;
wire [31:0] d_rsp_rdata;
wire d_rsp_err;
wire s_cmd_valid;
wire s_cmd_ready;
wire [31:0] s_cmd_addr;
wire s_cmd_read;
wire [31:0] s_cmd_wdata;
wire [3:0] s_cmd_wmask;
wire s_rsp_valid;
wire s_rsp_ready;
wire [31:0] s_rsp_rdata;
wire s_rsp_err;
kwt_icb_arb2 dut(.clk(clk),.rst_n(rst_n),
.u_cmd_valid(u_cmd_valid),
.u_cmd_ready(u_cmd_ready),
.u_cmd_addr(u_cmd_addr),
.u_cmd_read(u_cmd_read),
.u_cmd_wdata(u_cmd_wdata),
.u_cmd_wmask(u_cmd_wmask),
.u_rsp_valid(u_rsp_valid),
.u_rsp_ready(u_rsp_ready),
.u_rsp_rdata(u_rsp_rdata),
.u_rsp_err(u_rsp_err),
.d_cmd_valid(d_cmd_valid),
.d_cmd_ready(d_cmd_ready),
.d_cmd_addr(d_cmd_addr),
.d_cmd_read(d_cmd_read),
.d_cmd_wdata(d_cmd_wdata),
.d_cmd_wmask(d_cmd_wmask),
.d_rsp_valid(d_rsp_valid),
.d_rsp_ready(d_rsp_ready),
.d_rsp_rdata(d_rsp_rdata),
.d_rsp_err(d_rsp_err),
.s_cmd_valid(s_cmd_valid),
.s_cmd_ready(s_cmd_ready),
.s_cmd_addr(s_cmd_addr),
.s_cmd_read(s_cmd_read),
.s_cmd_wdata(s_cmd_wdata),
.s_cmd_wmask(s_cmd_wmask),
.s_rsp_valid(s_rsp_valid),
.s_rsp_ready(s_rsp_ready),
.s_rsp_rdata(s_rsp_rdata),
.s_rsp_err(s_rsp_err));

reg [31:0] usent=0,dsent=0,uret=0,dret=0;
reg up=0,dp=0,pending=0;
reg [31:0] saved_tag=0;reg saved_error=0;
integer cycle=0,errors=0,rsp_stalls=0,ties=0,fd;
reg held=0,last_grant=0,have_grant=0;reg [68:0] held_payload;
assign u_cmd_valid=rst_n&&(cycle>=8)&&(usent<64)&&!up;
assign d_cmd_valid=rst_n&&(dsent<64)&&!dp;
assign u_cmd_addr=32'h30010000+(usent<<2);
assign d_cmd_addr=32'h30020000+(dsent<<2);
assign u_cmd_wdata=32'h12340000^usent;
assign d_cmd_wdata=32'habcd0000^dsent;
assign u_cmd_read=usent[0];assign d_cmd_read=dsent[0];
assign u_cmd_wmask=4'b0001<<usent[1:0];
assign d_cmd_wmask=4'b0001<<dsent[1:0];
assign u_rsp_ready=cycle[1:0]!=0;assign d_rsp_ready=cycle[2:0]>=3;
assign s_cmd_ready=rst_n&&(cycle>=20)&&(cycle%5!=0)&&!pending;
// Target may offer an immediate response and retains it until accepted.
wire fire=s_cmd_valid&&s_cmd_ready;
wire [31:0] tag=s_cmd_addr^s_cmd_wdata^{27'd0,s_cmd_read,s_cmd_wmask};
assign s_rsp_valid=pending||fire;
assign s_rsp_rdata=pending?saved_tag:tag;
assign s_rsp_err=pending?saved_error:s_cmd_addr[5];
wire [31:0] eu=(32'h30010000+(uret<<2))^(32'h12340000^uret)^((uret[0]<<4)|(32'd1<<uret[1:0]));
wire [31:0] ed=(32'h30020000+(dret<<2))^(32'habcd0000^dret)^((dret[0]<<4)|(32'd1<<dret[1:0]));
always @(posedge clk)begin
  if(!rst_n)begin cycle<=0;pending<=0;held<=0;end
  else begin
    cycle<=cycle+1;
    if(held&&(!s_cmd_valid||{s_cmd_addr,s_cmd_wdata,s_cmd_read,s_cmd_wmask}!==held_payload))$fatal(1,"GRANT CHANGED UNDER STALL");
    held<=s_cmd_valid&&!s_cmd_ready;
    held_payload<={s_cmd_addr,s_cmd_wdata,s_cmd_read,s_cmd_wmask};
    if(fire)begin
      if(u_cmd_valid&&d_cmd_valid&&have_grant)begin
        ties<=ties+1;
        if(dut.selected==last_grant)$fatal(1,"ROUND ROBIN FAIRNESS");
      end
      last_grant<=dut.selected;have_grant<=1;
      pending<=!s_rsp_ready;saved_tag<=tag;saved_error<=s_cmd_addr[5];
    end else if(s_rsp_valid&&s_rsp_ready)pending<=0;
    if(s_rsp_valid&&!s_rsp_ready)rsp_stalls<=rsp_stalls+1;
    if(u_cmd_valid&&u_cmd_ready)begin usent<=usent+1;up<=1;end
    if(d_cmd_valid&&d_cmd_ready)begin dsent<=dsent+1;dp<=1;end
    if(u_rsp_valid&&u_rsp_ready)begin
      if(!up||u_rsp_rdata!==eu||u_rsp_err!==uret[3])$fatal(1,"CPU RESPONSE ROUTING");
      uret<=uret+1;up<=0;
    end
    if(d_rsp_valid&&d_rsp_ready)begin
      if(!dp||d_rsp_rdata!==ed||d_rsp_err!==dret[3])$fatal(1,"DMA RESPONSE ROUTING");
      dret<=dret+1;dp<=0;
    end
    if(s_rsp_valid&&s_rsp_ready&&s_rsp_err)errors<=errors+1;
  end
end
initial begin
  repeat(5)@(negedge clk);rst_n=1;
  wait(uret==64&&dret==64);@(negedge clk);
  if(errors!=64||rsp_stalls==0||ties<60||pending)$fatal(1,"COVERAGE COUNTS");
  $display("PASS tb_arbiter transactions=128 routed_errors=%0d response_stalls=%0d fairness_checks=%0d",errors,rsp_stalls,ties);
  $finish;
end
initial begin #100000;$fatal(1,"ARBITER TIMEOUT");end
endmodule
