`timescale 1ns/1ps
module tb_icb_cfg;
  reg clk=0;always #5 clk=~clk;
  reg rst_n=0;
  integer csr_cmd=0,csr_rsp=0,starts=0,n;
  reg [31:0] expected_data,mask32,old_value;
  reg [1:0] events=0;
  reg [7:0] event_code=0;
  task tick;begin @(negedge clk);#1;end endtask
  reg cv=0,crd=1,csrready=0;
  reg [31:0] ca=0,cwd=0;
  reg [3:0] cwm=0;
  wire cready,csv,cse,irq,start;
  wire [31:0] csd,ib,ob,pb,stride,layers;
  reg busy=0,done=0,err=0,legal=1;
  reg [7:0] ecode=0;
  reg [3:0] layer=4'd7;
  reg [4:0] stage=5'd15;
  reg [31:0] cycles=32'h12345678;
  kwt_icb_cfg cfg(
    .clk(clk),.rst_n(rst_n),.s_icb_cmd_valid(cv),.s_icb_cmd_ready(cready),
    .s_icb_cmd_addr(ca),.s_icb_cmd_read(crd),.s_icb_cmd_wdata(cwd),.s_icb_cmd_wmask(cwm),
    .s_icb_rsp_valid(csv),.s_icb_rsp_ready(csrready),.s_icb_rsp_rdata(csd),.s_icb_rsp_err(cse),
    .run_busy(busy),.run_done(done),.run_error(err),.run_error_code(ecode),
    .run_layer(layer),.run_stage(stage),.run_cycles(cycles),.cfg_valid(legal),
    .start_pulse(start),.cfg_input_base(ib),.cfg_output_base(ob),.cfg_param_base(pb),
    .cfg_layer_stride(stride),.cfg_layer_count(layers),.irq(irq));
  always @(posedge clk)if(rst_n)begin
    if(cv&&cready)csr_cmd=csr_cmd+1;
    if(csv&&csrready)csr_rsp=csr_rsp+1;
    if(start)starts=starts+1;
  end
  task csr(input [31:0] address,input rd,input [31:0] value,input [3:0] mask,
           input [31:0] expected,input expected_err,input integer hold_cycles);
    integer k;
    begin
      tick;cv=1;ca=address;crd=rd;cwd=value;cwm=mask;csrready=0;
      done=events[0];err=events[1];ecode=event_code;
      if(!cready)$fatal(1,"CSR not ready before request");
      @(posedge clk);#1;
      if(!csv||csd!==expected||cse!==expected_err)
        $fatal(1,"CSR address=%h rd=%b got=%h/%b expected=%h/%b",address,rd,csd,cse,expected,expected_err);
      tick;cv=0;done=0;err=0;
      for(k=0;k<hold_cycles;k=k+1)begin
        ca=32'hffffffff;cwd=~value;crd=~rd;
        @(posedge clk);#1;
        if(!csv||csd!==expected||cse!==expected_err||cready)$fatal(1,"CSR RESPONSE HOLD");
        tick;
      end
      csrready=1;@(posedge clk);#1;
      tick;csrready=0;
      if(csv)$fatal(1,"DUPLICATE CSR RESPONSE");
    end
  endtask

  initial begin
    repeat(4)tick;rst_n=1;tick;
    csr(0,1,0,0,32'h4b575431,0,4);
    csr('h20,1,0,0,12,0,0);
    csr('h00,0,32'hffffffff,15,0,1,2);
    csr('h30,1,0,0,0,1,1);
    csr('h11,0,32'hffffffff,15,0,1,0);
    csr('h10,0,32'h12345678,15,0,0,0);old_value=32'h12345678;
    for(n=0;n<16;n=n+1)begin
      mask32={{8{n[3]}},{8{n[2]}},{8{n[1]}},{8{n[0]}}};
      expected_data=32'haabbccdd^n;old_value=(old_value&~mask32)|(expected_data&mask32);
      csr('h10,0,expected_data,n,0,0,n%4);
      csr('h10,1,0,0,old_value,0,0);
    end
    csr('h14,0,32'h81000000,15,0,0,0);
    csr('h18,0,32'h82000000,15,0,0,0);
    csr('h1c,0,32'h0000d000,15,0,0,0);
    csr('h20,0,32'd3,15,0,0,0);
    if(ob!==32'h81000000||pb!==32'h82000000||stride!==32'hd000||layers!==3)$fatal(1,"CONFIG OUTPUTS");
    busy=1;
    csr('h10,0,0,15,0,1,2);if(ib!==old_value)$fatal(1,"BUSY CONFIG MUTATION");
    csr('h04,0,1,15,0,1,0);
    csr('h08,1,0,0,1,0,0);
    csr('h0c,0,1,15,0,0,0);
    busy=0;legal=0;
    csr('h04,0,1,15,0,1,0);
    legal=1;
    csr('h04,0,1,14,0,0,0);if(starts!=0)$fatal(1,"MASKED START");
    csr('h04,0,1,15,0,0,0);if(starts!=1)$fatal(1,"START PULSE");
    events=3;event_code=8'h5a;
    csr('h08,0,6,15,0,0,2);events=0;
    csr('h08,1,0,0,6,0,1);if(!irq)$fatal(1,"INTERRUPT");
    csr('h24,1,0,0,32'h5a,0,0);
    csr('h08,0,6,14,0,0,0);if(!irq)$fatal(1,"MASKED W1C");
    csr('h08,0,2,15,0,0,0);
    csr('h08,1,0,0,4,0,0);
    csr('h08,0,4,15,0,0,0);if(irq)$fatal(1,"CLEAR INTERRUPT");
    csr('h24,1,0,0,0,0,0);
    csr('h28,1,0,0,32'hf07,0,0);
    csr('h2c,1,0,0,32'h12345678,0,0);

    // A full response slot must block a second command until it can retire.
    tick;cv=1;crd=1;ca=0;csrready=0;
    @(posedge clk);#1;tick;ca='h2c;
    repeat(6)begin
      if(cready||!csv||csd!==32'h4b575431)$fatal(1,"BLOCK SECOND CSR COMMAND");
      tick;
    end
    csrready=1;
    @(posedge clk);#1;if(!csv||csd!==cycles)$fatal(1,"CSR REPLACE RESPONSE");
    tick;cv=0;@(posedge clk);#1;tick;csrready=0;

    // Back-to-back throughput: one accepted register read per cycle.
    cv=1;crd=1;csrready=1;
    for(n=0;n<32;n=n+1)begin
      ca=(n%2)?32'h2c:0;
      @(posedge clk);#1;
      if(!csv||cse||csd!==((n%2)?cycles:32'h4b575431))$fatal(1,"BACK TO BACK CSR");
      tick;
    end
    cv=0;@(posedge clk);#1;tick;csrready=0;
    if(csr_cmd!=csr_rsp)$fatal(1,"CSR COUNT");
    rst_n=0;#1;if(csv!==0||irq!==0||start!==0)$fatal(1,"RESET");
    tick;rst_n=1;tick;
    if(ib||ob||pb||stride||layers!=12)$fatal(1,"RESET CONFIG");
    $display("PASS tb_icb_cfg transactions=%0d starts=%0d",csr_cmd,starts);
    $finish;
  end
  initial begin #1000000;$fatal(1,"CFG TIMEOUT");end
endmodule
