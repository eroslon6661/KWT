#!/usr/bin/env bash
# Read the waveform from the explicitly selected run; never guess the latest run.
set -euo pipefail
if [[ $# -ne 1 ]]; then
  echo 'Usage: bash view_wave.sh RUN_DIRECTORY' >&2
  exit 2
fi
run=$(cd -- "$1" && pwd -P)
if [[ ! -s "$run/wave.vcd" ]]; then
  printf 'Missing or empty waveform: %s/wave.vcd\n' "$run" >&2
  exit 1
fi
verdi_bin=${VERDI_BIN:-verdi}
command -v "$verdi_bin" >/dev/null
cd -- "$run"
exec "$verdi_bin" -ssf "$run/wave.vcd"
