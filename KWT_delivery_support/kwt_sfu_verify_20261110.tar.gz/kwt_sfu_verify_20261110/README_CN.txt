kwt_vpu_sfu 独立验证包（2026-11-10）

一、这次增加的内容
原 tb_operators 先测试 65536 种 FP16 编码，再运行少量 SFU 用例，所以
SFU 的 start 在整个算子波形的大部分时间内为 0。原 SFU 测试还会在接受
请求后更改 op/x 来检查锁存。这种波形不适合直接阅读输入输出对应关系。

本包只编译 kwt_vpu_sfu、kwt_vpu_mul、kwt_pe_fp32_add 和 tb_sfu。
RTL 与原 kwt_vcs_module_verify/accel_rtl 的对应文件保持逐字节一致。
demo：32 个数值演示用例，每种 op 8 个，按 00、01、10、11 顺序执行。
full：753 个数值/边界用例，外加各 op 的 busy 中干扰请求、运行中复位及
复位后恢复，并检查两次无空闲间隔的连续请求。只有 full 的协议阶段才会
故意改变正在运算时的 op/x；phase=1 的全部数值阶段始终保持输入稳定。

二、功能与时序
op=00：exp(x)，仅非正输入。x<-80 输出0；正非零输入返回NaN。
op=01：tanh(x)。|x|>=9 饱和到±1，|x|<2^-12 直接返回x。
op=10：1/x，正正规数输入。
op=11：1/sqrt(x)，正正规数输入。
四种 op 对 Inf/NaN 均返回 7fc00000；10/11 对负数、±0、次正规数也如此。

start 是请求信号，仅在 busy=0 的上升沿接受。正常数值请求用一周期脉冲；
full 的忙时干扰阶段故意额外拉高 start，以检查 DUT 是否正确忽略。
普通计算接受后 busy=1；完成时 done=1、busy=0，且 y 为本次结果。
从接受拍之后计数，四种普通路径分别需 21/37/12/20 周期；特殊分支接受
当拍完成，busy 不拉高。因此 start 低不等于没有在计算，应结合 busy。
持续拉高 start 跨过完成，会在重新空闲时再次接受同一请求，不能将其
作为“保持计算”的使能。没有新请求时 done 清零，y 保持上次完成的值。

三、在 Linux 服务器运行
把 kwt_sfu_verify_20261110.tar.gz 上传到服务器桌面后：

kwt_stage=$(mktemp -d "$HOME/Desktop/kwt_sfu_check_XXXXXXXX")
tar -xzf "$HOME/Desktop/kwt_sfu_verify_20261110.tar.gz" -C "$kwt_stage"
cd "$kwt_stage/kwt_sfu_verify_20261110"
bash run_vcs.sh demo

使用终端末尾打印的 Results 目录打开完整波形：
bash view_wave.sh runs/实际运行目录名

全面回归：
bash run_vcs.sh full

只看一种 op（第二个参数必须写两个二进制字符）：
bash run_vcs.sh demo 00
bash run_vcs.sh demo 01
bash run_vcs.sh demo 10
bash run_vcs.sh demo 11

完整回归也可以加上述第二参数筛选。不需要重建旧工程、SRAM模型或固件。
服务器需已有可用的 vcs、verdi 和许可证。脚本不要求 Python，不会修改旧包。
每次运行创建新 runs 目录，保留编译日志、仿真日志、results.txt、wave.vcd。
默认记录整个短仿真，不再使用原脚本的 200000 ns 波形截断窗口。
若只检查数值而不录波形，可执行：DUMP=0 bash run_vcs.sh full

四、Verdi 中优先添加的信号
Scope：tb_sfu
clk rst_n phase case_id op x start busy done y expected_y observed_y
transaction_active check_valid case_pass latency_cycles expected_latency
x_real y_real expected_real abs_error tolerance accepted_op accepted_x

op 以二进制显示；x/y/expected_y/observed_y 以十六进制显示，均为FP32位模式。
x_real/y_real/expected_real 是解码后的实数，方便读值。对NaN/Inf这些实数
显示为占位0，必须查看原始十六进制；NaN结果为7fc00000。
case_id 对应 docs/sfu_expected_values.txt 的行号ID；check_valid=1时
observed_y为已检查的实际结果，case_pass=1表示当前用例通过。
expected_y是独立数学参考四舍五入到FP32后的位模式；普通近似运算允许
在规定误差内与它相差若干ULP，不能要求所有用例逐位等于数学参考。
内部定位可另加 dut.st、dut.degree、dut.iter、dut.z、dut.r、dut.tmp。
phase=1数值测试；2忙时请求干扰；3复位中止与恢复；5连续请求；4结束。

五、具体 x/y、对比方法与覆盖范围
docs/sfu_expected_values.txt 列出全部753个输入、独立预期输出、比较方式，
最前面的 DEMO 表列出32个波形演示用例。每次仿真的 results.txt 另外列出
真正得到的 y（hex/十进制）、reference、误差、容差、完成延迟和PASS。
docs/sfu_demo_actual.txt 保存本次本地ModelSim得到的32组实际x/y简表，
validation/demo_results.txt、full_results.txt 保存本次完整实际结果。
tools/generate_sfu_vectors.py 用Python math生成参考，不调用RTL内部算法。
生成向量时先将x量化到FP32，解码后求数学函数，再将参考结果舍入到FP32。
普通数值检查 |actual-reference| <= atol + rtol*|reference|；域处理和
饱和/透传分支按精确位模式检查。exp采用极小绝对项，避免小结果被误清零
却通过旧2e-6绝对容差的问题。全部请求同时检查busy、done、y保持和延迟。
每种op均含定向点、边界及固定种子的随机/网格输入。00检查-80边界，
01检查±9和±2^-12边界。10/11正常数覆盖[2^-20,2^20]，另检查非法输入。
“full”指本包定义的全部回归用例，不是穷举全部32位输入。乘法器有
DAZ/FTZ行为，不能据此声称倒数/平方根倒数在整个FP32极端范围都准确。

六、验证证据
validation/ 中记录本地 ModelSim 的预检结果。本地通过不等于服务器
VCS已经执行；服务器运行成功应同时出现 PASS tb_sfu 和 status.txt=PASS。
full all 的汇总 cases=761，是753个向量加4个忙时干扰完成、4个复位后
恢复完成；reset_abort=4及back_to_back=2另外计数，不含在761中。
原16/17例SFU测试未被冒充为本次新测试，原VCS包和RTL均未改动。
