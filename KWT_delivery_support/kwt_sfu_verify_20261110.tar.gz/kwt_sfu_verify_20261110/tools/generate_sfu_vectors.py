#!/usr/bin/env python3
"""Generate independent mathematical references for the four SFU operations.

No DUT arithmetic/state-machine implementation is used as a golden model.
Domain responses are checked against the explicit RTL interface policy.
Numerical references use math on the decoded binary32 input, then round once
to binary32. Approximate arithmetic is compared using declared tolerances.
"""
from pathlib import Path
import math
import random
import struct


ROOT = Path(__file__).resolve().parents[1]
NAMES = ("EXP_NONPOSITIVE", "TANH", "RECIPROCAL", "RSQRT")
CANONICAL_NAN = 0x7FC00000


def bits(value):
    return struct.unpack("<I", struct.pack("<f", value))[0]


def number(word):
    return struct.unpack("<f", struct.pack("<I", word))[0]


def describe(word):
    value = number(word)
    if math.isnan(value):
        return "NaN"
    if math.isinf(value):
        return "-Inf" if value < 0 else "+Inf"
    if word == 0x80000000:
        return "-0"
    return format(value, ".10g")


def reference(op, word):
    """Return expected binary32, comparison kind, atol, rtol, rationale."""
    sign = word >> 31
    exponent = (word >> 23) & 255
    magnitude = word & 0x7FFFFFFF
    value = number(word)
    if exponent == 255:
        return CANONICAL_NAN, 2, 0.0, 0.0, "NaN/Inf policy: canonical NaN"
    if op in (2, 3) and (sign or exponent == 0):
        return CANONICAL_NAN, 2, 0.0, 0.0, "nonpositive/subnormal input rejected"
    if op == 0:
        if sign and magnitude > 0x42A00000:
            return 0, 1, 0.0, 0.0, "x < -80: explicit zero clamp"
        if not sign and magnitude != 0:
            return CANONICAL_NAN, 2, 0.0, 0.0, "positive nonzero input rejected"
        return bits(math.exp(value)), 0, 1e-40, 2e-5, "independent exp(x)"
    if op == 1:
        if magnitude >= 0x41100000:
            return (sign << 31) | bits(1.0), 1, 0.0, 0.0, "|x| >= 9: signed saturation"
        if exponent < 115:
            return word, 1, 0.0, 0.0, "|x| < 2^-12: identity shortcut"
        return bits(math.tanh(value)), 0, 2e-6, 2e-5, "independent tanh(x)"
    if op == 2:
        return bits(1.0 / value), 0, 0.0, 2e-5, "independent 1/x"
    return bits(1.0 / math.sqrt(value)), 0, 0.0, 2e-5, "independent 1/sqrt(x)"


def main():
    # Eight demonstration requests per operation, grouped by operation in demo.
    demos = [
        [0.0, -0.125, -0.5, -1.0, -2.0, -4.0, -10.0, -80.0],
        [-10.0, -2.0, -1.0, -0.5, 0.0, 0.5, 1.0, 10.0],
        [0.25, 0.5, 1.0, 2.0, 3.0, 4.0, 16.0, 64.0],
        [0.25, 0.5, 1.0, 2.0, 3.0, 4.0, 9.0, 16.0],
    ]
    # NaN payloads, infinities, signed zeros and signed subnormal endpoints.
    special = [
        0x00000000, 0x80000000, 0x00000001, 0x80000001,
        0x007FFFFF, 0x807FFFFF, 0x7F800000, 0xFF800000,
        0x7FC12345, 0xFFC12345, 0x7F800001, 0xFF800001,
    ]
    rows = []
    demo_rows = []
    seen = set()
    rng = random.Random(20261110)

    def add(op, word, label, demo=False):
        key = (op, word)
        if key in seen:
            return
        seen.add(key)
        want, kind, atol, rtol, reason = reference(op, word)
        row = (len(rows) + 1, op, word, want, kind, atol, rtol, label, reason)
        rows.append(row)
        if demo:
            demo_rows.append(row)

    for op in range(4):
        for value in demos[op]:
            add(op, bits(value), "demo", demo=True)
        for word in special:
            add(op, word, "special")
        if op == 0:
            for word in [0xC29FFFFF, 0xC2A00000, 0xC2A00001,
                         0xBF317217, 0xBF317218, 0xBF317219,
                         0x80800000, 0x00800000, 0xFF7FFFFF,
                         0x3F800000, 0x7F7FFFFF]:
                add(op, word, "boundary")
            # Relative checks stay meaningful even for exp(-80) ~ 1.8e-35.
            for i in range(129):
                add(op, bits(-80.0 * i / 128), "uniform_grid")
            for _ in range(32):
                add(op, bits(rng.uniform(-80.0, 0.0)), "seeded_random")
        elif op == 1:
            for magnitude in [0x397FFFFF, 0x39800000, 0x39800001,
                              0x410FFFFF, 0x41100000, 0x41100001,
                              0x00800000, 0x7F7FFFFF]:
                for sign in [0, 0x80000000]:
                    add(op, sign | magnitude, "boundary")
            for i in range(129):
                add(op, bits(-8.0 + 16.0 * i / 128), "uniform_grid")
            for _ in range(32):
                add(op, bits(rng.uniform(-8.99, 8.99)), "seeded_random")
        else:
            for value in [-1.0, -0.25, -4.0, -1048576.0]:
                add(op, bits(value), "invalid_negative")
            for word in [0x3F7FFFFF, 0x3F800001, 0x3FFFFFFF, 0x40000001]:
                add(op, word, "power_of_two_neighbor")
            for i in range(129):
                add(op, bits(2.0 ** (-20.0 + 40.0 * i / 128)), "log_grid")
            for _ in range(32):
                add(op, bits(2.0 ** rng.uniform(-20.0, 20.0)), "seeded_random")

    def line(row):
        ident, op, word, want, kind, atol, rtol = row[:7]
        return f"{ident:d} {op:d} {word:08x} {want:08x} {kind:d} {atol:.9e} {rtol:.9e}\n"

    assert len(demo_rows) == 32
    for op in range(4):
        assert sum(row[1] == op for row in rows) >= 150
        assert sum(row[1] == op for row in demo_rows) == 8
    for path, selected in [(ROOT / "vectors/sfu_cases.txt", rows),
                           (ROOT / "vectors/sfu_demo.txt", demo_rows)]:
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("w", encoding="ascii", newline="\n") as stream:
            stream.write("".join(map(line, selected)))

    docs = [
        "KWT SFU independent expected values (binary32 input/output)",
        "Generated from Python math; NOT an RTL arithmetic/state-machine model.",
        "op 00: exp(x) for x<=0, explicit x<-80 clamp to zero; positive x rejected.",
        "op 01: tanh(x), |x|>=9 saturates to signed 1; |x|<2^-12 returns x.",
        "op 10: reciprocal 1/x; op 11: reciprocal square root 1/sqrt(x).",
        "All NaN/Inf inputs return canonical 0x7fc00000. Ops 10/11 reject",
        "negative values, both signed zeros, and all subnormal inputs.",
        "Finite numeric tests for ops 10/11 span [2^-20, 2^20]. More extreme",
        "positive normal values may overflow/underflow internal iterations and",
        "are NOT numerically qualified here. This is not exhaustive IEEE testing.",
        "",
        "vectors/*.txt: seven whitespace-separated columns, no header:",
        "id_decimal op_decimal x_hex expected_y_hex kind_decimal atol_real rtol_real",
        "kind=0: finite |actual-reference| <= atol + rtol*|reference|",
        "kind=1: exact 32-bit equality; kind=2: exact canonical NaN 0x7fc00000",
        "expected_y_hex is rounded mathematical reference, not a required exact",
        "RTL output bit pattern for kind=0. The testbench records actual y separately.",
        "Mathematical functions consume decoded binary32 x, not unrounded Python x.",
        "Compare x and y as IEEE754 single precision, not as integer magnitudes.",
        "The op field is decimal in files; waveform should display it in binary.",
        "",
        "Counts: " + ", ".join(f"op={op:02b}: {sum(r[1] == op for r in rows)}" for op in range(4)),
        f"Full: {len(rows)} requests; demo: {len(demo_rows)} requests; RNG seed: 20261110.",
        "",
        "DEMO: x and expected y (8 requests per operation)",
        "id    op       x_hex          x_decimal          y_ref_hex      y_ref_decimal       kind",
    ]

    def detail(row):
        ident, op, word, want, kind = row[:5]
        return f"{ident:<5d} {op:02b}       {word:08x}    {describe(word):>16s}    {want:08x}    {describe(want):>16s}    {kind}"

    docs.extend(detail(row) for row in demo_rows)
    docs.extend(["", "FULL VECTOR INDEX", "id / op / x / mathematical or contract y / comparison kind / category / reason"])
    docs.extend(detail(row) + f"    {row[7]}    {row[8]}" for row in rows)
    path = ROOT / "docs/sfu_expected_values.txt"
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="ascii", newline="\n") as stream:
        stream.write("\n".join(docs) + "\n")
    print(f"Generated full={len(rows)}, demo={len(demo_rows)}")
    print("Per-op counts:", [sum(r[1] == op for r in rows) for op in range(4)])


if __name__ == "__main__":
    main()
