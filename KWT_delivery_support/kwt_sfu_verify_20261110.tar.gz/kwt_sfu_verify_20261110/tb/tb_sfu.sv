`timescale 1ns/1ps
// Dedicated SFU test: stable waveform commands plus independent math vectors.
module tb_sfu;
  reg clk=0, rst_n=0, start=0;
  reg [1:0] op=0;
  reg [31:0] x=0;
  wire busy, done;
  wire [31:0] y;
  always #5 clk=~clk;
  kwt_vpu_sfu dut(.clk(clk),.rst_n(rst_n),.start(start),.op(op),.x(x),
                 .busy(busy),.done(done),.y(y));

  // Add these top-level signals to Verdi; x/y are IEEE binary32 bit patterns.
  reg [31:0] expected_y=0, observed_y=0, accepted_x=0;
  reg [1:0] accepted_op=0;
  reg transaction_active=0, check_valid=0, case_pass=0;
  integer case_id=0, phase=0, latency_cycles=0, expected_latency=0;
  real x_real=0.0, y_real=0.0, expected_real=0.0, abs_error=0.0, tolerance=0.0;
  integer passed=0, op_count[0:3], protocol_checks=0, reset_checks=0, consecutive_checks=0;
  integer input_fd, output_fd, scan_count, vector_id, vector_op, kind, op_filter=-1, k;
  reg [31:0] vector_x, vector_y;
  real abs_tol, rel_tol;
  reg [4095:0] vector_path="vectors/sfu_demo.txt", results_path="results.txt";

  function automatic real fp32(input [31:0] bits);
    real magnitude;
    begin
      if(bits[30:23]==255) magnitude=0.0; // Nonfinite: display hex, real is a placeholder.
      else if(bits[30:23]==0) magnitude=bits[22:0]*(2.0**(-149));
      else magnitude=(1.0+bits[22:0]/8388608.0)*(2.0**(integer'(bits[30:23])-127));
      fp32=bits[31] ? -magnitude : magnitude;
    end
  endfunction
  function automatic integer latency(input [1:0] opcode,input [31:0] arg);
    begin
      if(arg[30:23]==255 || ((opcode==2 || opcode==3) && (arg[31] || arg[30:23]==0))) latency=0;
      else if(opcode==0 && ((arg[31] && arg[30:0]>31'h42a00000) || (!arg[31] && arg[30:0]!=0))) latency=0;
      else if(opcode==1 && (arg[30:0]>=31'h41100000 || arg[30:23]<115)) latency=0;
      else case(opcode)
        0: latency=21;
        1: latency=37;
        2: latency=12;
        3: latency=20;
      endcase
    end
  endfunction

  task automatic request(input integer id,input [1:0] opcode,input [31:0] arg,
                         input [31:0] want,input integer compare_kind,
                         input real atol,input real rtol,input bit disturb);
    reg [31:0] previous_y;
    real scale;
    begin
      @(negedge clk);
      if(busy!==0 || done!==0) $fatal(1,"SFU not idle id=%0d",id);
      case_id=id; expected_y=want; accepted_op=opcode; accepted_x=arg;
      op=opcode; x=arg; x_real=fp32(arg); expected_real=fp32(want);
      check_valid=0;case_pass=0;transaction_active=1;
      latency_cycles=0;expected_latency=latency(opcode,arg);previous_y=y;start=1;
      @(posedge clk);#1;
      if(expected_latency==0) begin
        if(done!==1 || busy!==0) $fatal(1,"Immediate completion missing id=%0d",id);
      end else if(busy!==1 || done!==0 || y!==previous_y)
        $fatal(1,"Acceptance/busy/output-hold failure id=%0d",id);
      @(negedge clk);start=0;
      while(done!==1 && latency_cycles<80) begin
        // Full-mode protocol phase only: other requests while busy are ignored.
        if(disturb && busy===1 && latency_cycles<expected_latency-2) begin
          start=1;op=~opcode;x=32'h7fc12345;
        end else begin start=0;op=opcode;x=arg;end
        @(posedge clk);#1;latency_cycles=latency_cycles+1;
        if(done!==1 && (busy!==1 || y!==previous_y))
          $fatal(1,"In-flight busy/output-hold failure id=%0d cycle=%0d",id,latency_cycles);
        if(done!==1) @(negedge clk);
      end
      if(done!==1 || busy!==0) $fatal(1,"Timeout/completion failure id=%0d",id);
      if(latency_cycles!=expected_latency)
        $fatal(1,"Latency id=%0d got=%0d want=%0d",id,latency_cycles,expected_latency);
      observed_y=y;abs_error=0.0;tolerance=0.0;
      if(compare_kind==1 || compare_kind==2) begin
        if(y!==want) $fatal(1,"Exact/domain id=%0d op=%02b x=%08h got=%08h expected=%08h",id,opcode,arg,y,want);
      end else begin
        if((^y)===1'bx || y[30:23]==255) $fatal(1,"Nonfinite result id=%0d y=%h",id,y);
        y_real=fp32(y);abs_error=y_real-expected_real;if(abs_error<0)abs_error=-abs_error;
        scale=expected_real;if(scale<0)scale=-scale;tolerance=atol+rtol*scale;
        if(abs_error>tolerance)
          $fatal(1,"Numeric id=%0d op=%02b x=%h y=%h actual=%e ref=%e error=%e tol=%e",id,opcode,arg,y,y_real,expected_real,abs_error,tolerance);
      end
      if(y[30:23]!=255)y_real=fp32(y);
      else y_real=0.0; // NaN is identified by y bits and compare_kind in results.
      case_pass=1;check_valid=1;transaction_active=0;
      $fdisplay(output_fd,"CASE id=%0d phase=%0d op=%02b x=%08h y=%08h expected=%08h kind=%0d x_real=%e y_real=%e reference=%e abs_error=%e tolerance=%e latency=%0d PASS",
        id,phase,opcode,arg,y,want,compare_kind,x_real,y_real,expected_real,abs_error,tolerance,latency_cycles);
      $display("SFU_CASE_PASS id=%0d op=%02b x=%08h y=%08h expected=%08h latency=%0d",id,opcode,arg,y,want,latency_cycles);
      // Immediate completion is already at the first negedge after acceptance.
      // Check done clears on the very next posedge, not one clock later.
      if(expected_latency!=0) @(negedge clk);
      start=0;op=opcode;x=arg;
      @(posedge clk);#1;
      if(done!==0 || busy!==0 || y!==observed_y) $fatal(1,"Done pulse/output hold failure id=%0d",id);
      passed=passed+1;op_count[opcode]=op_count[opcode]+1;
    end
  endtask

  task automatic back_to_back;
    integer j,c;
    reg [31:0] previous;
    real reference, error;
    begin
      // A new request on the FIRST clock after completion, with no idle bubble.
      @(negedge clk);op=2;x=32'h40800000;start=1;
      for(j=0;j<2;j=j+1)begin
        case_id=10000+j;check_valid=0;case_pass=0;transaction_active=1;
        accepted_op=op;accepted_x=x;x_real=fp32(x);expected_y=(j==0)?32'h3e800000:32'h3f000000;
        expected_real=(j==0)?0.25:0.5;expected_latency=(j==0)?12:20;latency_cycles=0;
        previous=y;
        @(posedge clk);#1;
        if(busy!==1 || done!==0)$fatal(1,"Back-to-back acceptance %0d",j);
        @(negedge clk);start=0;
        for(c=1;c<=(j==0?12:20);c=c+1)begin
          @(posedge clk);#1;
          latency_cycles=c;
          if(c<(j==0?12:20) && (busy!==1 || done!==0 || y!==previous))
            $fatal(1,"Back-to-back busy/hold");
        end
        reference=(j==0)?0.25:0.5;
        error=fp32(y)-reference;if(error<0)error=-error;
        if(done!==1 || busy!==0 || (^y)===1'bx || y[30:23]==255 || error>reference*0.00002)
          $fatal(1,"Back-to-back result %0d y=%h",j,y);
        observed_y=y;y_real=fp32(y);abs_error=error;tolerance=reference*0.00002;
        transaction_active=0;check_valid=1;case_pass=1;
        $fdisplay(output_fd,"PROTOCOL back_to_back op=%02b x=%08h y=%08h PASS",op,x,y);
        consecutive_checks=consecutive_checks+1;
        @(negedge clk);
        if(j==0)begin op=3;x=32'h40800000;start=1;end
      end
      @(posedge clk);#1;
      if(done!==0 || busy!==0)$fatal(1,"Back-to-back final idle");
    end
  endtask

  task automatic abort_by_reset(input [1:0] opcode);
    begin
      @(negedge clk);start=1;op=opcode;x=(opcode==0)?32'hbf800000:32'h40800000;
      case_id=9500+opcode;check_valid=0;case_pass=0;transaction_active=1;
      accepted_op=op;accepted_x=x;x_real=fp32(x);expected_y=0;expected_real=0.0;
      latency_cycles=0;expected_latency=0;
      @(negedge clk);start=0;
      repeat(3)@(negedge clk);
      if(busy!==1)$fatal(1,"Reset test failed to enter busy op=%02b",opcode);
      #2;rst_n=0;#1;
      transaction_active=0;observed_y=y;y_real=0.0;
      if(busy!==0 || done!==0 || y!==0)$fatal(1,"Asynchronous reset failure op=%02b",opcode);
      repeat(2)@(negedge clk);rst_n=1;
      repeat(42)begin @(posedge clk);#1;if(done!==0 || busy!==0)$fatal(1,"Stale completion after reset");end
      reset_checks=reset_checks+1;
      // A new transaction must still work after reset.
      request(9000+opcode,opcode,(opcode==0)?32'hbf800000:32'h40800000,
        (opcode==0)?32'h3ebc5ab2:(opcode==1)?32'h3f7fd40c:(opcode==2)?32'h3e800000:32'h3f000000,
        0,0.000002,0.00002,0);
    end
  endtask

  initial begin
    if(!$test$plusargs("NO_WAVE"))begin $dumpfile("wave.vcd");$dumpvars(0,tb_sfu);end
  end
  initial begin #2000000;$fatal(1,"SFU watchdog");end
  initial begin
    for(k=0;k<4;k=k+1)op_count[k]=0;
    scan_count=$value$plusargs("VECTORS=%s",vector_path);
    scan_count=$value$plusargs("RESULTS=%s",results_path);
    scan_count=$value$plusargs("OP_FILTER=%d",op_filter);
    if(op_filter < -1 || op_filter>3)$fatal(1,"Bad OP_FILTER");
    input_fd=$fopen(vector_path,"r");output_fd=$fopen(results_path,"w");
    if(!input_fd || !output_fd)$fatal(1,"Cannot open vectors/results");
    $fdisplay(output_fd,"SFU actual simulation results. kind=0 math-tolerance, 1 exact, 2 canonical NaN. NaN real display is a placeholder; use hex bits.");
    repeat(3)@(negedge clk);rst_n=1;phase=1;
    while(!$feof(input_fd))begin
      scan_count=$fscanf(input_fd,"%d %d %h %h %d %e %e\n",vector_id,vector_op,vector_x,vector_y,kind,abs_tol,rel_tol);
      if(scan_count==7)begin
        if(vector_op<0 || vector_op>3 || kind<0 || kind>2)$fatal(1,"Bad vector fields");
        if(op_filter==-1 || op_filter==vector_op)
          request(vector_id,vector_op[1:0],vector_x,vector_y,kind,abs_tol,rel_tol,0);
      end else if(scan_count!=-1) $fatal(1,"Malformed vector line count=%0d",scan_count);
    end
    $fclose(input_fd);
    if(passed==0)$fatal(1,"No cases executed");
    if($test$plusargs("PROTOCOL"))begin
      phase=2;
      for(k=0;k<4;k=k+1)begin
        if(op_filter==-1 || op_filter==k)begin
          request(8000+k,k[1:0],(k==0)?32'hbf800000:32'h40800000,
            (k==0)?32'h3ebc5ab2:(k==1)?32'h3f7fd40c:(k==2)?32'h3e800000:32'h3f000000,
            0,0.000002,0.00002,1);
          protocol_checks=protocol_checks+1;
          phase=3;abort_by_reset(k[1:0]);phase=2;
        end
      end
      if(op_filter==-1)begin phase=5;back_to_back();end
    end
    phase=4;
    repeat(5)@(negedge clk);
    $display("PASS tb_sfu cases=%0d op00=%0d op01=%0d op10=%0d op11=%0d busy_ignore=%0d reset_abort=%0d back_to_back=%0d",
      passed,op_count[0],op_count[1],op_count[2],op_count[3],protocol_checks,reset_checks,consecutive_checks);
    $fclose(output_fd);$finish;
  end
endmodule
