#!/usr/bin/env bash
# Standalone SFU verification. Compile and simulate in a fresh run directory.
set -Eeuo pipefail
export LC_ALL=C

root=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)
mode=${1:-demo}
op_filter=${2:-all}
if [[ $# -gt 2 ]]; then
  echo 'Usage: bash run_vcs.sh [demo|full] [all|00|01|10|11]' >&2
  exit 2
fi
case "$mode" in
  demo) vectors="$root/vectors/sfu_demo.txt" ;;
  full) vectors="$root/vectors/sfu_cases.txt" ;;
  *) echo 'Mode must be demo or full.' >&2; exit 2 ;;
esac
case "$op_filter" in
  all) op_number= ;;
  00) op_number=0 ;;
  01) op_number=1 ;;
  10) op_number=2 ;;
  11) op_number=3 ;;
  *) echo 'Operation filter must be all, 00, 01, 10 or 11.' >&2; exit 2 ;;
esac
case "${DUMP:-1}" in
  0|1) ;;
  *) echo 'DUMP must be 0 or 1.' >&2; exit 2 ;;
esac
vcs_bin=${VCS_BIN:-vcs}
command -v "$vcs_bin" >/dev/null
command -v sha256sum >/dev/null
[[ -s "$vectors" && -s "$root/SHA256SUMS" ]]

mkdir -p -- "$root/runs"
run=$(mktemp -d "$root/runs/${mode}_${op_filter}_XXXXXXXX")
printf 'Run directory: %s\n' "$run"
printf 'INCOMPLETE\n' > "$run/status.txt"
failure() {
  local code=$?
  trap - ERR
  printf 'FAIL\n' > "$run/status.txt"
  printf 'FAIL: logs retained in %s\n' "$run" >&2
  for log_name in package_check.log compile_console.log simulation_console.log; do
    if [[ -f "$run/$log_name" ]]; then
      printf '%s\n' "$log_name" >&2
      tail -n 25 -- "$run/$log_name" >&2 || true
    fi
  done
  exit "$code"
}
trap failure ERR
(cd -- "$root" && sha256sum -c SHA256SUMS) > "$run/package_check.log" 2>&1

compile_opts=(-full64 -sverilog -timescale=1ns/1ps -debug_access+all
  -top tb_sfu
  "$root/rtl/kwt_pe_fp32_add.v"
  "$root/rtl/kwt_vpu_mul.v"
  "$root/rtl/kwt_vpu_sfu.v"
  "$root/tb/tb_sfu.sv"
  -o "$run/simv" -l "$run/compile.log")
sim_opts=(-l "$run/simulation.log"
  "+VECTORS=$vectors" "+RESULTS=$run/results.txt")
[[ -z "$op_number" ]] || sim_opts+=("+OP_FILTER=$op_number")
[[ "$mode" != full ]] || sim_opts+=(+PROTOCOL)
[[ "${DUMP:-1}" != 0 ]] || sim_opts+=(+NO_WAVE)

cd -- "$run"
printf '%q ' "$vcs_bin" "${compile_opts[@]}" > compile_command.sh
printf '\n' >> compile_command.sh
printf '%q ' ./simv "${sim_opts[@]}" > simulation_command.sh
printf '\n' >> simulation_command.sh
"$vcs_bin" "${compile_opts[@]}" > compile_console.log 2>&1
./simv "${sim_opts[@]}" > simulation_console.log 2>&1
grep -Eq '^PASS tb_sfu([[:space:]]|$)' simulation.log
[[ -s results.txt ]]
if [[ "${DUMP:-1}" != 0 ]]; then
  [[ -s wave.vcd ]]
fi
printf 'PASS\n' > status.txt
grep -E '^PASS ' simulation.log
printf 'Results: %s\n' "$run"
printf 'Actual x/y table: %s/results.txt\n' "$run"
if [[ "${DUMP:-1}" != 0 ]]; then
  printf 'View waveform: bash %q %q\n' "$root/view_wave.sh" "$run"
fi
