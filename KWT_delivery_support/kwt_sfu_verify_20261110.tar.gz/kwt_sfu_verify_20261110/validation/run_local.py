"""Windows ModelSim preflight of the standalone SFU TB; not a VCS result.

Usage: python validation/run_local.py [demo|full] [all|00|01|10|11]
Every invocation creates a fresh validation/local_* directory. DUMP=0 disables
the waveform. Override MODELSIM_BIN to use a different local ModelSim install.
"""
from pathlib import Path
import argparse
import hashlib
import json
import os
import re
import subprocess
import tempfile


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mode", nargs="?", choices=("demo", "full"), default="demo")
    parser.add_argument("op", nargs="?", choices=("all", "00", "01", "10", "11"), default="all")
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[1]
    binary_dir = Path(os.environ.get("MODELSIM_BIN", "E:/modelsim/win64"))
    dump = os.environ.get("DUMP", "1")
    if dump not in ("0", "1"):
        parser.error("DUMP must be 0 or 1")
    vectors = root / "vectors" / ("sfu_demo.txt" if args.mode == "demo" else "sfu_cases.txt")
    sources = [root / "rtl" / name for name in
               ("kwt_pe_fp32_add.v", "kwt_vpu_mul.v", "kwt_vpu_sfu.v")]
    sources.append(root / "tb/tb_sfu.sv")
    for path in [vectors] + sources + [binary_dir / (tool + ".exe") for tool in ("vlib", "vlog", "vsim")]:
        if not path.is_file():
            raise FileNotFoundError(str(path))
    run = Path(tempfile.mkdtemp(prefix="local_%s_%s_" % (args.mode, args.op), dir=str(root / "validation")))
    print("RUN " + str(run), flush=True)
    (run / "status.txt").write_text("INCOMPLETE\n", encoding="ascii")
    commands = []

    def invoke(cmd, logfile):
        cmd = [str(part) for part in cmd]
        commands.append({"argv": cmd, "cwd": str(run), "log": logfile})
        (run / "commands.json").write_text(json.dumps(commands, indent=2) + "\n", encoding="utf-8")
        with (run / logfile).open("w", encoding="utf-8") as output:
            result = subprocess.run(cmd, cwd=run, stdout=output, stderr=subprocess.STDOUT,
                                    timeout=300, check=False)
        text = (run / logfile).read_text(encoding="utf-8", errors="replace")
        if result.returncode:
            raise RuntimeError("%s exited %s\n%s" % (cmd[0], result.returncode, text[-8000:]))
        return text

    try:
        invoke([binary_dir / "vlib.exe", "work"], "vlib.log")
        invoke([binary_dir / "vlog.exe", "-sv", "-timescale", "1ns/1ps"] + sources, "compile.log")
        plusargs = ["+VECTORS=" + vectors.as_posix(), "+RESULTS=" + (run / "results.txt").as_posix()]
        if args.op != "all":
            plusargs.append("+OP_FILTER=" + str(int(args.op, 2)))
        if args.mode == "full":
            plusargs.append("+PROTOCOL")
        if dump == "0":
            plusargs.append("+NO_WAVE")
        transcript = invoke([binary_dir / "vsim.exe", "-c", "-onfinish", "exit", "-voptargs=+acc",
                             "work.tb_sfu"] + plusargs +
                            ["-do", "onbreak {quit -code 3}; onerror {quit -code 2}; run -all; quit -code 0"],
                            "simulation.log")
        pass_lines = [line for line in transcript.splitlines()
                      if re.match(r"^(?:# )?PASS tb_sfu(?:\s|$)", line)]
        if not pass_lines:
            raise RuntimeError("Missing PASS tb_sfu marker\n" + transcript[-8000:])
        if not (run / "results.txt").is_file() or (run / "results.txt").stat().st_size == 0:
            raise RuntimeError("Missing actual x/y result table")
        wave = run / "wave.vcd"
        if dump != "0" and (not wave.is_file() or wave.stat().st_size < 100):
            raise RuntimeError("Missing VCD waveform")
        report = {
            "status": "PASS", "simulator": "ModelSim local preflight", "vcs_tested": False,
            "mode": args.mode, "op_filter": args.op, "protocol_requested": args.mode == "full",
            "pass_lines": pass_lines, "run_directory": str(run),
            "actual_results": str(run / "results.txt"),
            "wave_vcd_bytes": wave.stat().st_size if wave.exists() else 0,
            "source_sha256": {path.relative_to(root).as_posix(): hashlib.sha256(path.read_bytes()).hexdigest()
                              for path in sources + [vectors]},
        }
        (run / "result.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
        (run / "status.txt").write_text("PASS\n", encoding="ascii")
        print(json.dumps(report, indent=2), flush=True)
    except BaseException:
        (run / "status.txt").write_text("FAIL\n", encoding="ascii")
        print("FAIL: logs retained in " + str(run), flush=True)
        raise


if __name__ == "__main__":
    main()
